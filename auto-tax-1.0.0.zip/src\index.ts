import { startServer } from './server';
import { CollectorService } from './modules/collector';

async function main() {
  const isCliMode = process.argv.includes('--cli') || process.argv.includes('--collect');

  if (isCliMode) {
    console.log('====================================================');
    console.log('   메일 수집 및 세금계산서 발행 데이터 CLI 수집 실행');
    console.log('====================================================');
    const collector = CollectorService.getInstance();
    await collector.startCollection();
  } else {
    const port = parseInt(process.env.PORT || '3000', 10);
    startServer(port);
  }
}

main().catch((err) => {
  console.error('[Error] 실행 중 오류 발생:', err);
  process.exit(1);
});
