import express, { Request, Response } from 'express';
import path from 'path';
import { loadConfig } from './config';
import { DataStorage } from './modules/storage';
import { CollectorService } from './modules/collector';
import { registerAdminRoutes } from './modules/adminRoutes';
import { RegistryStorage } from './modules/registry';

const LOOPBACK_HOSTS = ['localhost', '127.0.0.1', '[::1]'];

function listenHost(): string {
  return process.env.HOST || '127.0.0.1';
}

function isLoopbackHost(host: string): boolean {
  return host === '127.0.0.1' || host === '::1' || host === 'localhost';
}

export function createServer() {
  const app = express();

  // 인증서/비밀번호를 다루므로 기본적으로 이 PC(localhost)에서만 접속을 허용한다.
  // 다른 사이트가 DNS 리바인딩으로 localhost 서버에 접근하는 것을 막기 위해 Host 헤더도 확인한다.
  if (isLoopbackHost(listenHost())) {
    app.use((req: Request, res: Response, next) => {
      let hostname = '';
      try {
        hostname = new URL(`http://${req.headers.host || ''}`).hostname.toLowerCase();
      } catch {}
      if (LOOPBACK_HOSTS.includes(hostname)) return next();
      res.status(403).send('허용되지 않은 접속 주소입니다. http://localhost 로 접속해 주세요.');
    });
  }

  app.use(express.json());

  // Static files (Web UI)
  const publicDir = path.resolve(process.cwd(), 'public');
  app.use(express.static(publicDir));

  // 1. 전체 데이터 및 사업자별 누적 데이터 조회 API
  app.get('/api/data', (_req: Request, res: Response) => {
    try {
      const config = loadConfig();
      const storage = new DataStorage(config.options.outputDir);
      const data = storage.getAllBusinessesData(config.folders);
      // 직접 입력/수정한 발전소 정보(주소, 용량, 계약번호)와 소속 사업자를 반영
      new RegistryStorage(config.options.outputDir).applyToBusinesses(data.businesses);

      res.json({
        success: true,
        stats: data.stats,
        businesses: data.businesses,
        config: {
          folders: config.folders,
          options: {
            outputDir: config.options.outputDir,
            headless: config.options.headless,
            maxMailsPerFolder: config.options.maxMailsPerFolder,
          },
        },
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: err.message || '데이터를 불러오는 중 오류가 발생했습니다.',
      });
    }
  });

  // 2. 메일 수집 실행 API
  // body.folderId 가 있으면 그 발전소만 수집한다(발전소 카드의 "메일 수집" 버튼).
  app.post('/api/collect', async (req: Request, res: Response) => {
    try {
      const collector = CollectorService.getInstance();
      const folderId = typeof req.body?.folderId === 'string' ? req.body.folderId : undefined;
      if (folderId !== undefined) {
        const config = loadConfig();
        if (!config.folders.some((f) => f.folderId === folderId)) {
          res.status(404).json({ success: false, message: '발전소를 찾을 수 없습니다.' });
          return;
        }
        const mail = new RegistryStorage(config.options.outputDir).getPlantRecord(folderId)?.mail;
        if (!mail) {
          res.status(400).json({ success: false, message: '이 발전소는 메일 수집 정보가 없습니다. 발전소 수정에서 메일 정보를 입력해 주세요.' });
          return;
        }
        res.json(await collector.startCollection([folderId]));
        return;
      }
      const result = await collector.startCollection();
      res.json(result);
    } catch (err: any) {
      res.status(500).json({
        success: false,
        message: err.message || '수집 실행 중 오류가 발생했습니다.',
      });
    }
  });

  // 3. 메일 수집 상태 및 실시간 로그 조회 API
  app.get('/api/collect/status', (req: Request, res: Response) => {
    try {
      const collector = CollectorService.getInstance();
      const since = req.query.since as string | undefined;
      const status = collector.getStatus();

      if (since) {
        res.json({
          ...status,
          logs: collector.getLogs(since),
        });
      } else {
        res.json(status);
      }
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: err.message,
      });
    }
  });

  // 4. 세금계산서 발행 프로세스(/api/invoice/issue, /api/invoice/status)는 adminRoutes.ts 에서 등록한다.

  // 5. 특정 발전월 데이터 삭제 API
  app.delete('/api/data/period', (req: Request, res: Response) => {
    try {
      const { folderId, generationPeriod } = req.body;
      if (!folderId || !generationPeriod) {
        res.status(400).json({
          success: false,
          message: 'folderId 및 generationPeriod 파라미터가 필요합니다.',
        });
        return;
      }
      const config = loadConfig();
      const storage = new DataStorage(config.options.outputDir);
      const deleted = storage.deletePeriodData(folderId, generationPeriod);

      res.json({
        success: deleted,
        message: deleted
          ? `[${generationPeriod}] 발전 데이터가 성공적으로 삭제되었습니다.`
          : `삭제할 발전 데이터를 찾지 못했습니다.`,
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: err.message || '데이터 삭제 중 오류가 발생했습니다.',
      });
    }
  });

  app.post('/api/data/period/delete', (req: Request, res: Response) => {
    try {
      const { folderId, generationPeriod } = req.body;
      if (!folderId || !generationPeriod) {
        res.status(400).json({
          success: false,
          message: 'folderId 및 generationPeriod 파라미터가 필요합니다.',
        });
        return;
      }
      const config = loadConfig();
      const storage = new DataStorage(config.options.outputDir);
      const deleted = storage.deletePeriodData(folderId, generationPeriod);

      res.json({
        success: deleted,
        message: deleted
          ? `[${generationPeriod}] 발전 데이터가 성공적으로 삭제되었습니다.`
          : `삭제할 발전 데이터를 찾지 못했습니다.`,
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: err.message || '데이터 삭제 중 오류가 발생했습니다.',
      });
    }
  });

  // 사업자 / 발전소 관리 API
  registerAdminRoutes(app);

  // SPA fallback
  app.use((_req: Request, res: Response) => {
    res.sendFile(path.join(publicDir, 'index.html'));
  });

  return app;
}

export function startServer(port: number = 3000) {
  const app = createServer();
  const host = listenHost();
  return app.listen(port, host, () => {
    console.log(`====================================================`);
    console.log(`  🌐 세금계산서 자동 발행 웹 관리자 패널 실행`);
    console.log(`  - 접속 URL: http://localhost:${port}`);
    if (!isLoopbackHost(host)) {
      console.log(`  ⚠️ HOST=${host} 로 열려 있어 같은 네트워크의 다른 기기에서도 접속할 수 있습니다.`);
      console.log(`     인증서/비밀번호가 저장되므로 신뢰할 수 있는 네트워크에서만 사용하세요.`);
    }
    console.log(`====================================================`);
  });
}
