// 업데이트 파일 서명을 확인하는 공개 키(Ed25519). `npm run release:keygen` 이 만들어 이 파일을 채운다.
export const UPDATE_PUBLIC_KEY_PEM = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAfYNGshkVXygBtv8ZVipd2Swcq6LcFjHFMpE3vNPyvTI=
-----END PUBLIC KEY-----
`;
