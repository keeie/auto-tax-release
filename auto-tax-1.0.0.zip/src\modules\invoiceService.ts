import { loadConfig } from '../config';
import { CollectionLog } from '../types';
import { CertificateMaterial, loadCertificateMaterial } from './certStore';
import { HometaxError, HometaxSession, LogFn, launchHometaxBrowser, loginHometax } from './hometax';
import { buildInvoiceDraft, fillInvoiceForm, InvoiceDraft } from './hometaxInvoice';
import { HttpError, RegistryStorage } from './registry';
import { DataStorage } from './storage';

/**
 * 세금계산서 발행 프로세스.
 *
 * 현재 구현 범위: 발전소 → 소속 사업자 → 등록된 공동인증서 확인 → 홈택스 로그인 →
 * 건별발급 화면에서 발행정보 입력까지. 입력을 마치면 브라우저를 열어 둔 채 멈춘다(발급 버튼은 사용자가 직접 누름).
 * 입력값(발전량·단가·공급가액·세액)은 화면에서 보낸 값이 아니라 서버에 저장된 수집 데이터에서 읽는다.
 */

export interface InvoiceRequest {
  folderId?: unknown;
  businessName?: unknown;
  plantName?: unknown;
  generationPeriod?: unknown;
  supplyAmount?: unknown;
  taxAmount?: unknown;
  totalAmount?: unknown;
}

export interface InvoiceStatus {
  status: 'idle' | 'running' | 'completed' | 'error';
  stage?: 'hometax-logged-in' | 'invoice-filled';
  startedAt?: string;
  finishedAt?: string;
  progressMessage?: string;
  error?: string;
  errorCode?: string;
  browserOpen: boolean;
  request?: { folderId: string; plantName: string; operatorName: string; generationPeriod?: string };
  logs: CollectionLog[];
}

export interface StartOptions {
  outputDir: string;
  configPath?: string;
  // 테스트에서 실제 브라우저 없이 흐름을 검증하기 위한 주입 지점
  launch?: () => Promise<HometaxSession>;
  login?: (session: HometaxSession, material: CertificateMaterial, log: LogFn) => Promise<void>;
  fillInvoice?: (session: HometaxSession, draft: InvoiceDraft, log: LogFn) => Promise<void>;
  now?: () => Date;
}

const text = (v: unknown, max = 200) => (typeof v === 'string' ? v.replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max) : '');

export class InvoiceService {
  private static instance: InvoiceService;

  public static getInstance(): InvoiceService {
    if (!InvoiceService.instance) InvoiceService.instance = new InvoiceService();
    return InvoiceService.instance;
  }

  private state: Omit<InvoiceStatus, 'logs' | 'browserOpen'> = { status: 'idle' };
  private logs: CollectionLog[] = [];
  private running = false;
  private session: HometaxSession | null = null;
  private currentRun: Promise<void> = Promise.resolve();
  // 비밀번호 오류로 실패한 인증서(등록 시각 기준). 같은 인증서로 다시 시도하면 오류 횟수가 쌓여 잠길 수 있으므로 막는다.
  private passwordBlocked = new Map<string, string>();

  /** 데이터 초기화 때 호출한다. 실행 중이 아닐 때만 쓰며, 비밀번호 차단 목록과 로그를 비운다. */
  public resetState() {
    this.state = { status: 'idle' };
    this.logs = [];
    this.passwordBlocked.clear();
  }

  public getStatus(since?: string): InvoiceStatus {
    return {
      ...this.state,
      browserOpen: !!this.session && this.session.browser.isConnected(),
      logs: since ? this.logs.filter((l) => l.timestamp > since) : [...this.logs],
    };
  }

  public waitForCompletion(): Promise<void> {
    return this.currentRun;
  }

  private log: LogFn = (message, level = 'info') => {
    this.logs.push({ timestamp: new Date().toISOString(), message, level });
    if (this.logs.length > 300) this.logs.shift();
    this.state.progressMessage = message;
    const prefix = level === 'error' ? '❌' : level === 'warn' ? '⚠️' : level === 'success' ? '✅' : 'ℹ️';
    console.log(`[Invoice] ${prefix} ${message}`);
  };

  public async closeSession() {
    const s = this.session;
    this.session = null;
    if (s) await s.browser.close().catch(() => {});
  }

  /** 요청을 검증하고 백그라운드로 프로세스를 시작한다. 검증에 실패하면 HttpError 를 던진다. */
  public start(input: InvoiceRequest, opts: StartOptions): { message: string } {
    if (this.running) throw new HttpError(409, '이미 세금계산서 발행(홈택스 로그인) 작업이 진행 중입니다.');

    const folderId = text(input.folderId, 20);
    if (!folderId) throw new HttpError(400, '발전소 정보(folderId)가 없어 세금계산서 발행을 시작할 수 없습니다.');

    const folder = loadConfig(opts.configPath).folders.find((f) => f.folderId === folderId);
    if (!folder) throw new HttpError(404, '등록되지 않은 발전소입니다.');

    const registry = new RegistryStorage(opts.outputDir);
    const record = registry.getPlantRecord(folderId);
    const operator = record?.operatorId ? registry.getOperator(record.operatorId) : undefined;
    if (!operator) {
      throw new HttpError(400, `[${folder.businessName}] 발전소에 소속 사업자가 지정되어 있지 않습니다. '사업자/발전소 관리'에서 소속 사업자를 지정해 주세요.`);
    }
    const cert = operator.certificate;
    if (!cert) {
      throw new HttpError(400, `[${operator.businessName}] 사업자에 공동인증서가 등록되어 있지 않습니다. '사업자/발전소 관리 → 사업자 목록 → 수정'에서 인증서를 등록해 주세요.`);
    }
    if (cert.validTo && new Date(cert.validTo).getTime() < Date.now()) {
      throw new HttpError(400, `등록된 인증서가 만료되었습니다. (만료일: ${cert.validTo.slice(0, 10)}) 갱신한 인증서를 다시 등록해 주세요.`);
    }
    if (this.passwordBlocked.get(operator.id) === cert.updatedAt) {
      throw new HttpError(
        409,
        '이전 로그인에서 인증서 비밀번호 오류가 발생했습니다. 같은 비밀번호로 반복 시도하면 인증서가 잠길 수 있어 막아 두었습니다. 사업자 수정 화면에서 비밀번호를 다시 등록한 뒤 시도해 주세요.'
      );
    }

    const generationPeriod = text(input.generationPeriod, 60);
    if (!generationPeriod) throw new HttpError(400, '발전 기간(generationPeriod)이 없어 세금계산서 발행을 시작할 수 없습니다.');
    const period = new DataStorage(opts.outputDir)
      .getAllBusinessesData()
      .businesses.find((b) => b.folderId === folderId)
      ?.periods.find((p) => p.generationPeriod === generationPeriod);
    if (!period) throw new HttpError(404, `[${folder.businessName}] 발전소의 ${generationPeriod} 수집 데이터를 찾을 수 없습니다.`);
    if (registry.getInvoiceIssue(folderId, generationPeriod)?.issued) {
      throw new HttpError(409, `[${generationPeriod}] 은(는) 이미 세금계산서 발행 완료로 표시되어 있습니다. 다시 발행하려면 먼저 발행 여부를 '미발행'으로 바꿔 주세요.`);
    }
    if (period.items.length !== 1) {
      throw new HttpError(400, `[${generationPeriod}] 명세서가 ${period.items.length}건이라 세금계산서 1장에 넣을 값을 정할 수 없습니다.`);
    }
    const gen = period.items[0].generationData;
    let draft: InvoiceDraft;
    try {
      draft = buildInvoiceDraft(
        {
          generationPeriod,
          generationAmount: gen.generationAmount ?? NaN,
          basePrice: gen.basePrice ?? NaN,
          supplyAmount: gen.supplyAmount ?? NaN,
          taxAmount: gen.taxAmount ?? NaN,
        },
        (opts.now ?? (() => new Date()))()
      );
    } catch (err: any) {
      throw new HttpError(400, `[${generationPeriod}] 명세서 값으로 세금계산서를 작성할 수 없습니다: ${err.message}`);
    }

    this.running = true;
    this.logs = [];
    this.state = {
      status: 'running',
      startedAt: new Date().toISOString(),
      request: {
        folderId,
        plantName: folder.businessName,
        operatorName: operator.businessName,
        generationPeriod,
      },
    };

    this.currentRun = this.run(folder.businessName, operator.id, operator.businessName, cert.updatedAt, draft, opts);
    return { message: '세금계산서 발행 프로세스를 시작했습니다. 홈택스 로그인부터 진행합니다.' };
  }

  private async run(
    plantName: string,
    operatorId: string,
    operatorName: string,
    certUpdatedAt: string,
    draft: InvoiceDraft,
    opts: StartOptions
  ) {
    let material: CertificateMaterial | null = null;
    try {
      this.log(`발전소 [${plantName}] / 사업자 [${operatorName}] 세금계산서 발행 프로세스를 시작합니다.`);
      this.log('등록된 공동인증서 정보를 불러옵니다.');
      material = await loadCertificateMaterial(operatorId);

      await this.closeSession(); // 이전 실행에서 열어 둔 브라우저 정리
      this.log('홈택스 로그인용 새 브라우저를 실행합니다.');
      const session = await (opts.launch ?? launchHometaxBrowser)();
      this.session = session;

      await (opts.login ?? loginHometax)(session, material, this.log);
      material = null; // 로그인 이후에는 비밀번호가 필요 없다
      this.state = { ...this.state, stage: 'hometax-logged-in' };

      await (opts.fillInvoice ?? fillInvoiceForm)(session, draft, this.log);

      this.state = {
        ...this.state,
        status: 'completed',
        stage: 'invoice-filled',
        finishedAt: new Date().toISOString(),
      };
      this.log('발행정보 입력까지 완료했습니다. 발급 버튼은 누르지 않았습니다. 열려 있는 브라우저에서 내용을 확인한 뒤 직접 발급해 주세요.', 'warn');
    } catch (err: any) {
      const code = err instanceof HometaxError ? err.code : 'error';
      const message = String(err?.message || err);
      this.log(`세금계산서 발행 중단: ${message}`, 'error');
      this.state = { ...this.state, status: 'error', error: message, errorCode: code, finishedAt: new Date().toISOString() };
      if (code === 'wrong-password') this.passwordBlocked.set(operatorId, certUpdatedAt);
      if (!(err instanceof HometaxError && err.keepBrowserOpen)) await this.closeSession();
    } finally {
      material = null; // 비밀번호 참조를 즉시 버린다
      this.running = false;
    }
  }
}
