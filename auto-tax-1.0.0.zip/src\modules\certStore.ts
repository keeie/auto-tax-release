import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import tls from 'tls';
import { CertificateMeta, Operator } from '../types/registry';
import { HttpError, RegistryStorage } from './registry';
import { PfxPasswordError, readPfxCertificate } from './pfx';
import { decryptSecret, encryptSecret, getSecretsDir } from './secretBox';

/**
 * 사업자별 공동인증서(공인인증서) 보관소.
 *
 * secrets/certs/<사업자ID>/ 아래에 인증서 파일과 암호화된 비밀번호(password.enc)를 둔다.
 * - NPKI : signCert.der + signPri.key
 * - PFX  : cert.pfx (.pfx/.p12 업로드)
 * 파일 이름은 클라이언트가 보낸 이름을 쓰지 않고 위의 고정 이름으로 저장한다(경로 조작 방지).
 */

const MAX_FILE_BYTES = 40 * 1024; // 인증서 파일은 보통 수 KB. 요청 본문 한도(100KB) 안에서 두 파일이 들어가도록 제한
const MAX_PASSWORD_LENGTH = 256;
const ID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

type CertKind = 'npki' | 'pfx';
interface UploadedFile {
  name: string;
  data: Buffer;
}
export interface CertificateInput {
  files?: unknown;
  password?: unknown;
}

const NPKI_CERT = 'signCert.der';
const NPKI_KEY = 'signPri.key';
const PFX_FILE = 'cert.pfx';
const PASSWORD_FILE = 'password.enc';

function certDir(operatorId: string): string {
  if (!ID_RE.test(operatorId)) throw new HttpError(400, '잘못된 사업자 ID입니다.');
  return path.join(getSecretsDir(), 'certs', operatorId);
}

const ext = (name: string) => path.extname(name).toLowerCase();
const displayName = (name: string) => name.replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, 100);

// ---------- 업로드 파싱/분류 ----------

function parseUploads(raw: unknown): UploadedFile[] {
  if (!Array.isArray(raw)) throw new HttpError(400, '인증서 파일 형식이 올바르지 않습니다.');
  if (raw.length === 0 || raw.length > 2) throw new HttpError(400, '인증서 파일은 1~2개를 선택해 주세요.');
  return raw.map((f: any) => {
    if (!f || typeof f.name !== 'string' || typeof f.data !== 'string') {
      throw new HttpError(400, '인증서 파일 형식이 올바르지 않습니다.');
    }
    const data = Buffer.from(f.data, 'base64');
    if (data.length === 0) throw new HttpError(400, `비어 있는 파일입니다: ${displayName(f.name)}`);
    if (data.length > MAX_FILE_BYTES) {
      throw new HttpError(400, `인증서 파일이 너무 큽니다(최대 ${MAX_FILE_BYTES / 1024}KB): ${displayName(f.name)}`);
    }
    return { name: f.name, data };
  });
}

function classify(files: UploadedFile[]): { kind: CertKind; stored: Record<string, Buffer>; fileNames: string[] } {
  const ders = files.filter((f) => ext(f.name) === '.der');
  const keys = files.filter((f) => ext(f.name) === '.key');
  const pfxs = files.filter((f) => ['.pfx', '.p12'].includes(ext(f.name)));
  if (ders.length + keys.length + pfxs.length !== files.length) {
    throw new HttpError(400, '지원하지 않는 파일이 포함되어 있습니다. .der, .key, .pfx, .p12 파일만 선택할 수 있습니다.');
  }
  if (files.some((f) => /^km(cert|pri)/i.test(path.basename(f.name)))) {
    throw new HttpError(400, 'kmCert.der / kmPri.key 는 암호화용 인증서입니다. signCert.der 와 signPri.key 를 선택해 주세요.');
  }
  const fileNames = files.map((f) => displayName(path.basename(f.name)));
  if (files.length === 1 && pfxs.length === 1) {
    return { kind: 'pfx', stored: { [PFX_FILE]: pfxs[0].data }, fileNames };
  }
  if (files.length === 2 && ders.length === 1 && keys.length === 1) {
    return { kind: 'npki', stored: { [NPKI_CERT]: ders[0].data, [NPKI_KEY]: keys[0].data }, fileNames };
  }
  throw new HttpError(400, 'signCert.der 와 signPri.key 두 파일을 함께 선택하거나, .pfx/.p12 파일 1개를 선택해 주세요.');
}

// ---------- 검증 ----------

const WRONG_PASSWORD_RE = /bad decrypt|bad_decrypt|bad password|mac verify|wrong final block|interrupted or cancelled/i;
const BROKEN_FILE_RE = /asn1|wrong tag|nested|too long|not enough data|header too long|no start line/i;

const cnOf = (dn: string): string => {
  const lines = dn.split('\n');
  const pick = (key: string) => lines.find((l) => l.startsWith(`${key}=`))?.slice(key.length + 1).trim();
  return pick('CN') || pick('O') || dn.replace(/\n/g, ', ');
};
const toIso = (s: string): string => {
  const d = new Date(s);
  return Number.isNaN(d.getTime()) ? '' : d.toISOString();
};

interface Verification {
  subject: string;
  issuer: string;
  validFrom: string;
  validTo: string;
  passwordVerified: boolean | null;
  keyMatchesCert: boolean | null;
}

function verifyNpki(certDer: Buffer, keyFile: Buffer, password: string): Verification {
  let x509: crypto.X509Certificate;
  try {
    x509 = new crypto.X509Certificate(certDer);
  } catch {
    throw new HttpError(400, 'signCert.der 파일을 인증서로 읽을 수 없습니다. 파일이 맞는지 확인해 주세요.');
  }
  if (new Date(x509.validTo).getTime() < Date.now()) {
    throw new HttpError(400, `만료된 인증서입니다. (만료일: ${toIso(x509.validTo).slice(0, 10)})`);
  }

  const isPem = keyFile.subarray(0, 10).toString('latin1').startsWith('-----BEGIN');
  if (!isPem && keyFile[0] !== 0x30) {
    throw new HttpError(400, 'signPri.key 파일 형식이 올바르지 않습니다.');
  }

  let passwordVerified: boolean | null = null;
  let keyMatchesCert: boolean | null = null;
  try {
    const priv = isPem
      ? crypto.createPrivateKey({ key: keyFile, passphrase: password })
      : crypto.createPrivateKey({ key: keyFile, format: 'der', type: 'pkcs8', passphrase: password });
    passwordVerified = true;
    const fromKey = crypto.createPublicKey(priv).export({ type: 'spki', format: 'der' });
    const fromCert = x509.publicKey.export({ type: 'spki', format: 'der' });
    keyMatchesCert = Buffer.compare(fromKey, fromCert) === 0;
    if (!keyMatchesCert) {
      throw new HttpError(400, 'signCert.der 와 signPri.key 가 서로 짝이 맞지 않습니다. 같은 인증서의 파일을 선택해 주세요.');
    }
  } catch (err: any) {
    if (err instanceof HttpError) throw err;
    const msg = `${err?.code ?? ''} ${err?.message ?? ''}`;
    if (WRONG_PASSWORD_RE.test(msg)) throw new HttpError(400, '인증서 비밀번호가 올바르지 않습니다.');
    if (BROKEN_FILE_RE.test(msg)) throw new HttpError(400, 'signPri.key 파일 형식이 올바르지 않습니다.');
    // SEED 등 서버(Node/OpenSSL)가 지원하지 않는 암호화 방식: 비밀번호를 확인할 수 없다.
    passwordVerified = null;
    keyMatchesCert = null;
  }

  return {
    subject: cnOf(x509.subject),
    issuer: cnOf(x509.issuer),
    validFrom: toIso(x509.validFrom),
    validTo: toIso(x509.validTo),
    passwordVerified,
    keyMatchesCert,
  };
}

function verifyPfx(pfx: Buffer, password: string): Verification {
  // 1) PKCS#12 를 직접 풀어 인증서(소유자명·만료일)까지 읽는다. 홈택스 인증서 선택창과 맞춰보는 데 필요하다.
  try {
    const { certDer } = readPfxCertificate(pfx, password);
    const x509 = new crypto.X509Certificate(certDer);
    if (new Date(x509.validTo).getTime() < Date.now()) {
      throw new HttpError(400, `만료된 인증서입니다. (만료일: ${toIso(x509.validTo).slice(0, 10)})`);
    }
    return {
      subject: cnOf(x509.subject),
      issuer: cnOf(x509.issuer),
      validFrom: toIso(x509.validFrom),
      validTo: toIso(x509.validTo),
      passwordVerified: true,
      keyMatchesCert: null,
    };
  } catch (err) {
    if (err instanceof HttpError) throw err;
    if (err instanceof PfxPasswordError) throw new HttpError(400, '인증서 비밀번호가 올바르지 않습니다.');
    // 지원하지 않는 방식이면 아래의 기본 검사(Node TLS)로 넘어간다.
  }

  // 2) 기본 검사: 비밀번호만 확인한다(소유자명·만료일은 알 수 없음).
  let passwordVerified: boolean | null = null;
  try {
    tls.createSecureContext({ pfx, passphrase: password });
    passwordVerified = true;
  } catch (err: any) {
    const msg = `${err?.code ?? ''} ${err?.message ?? ''}`;
    if (WRONG_PASSWORD_RE.test(msg)) throw new HttpError(400, '인증서 비밀번호가 올바르지 않습니다.');
    if (BROKEN_FILE_RE.test(msg) || /pkcs12|pfx/i.test(msg) && !/unsupported/i.test(msg)) {
      throw new HttpError(400, 'PFX/P12 파일을 읽을 수 없습니다. 파일이 맞는지 확인해 주세요.');
    }
    passwordVerified = null; // 오래된 암호화 방식 등 서버가 지원하지 않는 형식
  }
  return { subject: '', issuer: '', validFrom: '', validTo: '', passwordVerified, keyMatchesCert: null };
}

// ---------- 저장소 입출력 ----------

function readStored(dir: string, kind: CertKind): Record<string, Buffer> {
  const names = kind === 'pfx' ? [PFX_FILE] : [NPKI_CERT, NPKI_KEY];
  const out: Record<string, Buffer> = {};
  for (const n of names) {
    const p = path.join(dir, n);
    if (!fs.existsSync(p)) throw new HttpError(409, '저장된 인증서 파일을 찾을 수 없습니다. 인증서를 다시 등록해 주세요.');
    out[n] = fs.readFileSync(p);
  }
  return out;
}

function writeSecretFile(p: string, data: Buffer | string) {
  fs.writeFileSync(p, data, { mode: 0o600 });
}

/** 인증서 폴더를 통째로 교체한다. 실패하면 기존 폴더를 되돌린다. */
function replaceDir(dir: string, files: Record<string, Buffer>, passwordToken: string) {
  const tmp = `${dir}.tmp-${crypto.randomBytes(4).toString('hex')}`;
  const bak = `${dir}.bak-${crypto.randomBytes(4).toString('hex')}`;
  fs.mkdirSync(tmp, { recursive: true });
  try {
    for (const [name, data] of Object.entries(files)) writeSecretFile(path.join(tmp, name), data);
    writeSecretFile(path.join(tmp, PASSWORD_FILE), passwordToken);
    const hadOld = fs.existsSync(dir);
    if (hadOld) fs.renameSync(dir, bak);
    try {
      fs.renameSync(tmp, dir);
    } catch (err) {
      if (hadOld) fs.renameSync(bak, dir);
      throw err;
    }
    if (hadOld) fs.rmSync(bak, { recursive: true, force: true });
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
}

// ---------- 공개 API ----------

/**
 * 인증서 등록/갱신.
 * - files 가 있으면 파일과 비밀번호를 함께 등록한다.
 * - files 가 없으면 이미 등록된 인증서에 대해 비밀번호만 다시 확인하고 교체한다.
 */
export async function saveOperatorCertificate(
  registry: RegistryStorage,
  operatorId: string,
  input: CertificateInput
): Promise<Operator> {
  const dir = certDir(operatorId);
  const op = registry.getOperator(operatorId);
  if (!op) throw new HttpError(404, '사업자를 찾을 수 없습니다.');

  const password = typeof input.password === 'string' ? input.password : '';
  if (!password) throw new HttpError(400, '인증서 비밀번호를 입력해 주세요.');
  if (password.length > MAX_PASSWORD_LENGTH || password.includes('\u0000')) {
    throw new HttpError(400, '인증서 비밀번호 형식이 올바르지 않습니다.');
  }

  let kind: CertKind;
  let stored: Record<string, Buffer>;
  let fileNames: string[];
  let replaceFiles: boolean;

  if (input.files !== undefined && input.files !== null) {
    ({ kind, stored, fileNames } = classify(parseUploads(input.files)));
    replaceFiles = true;
  } else {
    if (!op.certificate) throw new HttpError(400, '등록된 인증서가 없습니다. 인증서 파일을 선택해 주세요.');
    kind = op.certificate.kind;
    fileNames = op.certificate.fileNames;
    stored = readStored(dir, kind);
    replaceFiles = false;
  }

  const v = kind === 'pfx' ? verifyPfx(stored[PFX_FILE], password) : verifyNpki(stored[NPKI_CERT], stored[NPKI_KEY], password);
  const token = await encryptSecret(password);

  if (replaceFiles) {
    replaceDir(dir, stored, token);
  } else {
    writeSecretFile(path.join(dir, PASSWORD_FILE), token);
  }

  const now = new Date().toISOString();
  const meta: CertificateMeta = {
    kind,
    fileNames,
    subject: v.subject,
    issuer: v.issuer,
    validFrom: v.validFrom,
    validTo: v.validTo,
    passwordSaved: true,
    passwordVerified: v.passwordVerified,
    keyMatchesCert: v.keyMatchesCert,
    registeredAt: op.certificate?.registeredAt ?? now,
    updatedAt: now,
  };
  return registry.setCertificate(operatorId, meta);
}

export function removeOperatorCertificate(registry: RegistryStorage, operatorId: string): Operator {
  const dir = certDir(operatorId);
  if (!registry.getOperator(operatorId)) throw new HttpError(404, '사업자를 찾을 수 없습니다.');
  fs.rmSync(dir, { recursive: true, force: true });
  return registry.setCertificate(operatorId, null);
}

export interface CertificateMaterial {
  kind: CertKind;
  /** NPKI: signCert(DER) + signPri(암호화된 개인키 DER) / PFX: pfx */
  files: { signCert?: Buffer; signPri?: Buffer; pfx?: Buffer };
  password: string;
}

/**
 * 홈택스 인증 등 서버 내부 작업에서 쓰기 위한 함수. 비밀번호가 평문으로 반환되므로
 * HTTP 응답이나 로그로 내보내지 말 것(어떤 API 라우트에도 연결하지 않았다).
 */
export async function loadCertificateMaterial(operatorId: string): Promise<CertificateMaterial> {
  const dir = certDir(operatorId);
  const passwordFile = path.join(dir, PASSWORD_FILE);
  if (!fs.existsSync(passwordFile)) throw new HttpError(404, '등록된 인증서가 없습니다.');
  const password = await decryptSecret(fs.readFileSync(passwordFile, 'utf-8'));

  if (fs.existsSync(path.join(dir, PFX_FILE))) {
    return { kind: 'pfx', files: { pfx: fs.readFileSync(path.join(dir, PFX_FILE)) }, password };
  }
  const stored = readStored(dir, 'npki');
  return { kind: 'npki', files: { signCert: stored[NPKI_CERT], signPri: stored[NPKI_KEY] }, password };
}
