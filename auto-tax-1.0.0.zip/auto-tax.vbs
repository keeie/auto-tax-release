' auto-tax 제어 패널을 콘솔 창 없이 실행한다. 이 파일을 더블클릭하면 된다.
Set sh = CreateObject("WScript.Shell")
dir = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\"))
sh.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & dir & "launcher.ps1""", 0, False
