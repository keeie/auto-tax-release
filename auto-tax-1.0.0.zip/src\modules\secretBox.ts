import crypto from 'crypto';
import { execFile } from 'child_process';
import fs from 'fs';
import path from 'path';

/**
 * 인증서 비밀번호 같은 비밀값을 디스크에 저장하기 위한 암호화 모듈.
 *
 * - Windows(기본): DPAPI(현재 Windows 사용자 계정에 묶인 암호화). 키 파일이 따로 없고,
 *   다른 Windows 계정이나 다른 PC에서는 복호화되지 않는다.
 * - 그 외 OS 또는 AUTOTAX_MASTER_KEY 지정 시: AES-256-GCM. 키는 환경변수(64자리 hex) 또는
 *   secrets/master.key(자동 생성, 권한 600)에서 읽는다.
 *
 * 저장 형식은 접두어로 구분한다: "dpapi:v1:<base64>" / "aes:v1:<iv>:<tag>:<ciphertext>"
 */

export function getSecretsDir(): string {
  return process.env.AUTOTAX_SECRETS_DIR
    ? path.resolve(process.env.AUTOTAX_SECRETS_DIR)
    : path.resolve(process.cwd(), 'secrets');
}

// ---------- Windows DPAPI ----------

const DPAPI_ENTROPY = 'auto-tax:secret:v1';

function runPowerShell(script: string, stdin: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const child = execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script],
      { windowsHide: true, timeout: 30_000, maxBuffer: 1024 * 1024 },
      (err, stdout, stderr) => {
        if (err) {
          // 비밀값은 stdin 으로만 전달되므로 오류 메시지에 포함되지 않는다.
          reject(new Error(`DPAPI 처리에 실패했습니다: ${String(stderr || err.message).trim()}`));
          return;
        }
        resolve(String(stdout).trim());
      }
    );
    // 비밀값을 base64(ASCII)로 stdin 에 전달: 명령줄에 노출되지 않고 콘솔 코드페이지 영향도 받지 않는다.
    child.stdin?.end(stdin);
  });
}

const DPAPI_PREFIX =
  "Add-Type -AssemblyName System.Security; $e=[Text.Encoding]::UTF8.GetBytes('" +
  DPAPI_ENTROPY +
  "'); $b=[Convert]::FromBase64String(([Console]::In.ReadToEnd()).Trim()); ";

async function dpapiProtect(plain: Buffer): Promise<string> {
  const out = await runPowerShell(
    DPAPI_PREFIX + "[Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Protect($b,$e,'CurrentUser'))",
    plain.toString('base64')
  );
  if (!/^[A-Za-z0-9+/=]+$/.test(out)) throw new Error('DPAPI 암호화 결과가 올바르지 않습니다.');
  return out;
}

async function dpapiUnprotect(cipherB64: string): Promise<Buffer> {
  const out = await runPowerShell(
    DPAPI_PREFIX + "[Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Unprotect($b,$e,'CurrentUser'))",
    cipherB64
  );
  return Buffer.from(out, 'base64');
}

// ---------- AES-256-GCM ----------

function loadAesKey(): Buffer {
  const fromEnv = process.env.AUTOTAX_MASTER_KEY;
  if (fromEnv) {
    if (!/^[0-9a-fA-F]{64}$/.test(fromEnv)) throw new Error('AUTOTAX_MASTER_KEY 는 64자리 hex 문자열이어야 합니다.');
    return Buffer.from(fromEnv, 'hex');
  }
  const dir = getSecretsDir();
  const keyFile = path.join(dir, 'master.key');
  if (fs.existsSync(keyFile)) {
    const hex = fs.readFileSync(keyFile, 'utf-8').trim();
    if (!/^[0-9a-fA-F]{64}$/.test(hex)) throw new Error(`${keyFile} 의 형식이 올바르지 않습니다.`);
    return Buffer.from(hex, 'hex');
  }
  fs.mkdirSync(dir, { recursive: true });
  const key = crypto.randomBytes(32);
  fs.writeFileSync(keyFile, key.toString('hex'), { mode: 0o600 });
  return key;
}

function aesEncrypt(plain: Buffer): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', loadAesKey(), iv);
  const ct = Buffer.concat([cipher.update(plain), cipher.final()]);
  return `${iv.toString('base64')}:${cipher.getAuthTag().toString('base64')}:${ct.toString('base64')}`;
}

function aesDecrypt(payload: string): Buffer {
  const [iv, tag, ct] = payload.split(':').map((p) => Buffer.from(p, 'base64'));
  if (!iv || !tag || !ct) throw new Error('저장된 비밀번호 형식이 올바르지 않습니다.');
  const decipher = crypto.createDecipheriv('aes-256-gcm', loadAesKey(), iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(ct), decipher.final()]);
}

// ---------- 공개 API ----------

export type SecretBackend = 'dpapi' | 'aes';

export function currentBackend(): SecretBackend {
  if (!process.env.AUTOTAX_MASTER_KEY && process.platform === 'win32') return 'dpapi';
  return 'aes';
}

export async function encryptSecret(plain: string): Promise<string> {
  const buf = Buffer.from(plain, 'utf-8');
  return currentBackend() === 'dpapi' ? `dpapi:v1:${await dpapiProtect(buf)}` : `aes:v1:${aesEncrypt(buf)}`;
}

export async function decryptSecret(token: string): Promise<string> {
  const trimmed = token.trim();
  if (trimmed.startsWith('dpapi:v1:')) {
    if (process.platform !== 'win32') {
      throw new Error('이 비밀번호는 Windows DPAPI로 암호화되어 있어 현재 환경에서는 복호화할 수 없습니다. 비밀번호를 다시 등록해 주세요.');
    }
    try {
      return (await dpapiUnprotect(trimmed.slice('dpapi:v1:'.length))).toString('utf-8');
    } catch {
      throw new Error('저장된 비밀번호를 복호화하지 못했습니다. 다른 Windows 계정이나 PC에서 등록한 값일 수 있으니 비밀번호를 다시 등록해 주세요.');
    }
  }
  if (trimmed.startsWith('aes:v1:')) {
    try {
      return aesDecrypt(trimmed.slice('aes:v1:'.length)).toString('utf-8');
    } catch {
      throw new Error('저장된 비밀번호를 복호화하지 못했습니다. 암호화 키가 바뀌었을 수 있으니 비밀번호를 다시 등록해 주세요.');
    }
  }
  throw new Error('알 수 없는 비밀번호 저장 형식입니다.');
}
