import fs from 'fs';
import path from 'path';
import { loadConfig, updateConfigFolders } from '../config';
import { CollectorService } from './collector';
import { InvoiceService } from './invoiceService';
import { getSecretsDir } from './secretBox';
import { HttpError } from './registry';

/**
 * 저장된 데이터를 모두 지우고 처음 상태로 되돌린다(되돌릴 수 없음).
 * - data/ 안의 발전소 폴더, 발전월 데이터, registry.json(사업자·발전소 정보·발행 여부), summary.json 삭제
 * - config.json 의 발전소 목록(folders) 비움 (옵션은 유지)
 * - secrets/certs(인증서·비밀번호), secrets/mail(메일 비밀번호) 삭제. secrets/master.key 는 유지
 * - 수집·발행이 진행 중이면 거부한다.
 */
export function resetAllData(configPath?: string): { removed: string[] } {
  if (CollectorService.getInstance().getStatus().status === 'running') {
    throw new HttpError(409, '메일 수집이 진행 중입니다. 끝난 뒤에 다시 시도해 주세요.');
  }
  const invoice = InvoiceService.getInstance().getStatus();
  if (invoice.status === 'running' || invoice.browserOpen) {
    throw new HttpError(409, '세금계산서 발행 작업이 진행 중입니다. 작업을 마치고 브라우저를 닫은 뒤 다시 시도해 주세요.');
  }

  const config = loadConfig(configPath);
  const dataDir = path.resolve(process.cwd(), config.options.outputDir);
  const projectDir = path.resolve(process.cwd());
  // 프로젝트 폴더 자체(또는 그 상위)를 지우는 설정 실수를 막는다.
  if (dataDir === projectDir || projectDir.startsWith(dataDir + path.sep)) {
    throw new HttpError(400, `데이터 폴더 설정(${config.options.outputDir})이 올바르지 않아 초기화하지 않습니다.`);
  }

  const removed: string[] = [];
  if (fs.existsSync(dataDir)) {
    for (const entry of fs.readdirSync(dataDir)) {
      fs.rmSync(path.join(dataDir, entry), { recursive: true, force: true });
      removed.push(`data/${entry}`);
    }
  }

  const secretsDir = getSecretsDir();
  for (const sub of ['certs', 'mail']) {
    const target = path.join(secretsDir, sub);
    if (fs.existsSync(target)) {
      fs.rmSync(target, { recursive: true, force: true });
      removed.push(`secrets/${sub}`);
    }
  }

  updateConfigFolders(() => [], configPath);
  removed.push('config.json folders');

  InvoiceService.getInstance().resetState();
  return { removed };
}
