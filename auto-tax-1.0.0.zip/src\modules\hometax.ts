import crypto from 'crypto';
import { Browser, BrowserContext, chromium, Page } from 'playwright';
import type { CertificateMaterial } from './certStore';
import { PfxPasswordError, readPfxCertificate } from './pfx';

/**
 * 홈택스 공동·금융인증서 로그인 자동화.
 *
 * 순서: 새 브라우저로 홈택스 접속 → 로그인 → 공동·금융인증서 → 인증서 선택창 대기 →
 *       등록된 인증서와 같은 인증서 선택 → 비밀번호 입력 후 확인 → 로그인 확인
 *
 * 주의
 * - 비밀번호는 입력에만 사용하며 로그/오류 메시지/예외에 포함하지 않는다.
 * - 비밀번호가 틀렸을 때 절대 재시도하지 않는다(홈택스/인증기관의 오류 횟수 누적으로 인증서가 잠길 수 있음).
 * - page.evaluate 는 tsx(esbuild) 변환 문제(__name)를 피하려고 문자열 스크립트로 실행한다.
 */

export const HOMETAX_URL = 'https://hometax.go.kr/';
const HOMETAX_ORIGIN = 'https://hometax.go.kr';

// 홈택스 화면 요소 (2026-10 기준, 직접 확인한 값)
const SEL = {
  headerLogin: '#mf_wfHeader_group1503',
  certLoginButton: '#mf_txppWframe_anchor22', // "공동·금융인증서" 로그인 버튼
  certFrame: 'iframe[name="dscert"]',
  certFrameName: 'dscert',
  certRows: '#tabledataTable tbody tr',
  hddTab: '#stg_hdd',
  passwordInput: '#input_cert_pw',
  confirmButton: '#btn_confirm_iframe',
};

export type HometaxErrorCode =
  | 'unsupported-cert'
  | 'cert-list-empty'
  | 'cert-not-found'
  | 'cert-ambiguous'
  | 'select-failed'
  | 'password-input'
  | 'wrong-password'
  | 'login-failed'
  | 'unknown-result'
  | 'page-error'
  // 로그인 이후 발행정보 입력 단계 (hometaxInvoice.ts)
  | 'menu-failed'
  | 'form-not-found'
  | 'partner-not-found'
  | 'partner-ambiguous'
  | 'form-mismatch';

export class HometaxError extends Error {
  constructor(
    public code: HometaxErrorCode,
    message: string,
    /** true 이면 사용자가 직접 확인할 수 있도록 브라우저를 닫지 않는다 */
    public keepBrowserOpen: boolean = false
  ) {
    super(message);
    this.name = 'HometaxError';
  }
}

export type LogLevel = 'info' | 'warn' | 'error' | 'success';
export type LogFn = (message: string, level?: LogLevel) => void;

export interface HometaxSession {
  browser: Browser;
  context: BrowserContext;
  page: Page;
  /** false 로 바꾸면 홈택스 팝업 창(popup.html)을 더 이상 자동으로 닫지 않는다. (로그인 이후 단계용) */
  autoClosePopups?: boolean;
}

// ---------- 인증서 매칭 (순수 함수: 테스트 가능) ----------

export interface ExpectedCert {
  commonName: string;
  expiry: string; // YYYY-MM-DD (한국 시간)
}
export interface CertRow {
  index: number;
  cells: string[];
}

const norm = (s: string) => s.replace(/\s+/g, '');
const tailDigits = (s: string) => norm(s).match(/(\d{12,})$/)?.[1];
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

/** 인증서 선택창 목록에서 등록된 인증서와 같은 행을 찾는다. */
export function pickMatchingRow(
  rows: CertRow[],
  expected: ExpectedCert
): { index: number; method: 'exact' | 'id-number' } | 'ambiguous' | null {
  const expiryOf = (r: CertRow) => r.cells.find((c) => DATE_RE.test(c.trim()))?.trim();

  // 1) 소유자명(CN) 전체와 만료일이 모두 같은 행. 같은 인증서가 저장 위치만 달라 중복되어 있어도 동일하므로 첫 행을 쓴다.
  const exact = rows.find((r) => norm(r.cells[0] ?? '') === norm(expected.commonName) && expiryOf(r) === expected.expiry);
  if (exact) return { index: exact.index, method: 'exact' };

  // 2) 표기가 조금 다를 때: 소유자명 끝의 고유번호(숫자 12자리 이상)와 만료일이 같은 행
  const expectedTail = tailDigits(expected.commonName);
  if (expectedTail) {
    const loose = rows.filter((r) => tailDigits(r.cells[0] ?? '') === expectedTail && expiryOf(r) === expected.expiry);
    if (loose.length === 1) return { index: loose[0].index, method: 'id-number' };
    if (loose.length > 1) return 'ambiguous';
  }
  return null;
}

const KST_DATE = new Intl.DateTimeFormat('en-CA', {
  timeZone: 'Asia/Seoul',
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
});

/** 등록된 인증서 파일에서 선택창 매칭에 쓸 값(소유자명 CN, 만료일)을 읽는다. */
export function describeCertificate(material: Pick<CertificateMaterial, 'kind' | 'files' | 'password'>): ExpectedCert {
  let certDer: Buffer;
  if (material.kind === 'npki' && material.files.signCert) {
    certDer = material.files.signCert;
  } else if (material.kind === 'pfx' && material.files.pfx) {
    try {
      certDer = readPfxCertificate(material.files.pfx, material.password).certDer;
    } catch (err) {
      throw new HometaxError(
        'unsupported-cert',
        err instanceof PfxPasswordError
          ? '저장된 비밀번호로 PFX 인증서를 열 수 없습니다. 인증서를 다시 등록해 주세요.'
          : 'PFX 파일에서 인증서 정보를 읽지 못했습니다. signCert.der + signPri.key 로 다시 등록해 주세요.'
      );
    }
  } else {
    throw new HometaxError('unsupported-cert', '등록된 인증서 파일을 찾을 수 없습니다. 인증서를 다시 등록해 주세요.');
  }
  let x509: crypto.X509Certificate;
  try {
    x509 = new crypto.X509Certificate(certDer);
  } catch {
    throw new HometaxError('unsupported-cert', '저장된 인증서를 읽을 수 없습니다. 인증서를 다시 등록해 주세요.');
  }
  const cn = x509.subject.split('\n').find((l) => l.startsWith('CN='))?.slice(3).trim();
  if (!cn) throw new HometaxError('unsupported-cert', '인증서에서 소유자명(CN)을 읽을 수 없습니다.');
  return { commonName: cn, expiry: KST_DATE.format(new Date(x509.validTo)) };
}

// ---------- 브라우저 ----------

export async function launchHometaxBrowser(slowMo: number = 100): Promise<HometaxSession> {
  // 인증서 선택창은 PC에 설치된 인증서 보안모듈과 통신하므로 headless 로는 쓸 수 없다.
  // 최대화하지 않고 일반 창으로 띄운다(viewport: null 이라 페이지는 창 크기를 따른다).
  const browser = await chromium.launch({
    headless: false,
    slowMo,
    args: ['--window-size=1280,900', '--window-position=80,40'],
  });
  const context = await browser.newContext({ viewport: null, locale: 'ko-KR', timezoneId: 'Asia/Seoul' });
  // 크롬의 "로컬 네트워크 접근" 권한 요청(하드디스크 인증서 읽기에 필요)을 미리 허용한다.
  await context.grantPermissions(['local-network-access' as any], { origin: HOMETAX_ORIGIN }).catch(() => {});
  const page = await context.newPage();
  const session: HometaxSession = { browser, context, page, autoClosePopups: true };
  // 로그인 안내용 팝업 창(예: 크롬·엣지 이용자 안내)은 자동으로 닫는다.
  // 로그인 이후에는 거래처 조회 등 필요한 팝업이 같은 주소로 열릴 수 있어 autoClosePopups 를 끈다.
  context.on('page', (p) => {
    p.waitForLoadState('domcontentloaded')
      .catch(() => {})
      .then(() => {
        if (session.autoClosePopups !== false && /\/websquare\/popup\.html/.test(p.url())) p.close().catch(() => {});
      });
  });
  return session;
}

// ---------- 화면 스크립트 ----------

const ROWS_SCRIPT = `(() => Array.prototype.map.call(document.querySelectorAll('#tabledataTable tbody tr'), function (tr, i) {
  return { index: i, cells: Array.prototype.map.call(tr.querySelectorAll('td'), function (td) { return (td.innerText || '').replace(/\\s+/g, ' ').trim(); }) };
}))()`;

const SELECTED_ROW_SCRIPT = `(() => {
  var trs = document.querySelectorAll('#tabledataTable tbody tr');
  for (var i = 0; i < trs.length; i++) {
    if (trs[i].querySelector('td[class*="MLjqui-grid-cell-selected"]')) return i;
  }
  return -1;
})()`;

const LOGGED_IN_SCRIPT = `(() => {
  var els = document.querySelectorAll('a, button, span, li');
  for (var i = 0; i < els.length; i++) {
    var r = els[i].getBoundingClientRect();
    if (r.width > 0 && r.height > 0 && (els[i].innerText || '').trim() === '로그아웃') return true;
  }
  return false;
})()`;

const BODY_TEXT_SCRIPT = `(() => (document.body && document.body.innerText) || '')()`;

const WRONG_PASSWORD_RE = /(비밀번호|암호).*(틀|올바르|오류|일치|잘못)|(틀|올바르|오류|일치|잘못).*(비밀번호|암호)/;
const LOCKED_RE = /(횟수|잠금|잠겼|폐기)/;

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// ---------- 로그인 ----------

export async function loginHometax(
  session: HometaxSession,
  material: CertificateMaterial,
  log: LogFn
): Promise<void> {
  const { page } = session;
  const expected = describeCertificate(material);

  const dialogMessages: string[] = [];
  const onDialog = (d: import('playwright').Dialog) => {
    dialogMessages.push(d.message());
    // 단순 안내(alert)만 닫고, 확인을 요구하는 대화상자는 임의로 승인하지 않는다.
    (d.type() === 'alert' ? d.accept() : d.dismiss()).catch(() => {});
  };
  page.on('dialog', onDialog);

  try {
    // 1. 홈택스 접속
    log('1. 새 브라우저로 홈택스에 접속합니다.');
    await page.goto(HOMETAX_URL, { waitUntil: 'domcontentloaded', timeout: 60_000 });

    // 2. 로그인 클릭
    log('2. 로그인 버튼을 클릭합니다.');
    await page.locator(SEL.headerLogin).waitFor({ state: 'visible', timeout: 30_000 });
    await page.locator(SEL.headerLogin).click();

    // 3. 공동·금융인증서 클릭 → 인증서 선택창 대기
    log('3. 공동·금융인증서를 클릭하고 인증서 선택창을 기다립니다.');
    await page.locator(SEL.certLoginButton).waitFor({ state: 'visible', timeout: 30_000 });
    await page.locator(SEL.certLoginButton).click();

    const frame = page.frameLocator(SEL.certFrame);
    const rowLocator = frame.locator(SEL.certRows);
    try {
      await rowLocator.first().waitFor({ state: 'visible', timeout: 90_000 });
    } catch {
      throw new HometaxError(
        'cert-list-empty',
        '인증서 선택창에 인증서 목록이 나타나지 않았습니다. 홈택스 통합설치 프로그램(인증서 보안모듈) 설치와 브라우저의 로컬 네트워크 접근 허용 여부를 확인해 주세요.',
        true
      );
    }

    const certFrame = () => page.frame({ name: SEL.certFrameName });
    const hddTitle = await frame.locator(SEL.hddTab).getAttribute('title').catch(() => null);
    if (hddTitle && !hddTitle.includes('선택됨')) {
      await frame.locator(SEL.hddTab).click();
      await rowLocator.first().waitFor({ state: 'visible', timeout: 30_000 }).catch(() => {});
    }

    // 4. 등록된 인증서와 같은 인증서 선택
    const rows = (await certFrame()!.evaluate(ROWS_SCRIPT)) as CertRow[];
    log(`4. 인증서 선택창에서 ${rows.length}개의 인증서를 확인했습니다. 등록된 인증서와 일치하는 항목을 찾습니다.`);
    const picked = pickMatchingRow(rows, expected);
    if (picked === 'ambiguous') {
      throw new HometaxError(
        'cert-ambiguous',
        '선택창에서 등록된 인증서와 비슷한 항목이 여러 개라 안전하게 고를 수 없습니다. 홈택스 로그인 화면에서 직접 선택해 주세요.',
        true
      );
    }
    if (!picked) {
      throw new HometaxError(
        'cert-not-found',
        `인증서 선택창(${rows.length}개)에서 등록된 인증서와 일치하는 항목을 찾지 못했습니다. 이 PC의 하드디스크/이동식 디스크에 같은 인증서가 있는지 확인해 주세요.`
      );
    }

    await rowLocator.nth(picked.index).locator('td').first().click();
    // 선택이 실제로 해당 행으로 바뀌었는지 확인한다(잘못된 인증서에 비밀번호를 입력하면 오류 횟수가 쌓일 수 있다).
    let selected = -1;
    for (let i = 0; i < 10; i++) {
      selected = (await certFrame()!.evaluate(SELECTED_ROW_SCRIPT)) as number;
      if (selected === picked.index) break;
      await sleep(300);
    }
    if (selected !== picked.index) {
      throw new HometaxError('select-failed', '인증서 선택을 확인하지 못했습니다. 비밀번호는 입력하지 않았습니다.', true);
    }
    log(`일치하는 인증서를 선택했습니다. (${picked.method === 'exact' ? '소유자명·만료일 일치' : '고유번호·만료일 일치'})`);

    // 5. 비밀번호 입력 후 확인
    log('5. 인증서 비밀번호를 입력합니다.');
    const pw = frame.locator(SEL.passwordInput);
    const typedLength = async () => pw.evaluate((el) => (el as HTMLInputElement).value.length);
    await pw.click();
    await pw.pressSequentially(material.password, { delay: 40 });
    if ((await typedLength()) !== material.password.length) {
      // 입력이 보안 키패드에 일부 가로채진 경우 한 번만 다시 입력한다(확인 버튼을 누르기 전이므로 안전).
      await pw.fill('');
      await pw.fill(material.password);
    }
    if ((await typedLength()) !== material.password.length) {
      await pw.fill('').catch(() => {});
      throw new HometaxError('password-input', '비밀번호가 입력창에 정확히 입력되지 않았습니다. 확인 버튼은 누르지 않았습니다.', true);
    }
    log('비밀번호 입력 후 확인 버튼을 클릭합니다.');
    const dialogsBefore = dialogMessages.length;
    await frame.locator(SEL.confirmButton).click();

    // 6. 로그인 완료 확인
    const deadline = Date.now() + 90_000;
    let seenDialogs = dialogsBefore;
    while (Date.now() < deadline) {
      if (page.isClosed()) throw new HometaxError('page-error', '브라우저 창이 닫혀 로그인 결과를 확인하지 못했습니다.');

      if ((await page.mainFrame().evaluate(LOGGED_IN_SCRIPT).catch(() => false)) === true) {
        log('6. 홈택스 로그인이 완료되었습니다.', 'success');
        return;
      }

      // 비밀번호 오류 등 안내 메시지(alert 또는 선택창 안의 문구) 감지
      const messages: string[] = dialogMessages.slice(seenDialogs);
      seenDialogs = dialogMessages.length;
      const inFrame = certFrame();
      if (inFrame) {
        const text = ((await inFrame.evaluate(BODY_TEXT_SCRIPT).catch(() => '')) as string).split('\n').map((s) => s.trim());
        messages.push(...text.filter((l) => l.length > 0 && l.length <= 150 && (WRONG_PASSWORD_RE.test(l) || LOCKED_RE.test(l))));
      }
      const problem = messages.find((m) => WRONG_PASSWORD_RE.test(m) || LOCKED_RE.test(m));
      if (problem) {
        throw new HometaxError(
          'wrong-password',
          `인증서 비밀번호 확인에 실패했습니다: ${problem.replace(/\s+/g, ' ').slice(0, 120)}\n오류가 반복되면 인증서가 잠길 수 있어 자동으로 다시 시도하지 않습니다. 비밀번호를 확인해 다시 등록해 주세요.`
        );
      }
      const other = messages.find((m) => m.trim().length > 0);
      if (other) {
        throw new HometaxError('login-failed', `홈택스에서 안내 메시지가 표시되었습니다: ${other.replace(/\s+/g, ' ').slice(0, 150)}`, true);
      }
      await sleep(500);
    }
    throw new HometaxError(
      'unknown-result',
      '90초 안에 로그인 결과를 확인하지 못했습니다. 열려 있는 브라우저에서 로그인 상태를 확인해 주세요.',
      true
    );
  } catch (err: any) {
    if (err instanceof HometaxError) throw err;
    // 오류 메시지에 입력값이 섞여 들어가더라도 비밀번호가 새어 나가지 않도록 지운다.
    let msg = String(err?.message || err).split('\n')[0].slice(0, 200);
    if (material.password) msg = msg.split(material.password).join('***');
    throw new HometaxError('page-error', `홈택스 화면 처리 중 오류가 발생했습니다: ${msg}`, true);
  } finally {
    page.off('dialog', onDialog);
  }
}
