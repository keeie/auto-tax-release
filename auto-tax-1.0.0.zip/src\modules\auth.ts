import { Page } from 'playwright';

export interface LoginOptions {
  id: string;
  password: string;
  timeoutMs?: number;
}

export async function loginNaver(page: Page, options: LoginOptions): Promise<boolean> {
  const { id, password, timeoutMs = 60000 } = options;

  if (!id || !password || id === 'YOUR_NAVER_ID' || password === 'YOUR_NAVER_PASSWORD') {
    throw new Error(
      '[Auth] 네이버 ID와 비밀번호가 없습니다. 발전소 관리에서 메일 정보를 입력해 주세요.'
    );
  }

  console.log('[Auth] 1. www.naver.com 접속 중...');
  await page.goto('https://www.naver.com', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(1000);

  console.log('[Auth] 2. NAVER 로그인 버튼 찾는 중...');
  // Find NAVER login button on the main page
  const loginButtonSelectors = [
    'a.link_login',
    'a[href*="nidlogin.login"]',
    'a:has-text("NAVER 로그인")',
    'a:has-text("로그인")',
    '.MyView-module__link_login___HpHMW',
  ];

  let clicked = false;
  for (const selector of loginButtonSelectors) {
    const el = page.locator(selector).first();
    if (await el.isVisible({ timeout: 1500 }).catch(() => false)) {
      console.log(`[Auth] 로그인 버튼 클릭: ${selector}`);
      await el.click();
      clicked = true;
      break;
    }
  }

  if (!clicked) {
    console.log('[Auth] 메인화면 로그인 버튼을 직접 찾지 못해 로그인 페이지로 직접 이동합니다.');
    await page.goto('https://nid.naver.com/nidlogin.login', { waitUntil: 'domcontentloaded' });
  }

  // Wait for login form to load
  await page.waitForSelector('#id', { timeout: 10000 });
  await page.waitForTimeout(500);

  console.log('[Auth] 3. 계정 정보 입력 중 (자동입력 방지 우회 처리)...');

  // Inject ID and PW via DOM evaluation to avoid Naver's automated bot detection captcha
  await page.evaluate(
    ({ uid, upw }) => {
      const idInput = document.querySelector('#id') as HTMLInputElement;
      const pwInput = document.querySelector('#pw') as HTMLInputElement;

      if (idInput) {
        idInput.focus();
        idInput.value = uid;
        idInput.dispatchEvent(new Event('input', { bubbles: true }));
        idInput.dispatchEvent(new Event('change', { bubbles: true }));
      }

      if (pwInput) {
        pwInput.focus();
        pwInput.value = upw;
        pwInput.dispatchEvent(new Event('input', { bubbles: true }));
        pwInput.dispatchEvent(new Event('change', { bubbles: true }));
      }
    },
    { uid: id, upw: password }
  );

  await page.waitForTimeout(500);

  // Click submit login button
  console.log('[Auth] 로그인 제출 버튼 클릭...');
  const submitSelectors = [
    'button.btn_login[type="submit"]',
    '#log\\.login',
    'button.btn_login',
    'button[type="submit"]',
    '.btn_login_wrap button',
    'button:has-text("로그인")',
    'input[type="submit"]',
  ];

  let submitted = false;
  for (const selector of submitSelectors) {
    try {
      const btn = page.locator(selector).first();
      if (await btn.isVisible({ timeout: 1000 }).catch(() => false)) {
        console.log(`[Auth] 로그인 제출 버튼 클릭: ${selector}`);
        await btn.click({ timeout: 3000 });
        submitted = true;
        break;
      }
    } catch {
      // 다음 셀렉터 시도
    }
  }

  if (!submitted) {
    console.log('[Auth] 버튼 클릭 실패 -> 엔터키 입력 및 직접 폼 제출 시도...');
    try {
      await page.locator('#pw').focus();
      await page.keyboard.press('Enter');
      submitted = true;
    } catch {
      await page.evaluate(() => {
        const submitBtn = document.querySelector('button[type="submit"], .btn_login, #log\\.login') as HTMLElement;
        if (submitBtn) {
          submitBtn.click();
        } else {
          const form = document.querySelector('form') as HTMLFormElement;
          if (form) form.submit();
        }
      });
    }
  }

  console.log('[Auth] 로그인 완료 대기 중...');

  // Handle post-login conditions: device registration or 2FA or successful navigation
  const startTime = Date.now();
  while (Date.now() - startTime < timeoutMs) {
    const currentUrl = page.url();

    // Check if redirected away from login page
    if (!currentUrl.includes('nidlogin.login')) {
      console.log('[Auth] 네이버 로그인 성공!');
      await page.waitForTimeout(1000);
      return true;
    }

    // Check if device registration prompt appeared ("새로운 기기 등록")
    const dontSaveBtn = page.locator('#new\\.dontsave, a:has-text("등록안함"), button:has-text("등록안함")').first();
    if (await dontSaveBtn.isVisible({ timeout: 500 }).catch(() => false)) {
      console.log('[Auth] 기기 등록 확인 팝업 감지 -> "등록안함" 클릭');
      await dontSaveBtn.click();
      await page.waitForTimeout(1000);
      continue;
    }

    // Check if captcha / 2FA is presented to the user
    const captchaImg = page.locator('#chptcha, #captcha, .captcha_wrap').first();
    const isCaptcha = await captchaImg.isVisible({ timeout: 200 }).catch(() => false);
    if (isCaptcha) {
      console.log('[Auth] 자동입력 방지 문자(캡차) 또는 2단계 인증이 표시되었습니다. 브라우저 창에서 직접 인증을 완료해주세요...');
    }

    await page.waitForTimeout(1000);
  }

  throw new Error(`[Auth] ${timeoutMs / 1000}초 내에 로그인이 완료되지 않았습니다.`);
}
