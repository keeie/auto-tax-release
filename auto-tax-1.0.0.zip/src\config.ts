import fs from 'fs';
import path from 'path';
import { AppConfig, FolderConfig } from './types';

const DEFAULT_CONFIG_PATH = path.resolve(process.cwd(), 'config.json');

/**
 * config.json: 발전소 목록(folders)과 수집 옵션. 메일 계정은 발전소 관리(registry.json + secrets/mail)에서 관리한다.
 * 파일이 없으면 빈 발전소 목록으로 새로 만든다.
 */
export function loadConfig(configPath: string = DEFAULT_CONFIG_PATH): AppConfig {
  if (!fs.existsSync(configPath)) {
    const defaultConfig: AppConfig = {
      folders: [],
      options: {
        headless: false,
        slowMo: 100,
        outputDir: './data',
        maxMailsPerFolder: 50,
        onlyUnread: false,
      },
    };
    fs.writeFileSync(configPath, JSON.stringify(defaultConfig, null, 2), 'utf-8');
    console.log(`[Config] '${configPath}' 파일이 없어 새로 만들었습니다. 발전소 관리에서 발전소를 등록해 주세요.`);
  }

  try {
    const rawData = fs.readFileSync(configPath, 'utf-8');
    const parsed = JSON.parse(rawData) as Partial<AppConfig>;

    return {
      folders: Array.isArray(parsed.folders) ? parsed.folders : [],
      options: {
        headless: parsed.options?.headless ?? false,
        slowMo: parsed.options?.slowMo ?? 100,
        outputDir: parsed.options?.outputDir ?? './data',
        maxMailsPerFolder: parsed.options?.maxMailsPerFolder ?? 50,
        onlyUnread: parsed.options?.onlyUnread ?? false,
        updateManifestUrl: parsed.options?.updateManifestUrl ?? '',
      },
    };
  } catch (err) {
    throw new Error(`[Config] 설정 파일(${configPath})을 읽는 도중 오류가 발생했습니다: ${err}`);
  }
}

/**
 * config.json 의 folders 항목만 수정한다. 다른 항목(옵션 등)은 원본 그대로 보존하도록
 * loadConfig 결과가 아닌 원본 JSON 을 직접 수정한다.
 */
export function updateConfigFolders(
  mutate: (folders: FolderConfig[]) => FolderConfig[],
  configPath: string = DEFAULT_CONFIG_PATH
): FolderConfig[] {
  loadConfig(configPath); // 파일이 없으면 템플릿 생성
  let raw: any;
  try {
    raw = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
  } catch (err) {
    throw new Error(`[Config] 설정 파일(${configPath})을 읽는 도중 오류가 발생했습니다: ${err}`);
  }
  const current: FolderConfig[] = Array.isArray(raw.folders) ? raw.folders : [];
  raw.folders = mutate(current.map((f) => ({ ...f })));

  const tmpPath = `${configPath}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(raw, null, 2), 'utf-8');
  fs.renameSync(tmpPath, configPath);
  return raw.folders;
}
