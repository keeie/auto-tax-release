import forge from 'node-forge';

/**
 * PFX/P12(PKCS#12) 파일에서 사용자 인증서(공개 인증서)를 꺼낸다.
 * Node 의 crypto 는 PKCS#12 를 직접 읽지 못해 node-forge 로 컨테이너만 풀고,
 * 인증서 내용(소유자명·만료일 등)은 DER 로 되돌려 Node 의 X509Certificate 가 읽도록 한다
 * (한글 이름 디코딩이 정확하고, signCert.der 와 같은 경로로 처리할 수 있다).
 *
 * node-forge 는 서명 검증 기능을 쓰지 않고 PKCS#12 구조 해석에만 사용한다.
 */

export class PfxPasswordError extends Error {
  constructor() {
    super('PFX 비밀번호가 올바르지 않습니다.');
    this.name = 'PfxPasswordError';
  }
}

export class PfxUnsupportedError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'PfxUnsupportedError';
  }
}

const bytesToBuffer = (s: string) => Buffer.from(s, 'binary');

export function readPfxCertificate(pfx: Buffer, password: string): { certDer: Buffer } {
  let p12: forge.pkcs12.Pkcs12Pfx;
  try {
    const asn1 = forge.asn1.fromDer(forge.util.createBuffer(pfx.toString('binary')));
    p12 = forge.pkcs12.pkcs12FromAsn1(asn1, false, password);
  } catch (err: any) {
    const msg = String(err?.message || err);
    if (/invalid password|mac could not be verified/i.test(msg)) throw new PfxPasswordError();
    throw new PfxUnsupportedError(`PFX 파일을 해석하지 못했습니다: ${msg.slice(0, 120)}`);
  }

  const certBags = p12.getBags({ bagType: forge.pki.oids.certBag })[forge.pki.oids.certBag] ?? [];
  if (certBags.length === 0) throw new PfxUnsupportedError('PFX 파일에서 인증서를 찾지 못했습니다.');

  // 개인키와 짝인 인증서(localKeyId 가 같은 것)를 우선한다. 없으면 자체 서명이 아닌 첫 인증서, 그것도 없으면 첫 인증서.
  const keyBags = {
    ...p12.getBags({ bagType: forge.pki.oids.pkcs8ShroudedKeyBag }),
    ...p12.getBags({ bagType: forge.pki.oids.keyBag }),
  };
  const keyIds = Object.values(keyBags)
    .flat()
    .map((b) => (b?.attributes?.localKeyId?.[0] ? forge.util.bytesToHex(b.attributes.localKeyId[0] as string) : ''))
    .filter(Boolean);

  const withCert = certBags.filter((b) => b.cert);
  const byKeyId = withCert.find((b) => {
    const id = b.attributes?.localKeyId?.[0];
    return id ? keyIds.includes(forge.util.bytesToHex(id as string)) : false;
  });
  const notSelfSigned = withCert.find((b) => {
    const c = b.cert!;
    return c.subject.hash !== c.issuer.hash;
  });
  const chosen = byKeyId ?? notSelfSigned ?? withCert[0];
  if (!chosen?.cert) throw new PfxUnsupportedError('PFX 파일에서 인증서를 읽지 못했습니다.');

  const der = forge.asn1.toDer(forge.pki.certificateToAsn1(chosen.cert)).getBytes();
  return { certDer: bytesToBuffer(der) };
}
