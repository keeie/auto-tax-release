import { Browser, BrowserContext } from 'playwright';
import { loadConfig, updateConfigFolders } from '../config';
import { launchBrowser, launchHiddenBrowser, newBrowserContext } from './browser';
import { loginNaver } from './auth';
import { connectGmail, scrapeGmailLabel } from './gmailImap';
import { accountKey, loadMailPassword, platformLabel } from './mailAccounts';
import { scrapeFolderMails } from './mailScraper';
import { AUTO_FILL_NAME, RegistryStorage } from './registry';
import { DataStorage } from './storage';
import { CollectionLog, CollectionStatus, FolderConfig, FolderSummary, MailItem } from '../types';
import { MailPlatform, PlantMailSettings } from '../types/registry';

interface AccountGroup {
  platform: MailPlatform;
  account: string;
  plants: { folder: FolderConfig; mail: PlantMailSettings }[];
}

export class CollectorService {
  private static instance: CollectorService;
  private status: CollectionStatus = {
    status: 'idle',
    logs: [],
  };
  private maxLogs: number = 300;
  private isRunning: boolean = false;

  private constructor() {}

  public static getInstance(): CollectorService {
    if (!CollectorService.instance) {
      CollectorService.instance = new CollectorService();
    }
    return CollectorService.instance;
  }

  public getStatus(): CollectionStatus {
    return { ...this.status, logs: [...this.status.logs] };
  }

  public getLogs(sinceTimestamp?: string): CollectionLog[] {
    if (!sinceTimestamp) {
      return [...this.status.logs];
    }
    return this.status.logs.filter((l) => l.timestamp > sinceTimestamp);
  }

  public addLog(message: string, level: 'info' | 'warn' | 'error' | 'success' = 'info') {
    const logItem: CollectionLog = {
      timestamp: new Date().toISOString(),
      message,
      level,
    };
    this.status.logs.push(logItem);
    if (this.status.logs.length > this.maxLogs) {
      this.status.logs.shift();
    }
    this.status.progressMessage = message;

    const prefix = level === 'error' ? '❌' : level === 'warn' ? '⚠️' : level === 'success' ? '✅' : 'ℹ️';
    console.log(`[Collector] ${prefix} ${message}`);
  }

  /** folderIds 가 없으면 전체 발전소, 있으면 그 발전소들만 수집한다. */
  public async startCollection(folderIds?: string[]): Promise<{ success: boolean; message: string }> {
    if (this.isRunning) {
      return {
        success: false,
        message: '현재 이미 데이터 수집 작업이 실행 중입니다.',
      };
    }

    // 비동기로 수집 프로세스 실행
    this.executeCollection(folderIds).catch((err) => {
      console.error('[Collector] 수집 프로세스 실행 중 예외 발생:', err);
    });

    return {
      success: true,
      message: folderIds ? '선택한 발전소의 메일 수집을 시작했습니다.' : '메일 수집 작업이 성공적으로 시작되었습니다.',
    };
  }

  private async executeCollection(folderIds?: string[]) {
    this.isRunning = true;
    this.status.status = 'running';
    this.status.startedAt = new Date().toISOString();
    this.status.finishedAt = undefined;
    this.status.error = undefined;
    this.status.logs = [];

    this.addLog('메일 수집 작업을 시작합니다.', 'info');

    let config;
    try {
      config = loadConfig();
    } catch (err: any) {
      this.addLog(`설정 파일 로드 실패: ${err.message}`, 'error');
      this.status.status = 'error';
      this.status.error = err.message;
      this.isRunning = false;
      return;
    }

    const storage = new DataStorage(config.options.outputDir);
    const registry = new RegistryStorage(config.options.outputDir);

    // 발전소마다 발전소 관리에 저장된 메일 정보를 읽어 계정(플랫폼 + ID)별로 묶는다.
    let groups: AccountGroup[];
    try {
      const folders = folderIds ? config.folders.filter((f) => folderIds.includes(f.folderId)) : config.folders;
      if (folderIds) this.addLog(`선택한 발전소(${folders.map((f) => f.businessName).join(', ') || '없음'})만 수집합니다.`, 'info');
      groups = this.groupByAccount(folders, registry);
    } catch (err: any) {
      this.fail(`발전소 메일 정보를 읽지 못했습니다: ${err.message || err}`);
      return;
    }
    if (groups.length === 0) {
      this.fail('메일 수집 정보가 등록된 발전소가 없습니다. 발전소 관리에서 발전소마다 메일 플랫폼, ID, 비밀번호, 메일함을 입력해 주세요.');
      return;
    }

    // 네이버 계정이 있을 때만 설정대로 브라우저를 띄운다. Gmail 은 IMAP 으로 받으므로 화면이 필요 없다.
    const hasNaver = groups.some((g) => g.platform === 'naver');
    if (hasNaver) this.addLog(`네이버 로그인용 브라우저 구동 중 (Headless: ${config.options.headless ? 'ON' : 'OFF'})...`, 'info');

    let browserInstance: Browser | undefined;
    let renderBrowser: Browser | undefined;
    const folderSummaries: FolderSummary[] = [];
    const failedAccounts: string[] = [];

    try {
      let firstContext: BrowserContext | undefined;
      if (hasNaver) {
        const launched = await launchBrowser(config.options);
        browserInstance = launched.browser;
        firstContext = launched.context;
      }

      const plantCount = groups.reduce((n, g) => n + g.plants.length, 0);
      this.addLog(`총 ${groups.length}개 메일 계정, ${plantCount}개 발전소 메일함 수집을 시작합니다.`, 'info');

      for (let gi = 0; gi < groups.length; gi++) {
        const group = groups[gi];
        const label = `${platformLabel(group.platform)} ${group.account}`;
        this.addLog(`[계정 ${gi + 1}/${groups.length}] ${label} (발전소 ${group.plants.length}곳)`, 'info');

        try {
          const password = await loadMailPassword(group.platform, group.account);
          if (!password) throw new Error('저장된 메일 비밀번호가 없습니다. 발전소 관리에서 비밀번호를 입력해 주세요.');

          if (group.platform === 'naver') {
            // 계정마다 쿠키가 섞이지 않도록 새 창(컨텍스트)에서 로그인한다. 첫 계정은 처음 만든 창을 쓴다.
            if (!browserInstance) throw new Error('네이버 브라우저를 준비하지 못했습니다.');
            const ctx = firstContext ?? (await newBrowserContext(browserInstance));
            firstContext = undefined;
            try {
              const page = ctx.pages()[0] ?? (await ctx.newPage());
              this.addLog(`${label} 로그인 진행 중...`, 'info');
              await loginNaver(page, { id: group.account, password });
              this.addLog(`${label} 로그인에 성공했습니다.`, 'success');
              for (const { folder, mail } of group.plants) {
                this.addLog(`[${folder.businessName}] 네이버 메일함 ${mail.mailbox} 탐색 중...`, 'info');
                const mails = await scrapeFolderMails(page, folder, {
                  mailboxId: mail.mailbox,
                  maxMails: config.options.maxMailsPerFolder,
                  onlyUnread: config.options.onlyUnread,
                });
                folderSummaries.push(this.save(storage, registry, folder, mails));
              }
            } finally {
              await ctx.close().catch(() => {});
            }
          } else {
            this.addLog(`${label} IMAP 접속 중...`, 'info');
            const client = await connectGmail(group.account, password);
            // 메일 HTML 은 외부에서 온 내용이므로 스크립트와 네트워크를 막은 창에서 텍스트만 뽑는다.
            // 숨겨진 브라우저로 메일 HTML 을 글자로 바꾼다(한 번만 띄운다).
            if (!renderBrowser) renderBrowser = await launchHiddenBrowser();
            const renderCtx = await renderBrowser.newContext({ javaScriptEnabled: false });
            try {
              await renderCtx.route('**/*', (route) => route.abort());
              const renderPage = await renderCtx.newPage();
              const htmlToText = async (html: string) => {
                await renderPage.setContent(html, { waitUntil: 'domcontentloaded' });
                return (await renderPage.locator('body').innerText().catch(() => '')).trim();
              };
              this.addLog(`${label} 접속에 성공했습니다.`, 'success');
              for (const { folder, mail } of group.plants) {
                this.addLog(`[${folder.businessName}] Gmail 라벨 "${mail.mailbox}" 탐색 중...`, 'info');
                const mails = await scrapeGmailLabel(client, mail.mailbox, folder, {
                  maxMails: config.options.maxMailsPerFolder,
                  onlyUnread: config.options.onlyUnread,
                  htmlToText,
                });
                folderSummaries.push(this.save(storage, registry, folder, mails));
              }
            } finally {
              await renderCtx.close().catch(() => {});
              await client.logout().catch(() => client.close());
            }
          }
        } catch (err: any) {
          // 한 계정이 실패해도 다른 계정은 계속 수집한다. 로그인 실패는 자동으로 다시 시도하지 않는다.
          failedAccounts.push(label);
          this.addLog(`${label} 수집 실패: ${err?.message || err}`, 'error');
        }
      }

      if (folderSummaries.length > 0) {
        this.addLog('전체 수집 요약 파일 저장 중...', 'info');
        storage.saveSummary(folderSummaries);
      }

      this.status.finishedAt = new Date().toISOString();
      if (failedAccounts.length > 0) {
        this.status.status = 'error';
        this.status.error = `${failedAccounts.length}개 메일 계정 수집 실패: ${failedAccounts.join(', ')}`;
        this.addLog(`수집을 마쳤지만 일부 계정이 실패했습니다: ${failedAccounts.join(', ')}`, 'warn');
      } else {
        this.status.status = 'completed';
        this.addLog('🎉 모든 발전소의 메일 수집 및 발전월별 데이터 적재가 완료되었습니다!', 'success');
      }
    } catch (err: any) {
      const msg = err.message || String(err);
      this.addLog(`데이터 수집 중 오류 발생: ${msg}`, 'error');
      this.status.status = 'error';
      this.status.error = msg;
      this.status.finishedAt = new Date().toISOString();
    } finally {
      if (browserInstance) await browserInstance.close().catch(() => {});
      if (renderBrowser) await renderBrowser.close().catch(() => {});
      this.isRunning = false;
    }
  }

  private fail(message: string) {
    this.addLog(message, 'error');
    this.status.status = 'error';
    this.status.error = message;
    this.status.finishedAt = new Date().toISOString();
    this.isRunning = false;
  }

  /**
   * 마법사로 만든 발전소(autoFill)는 첫 메일 수집 때 메일 내용으로 발전소명·주소·용량·고객번호를 채운다.
   * 이미 입력된 값은 덮어쓰지 않는다(발전소명은 임시 이름일 때만 바꾼다).
   */
  private applyAutoFill(storage: DataStorage, registry: RegistryStorage, folder: FolderConfig, mails: MailItem[]): FolderConfig {
    const rec = registry.getPlantRecord(folder.folderId);
    const data = mails[0]?.generationData;
    if (!rec?.autoFill || !data) return folder;

    let target = folder;
    const mailName = (data.plantName || '').trim();
    const nameIsPlaceholder = folder.businessName === AUTO_FILL_NAME;
    if (nameIsPlaceholder && mailName.length >= 2 && mailName !== folder.businessName) {
      // 데이터 폴더를 먼저 옮긴다. config 만 바꾸면 새 이름의 빈 폴더가 생기고 예전 폴더가 남아 발전소가 두 개로 보인다.
      // 옮기다 실패하면 예외가 나서 이번 수집은 중단되고, config 는 그대로 남는다.
      storage.renameFolderDir(folder.folderId, mailName);
      updateConfigFolders(
        (folders) =>
          folders.map((f) =>
            f.folderId === folder.folderId
              ? { ...f, businessName: mailName, description: f.description === AUTO_FILL_NAME ? mailName : f.description }
              : f
          )
      );
      target = { ...folder, businessName: mailName };
    }
    registry.upsertPlantRecord(folder.folderId, {
      address: rec.address || data.address || '',
      capacity: rec.capacity || data.capacity || '',
      contractNumber: rec.contractNumber || data.contractNumber || '',
      autoFill: false,
    });
    this.addLog(`[${target.businessName}] 메일 내용으로 발전소 정보를 자동 입력했습니다.`, 'success');
    return target;
  }

  private save(storage: DataStorage, registry: RegistryStorage, folder: FolderConfig, mails: MailItem[]): FolderSummary {
    const target = this.applyAutoFill(storage, registry, folder, mails);
    const summary = storage.saveFolderMails(target, mails);
    this.addLog(
      `[${folder.businessName}] 저장 완료 - 이번 수집 ${mails.length}건, 누적 메일: ${summary.totalMails}건, 발전월: [${summary.periods.join(', ') || '없음'}]`,
      mails.length > 0 ? 'success' : 'warn'
    );
    return summary;
  }

  /** 발전소를 메일 계정별로 묶는다. 메일 정보가 없는 발전소는 건너뛰고 로그에 남긴다. */
  private groupByAccount(folders: FolderConfig[], registry: RegistryStorage): AccountGroup[] {
    const groups = new Map<string, AccountGroup>();
    for (const folder of folders) {
      const mail = registry.getPlantRecord(folder.folderId)?.mail;
      if (!mail) {
        this.addLog(`[${folder.businessName}] 메일 수집 정보가 없어 건너뜁니다. 발전소 관리에서 입력해 주세요.`, 'warn');
        continue;
      }
      const key = accountKey(mail.platform, mail.account);
      if (!groups.has(key)) groups.set(key, { platform: mail.platform, account: mail.account, plants: [] });
      groups.get(key)!.plants.push({ folder, mail });
    }
    return [...groups.values()];
  }
}
