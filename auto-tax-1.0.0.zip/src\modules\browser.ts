import { chromium, Browser, BrowserContext, Page } from 'playwright';
import { AppOptions } from '../types';

export interface BrowserInstance {
  browser: Browser;
  context: BrowserContext;
  page: Page;
}

/**
 * 화면에 보이지 않는 브라우저. Gmail 메일 HTML 을 글자로 바꾸는 데만 쓰므로 창을 띄우지 않는다.
 */
export async function launchHiddenBrowser(): Promise<Browser> {
  return chromium.launch({ headless: true, args: ['--no-sandbox', '--disable-setuid-sandbox'] });
}

export async function launchBrowser(options: AppOptions): Promise<BrowserInstance> {
  const browser = await chromium.launch({
    headless: options.headless,
    slowMo: options.slowMo || 100,
    args: [
      '--disable-blink-features=AutomationControlled',
      '--window-size=1280,900',
      '--window-position=80,40',
      '--no-sandbox',
      '--disable-setuid-sandbox',
    ],
  });

  const context = await newBrowserContext(browser);
  const page = await context.newPage();

  return { browser, context, page };
}

/** 로그인 상태를 공유하지 않는 새 창(쿠키 분리). 메일 계정을 바꿔 로그인할 때 쓴다. */
export async function newBrowserContext(browser: Browser): Promise<BrowserContext> {
  const context = await browser.newContext({
    viewport: null, // 전체화면이 아닌 일반 창: 페이지는 창 크기를 따른다(hometax.ts 와 같은 방식)
    userAgent:
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
    locale: 'ko-KR',
    timezoneId: 'Asia/Seoul',
  });

  // Evaluate script to bypass navigator.webdriver detection
  await context.addInitScript(() => {
    Object.defineProperty(navigator, 'webdriver', {
      get: () => undefined,
    });
  });

  return context;
}
