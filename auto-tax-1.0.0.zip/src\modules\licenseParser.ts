import { LicenseParseResult, OperatorInput } from '../types/registry';

const WEIGHTS = [1, 3, 7, 1, 3, 7, 1, 3, 5];

/** 사업자등록번호 체크섬 검증 (숫자 10자리) */
export function isValidBizNumber(digits: string): boolean {
  if (!/^\d{10}$/.test(digits)) return false;
  const d = digits.split('').map(Number);
  let sum = 0;
  for (let i = 0; i < 9; i++) sum += d[i] * WEIGHTS[i];
  sum += Math.floor((d[8] * 5) / 10);
  return (10 - (sum % 10)) % 10 === d[9];
}

/** 숫자 10자리를 000-00-00000 형태로. 10자리가 아니면 null */
export function formatBizNumber(input: string): string | null {
  const digits = String(input).replace(/\D/g, '');
  if (digits.length !== 10) return null;
  return `${digits.slice(0, 3)}-${digits.slice(3, 5)}-${digits.slice(5)}`;
}

const DIGIT_FIX: Record<string, string> = { O: '0', o: '0', I: '1', l: '1', '|': '1', S: '5', B: '8' };
const fixDigits = (s: string) => s.replace(/[OoIl|SB]/g, (c) => DIGIT_FIX[c] ?? c);

const DASH = '[-‐‑–—−]';

function findRegistrationNumber(text: string): { value: string | null; valid: boolean } {
  const strict = [...text.matchAll(new RegExp(`(\\d{3})\\s*${DASH}\\s*(\\d{2})\\s*${DASH}\\s*(\\d{5})`, 'g'))].map(
    (m) => `${m[1]}${m[2]}${m[3]}`
  );
  const loose = [
    ...text.matchAll(
      new RegExp(`([0-9OoIl|SB]{3})\\s*${DASH}\\s*([0-9OoIl|SB]{2})\\s*${DASH}\\s*([0-9OoIl|SB]{5})`, 'g')
    ),
  ].map((m) => fixDigits(`${m[1]}${m[2]}${m[3]}`));
  // 하이픈이 다른 기호/공백으로 인식된 경우는 체크섬이 맞을 때만 인정 (오탐 방지)
  const spaced = [...text.matchAll(/(?<!\d)(\d{3})[\s._~]+(\d{2})[\s._~]+(\d{5})(?!\d)/g)].map(
    (m) => `${m[1]}${m[2]}${m[3]}`
  );

  const all = [...strict, ...loose, ...spaced];
  const valid = all.find(isValidBizNumber);
  if (valid) return { value: valid, valid: true };
  const fallback = [...strict, ...loose][0];
  return fallback ? { value: fallback, valid: false } : { value: null, valid: false };
}

// OCR 이 한글 음절 사이에 공백을 넣는 경우("한 솔 태 양 광")를 붙여준다.
function compactSpacedHangul(s: string): string {
  const out: string[] = [];
  let run: string[] = [];
  const flush = () => {
    if (run.length >= 2) out.push(run.join(''));
    else out.push(...run);
    run = [];
  };
  for (const t of s.split(' ')) {
    if (t.length === 1 && /[가-힣]/.test(t)) run.push(t);
    else {
      flush();
      out.push(t);
    }
  }
  flush();
  return out.join(' ');
}

// 같은 줄에 다른 항목 라벨이 붙어 읽힌 경우 값을 거기서 자른다.
const NEXT_LABEL = /(성\s*명|대\s*표\s*자|생\s*년\s*월\s*일|개\s*업|사\s*업\s*장|본\s*점|업\s*태|종\s*목|등\s*록\s*번\s*호|상\s*호|법\s*인\s*명)/;
const STOP_LABEL = new RegExp(`^.{0,6}${NEXT_LABEL.source}|사\\s*업\\s*의\\s*종\\s*류|발\\s*급|공\\s*동\\s*사\\s*업\\s*자|사\\s*업\\s*자\\s*단\\s*위|전\\s*자\\s*세\\s*금`);

function cleanValue(v: string): string {
  let s = v.replace(/\s+/g, ' ').trim();
  const cut = s.search(NEXT_LABEL);
  if (cut > 0) s = s.slice(0, cut).trim();
  s = s.replace(/^[\s:：;.\-_~|]+|[\s:：;.,\-|_~]+$/g, '');
  return compactSpacedHangul(s);
}

/** 한국 행정구역 주소의 공백이 붙어있는 경우(PDF/스캔)를 자연스러운 띄어쓰기로 보정 */
export function formatKoreanAddress(addr: string): string {
  if (!addr) return '';
  let s = addr.trim().replace(/\s+/g, ' ');
  const spaceCount = (s.match(/\s/g) || []).length;
  if (spaceCount >= 2) {
    return s;
  }

  const provRegex = /^(서울특별시|부산광역시|대구광역시|인천광역시|광주광역시|대전광역시|울산광역시|세종특별자치시|경기도|강원특별자치도|강원도|충청북도|충청남도|전북특별자치도|전라북도|전라남도|경상북도|경상남도|제주특별자치도|제주도)/;
  const provMatch = s.match(provRegex);
  if (!provMatch) return s;

  const parts = [provMatch[1]];
  let rest = s.slice(provMatch[1].length).trim();

  // 시 / 군 / 구 순차 추출 (2회까지: 예, 전주시 완산구, 포항시 남구)
  for (let k = 0; k < 2; k++) {
    const m = rest.match(/^([가-힣]{1,4}?(?:시|군|구))(.*)$/);
    if (m) {
      parts.push(m[1]);
      rest = m[2].trim();
    } else break;
  }

  // 읍 / 면 / 동 / 가
  const emdMatch = rest.match(/^([가-힣]{1,5}?(?:읍|면|동\d*가?|가))(.*)$/);
  if (emdMatch) {
    parts.push(emdMatch[1]);
    rest = emdMatch[2].trim();
  }

  // 리
  const riMatch = rest.match(/^([가-힣]{1,5}?(?:리))(.*)$/);
  if (riMatch) {
    parts.push(riMatch[1]);
    rest = riMatch[2].trim();
  }

  // 도로명 (로/길)
  const roadMatch = rest.match(/^([가-힣\d]{1,10}?(?:로|길)(?:\s*\d+번길)?)(.*)$/);
  if (roadMatch) {
    parts.push(roadMatch[1]);
    rest = roadMatch[2].trim();
  }

  if (rest) parts.push(rest);
  return parts.join(' ');
}

function extractBusinessTypeAndItem(lines: string[]): { businessType?: string; businessItem?: string } {
  let businessType: string | undefined;
  let businessItem: string | undefined;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // Case 1: 업태와 종목이 한 행에 헤더로 오는 경우 (예: "업태 종목", "업 태 종 목")
    if (/^업\s*태\s+종\s*목\s*[:：]?$/.test(line)) {
      if (i + 1 < lines.length && !STOP_LABEL.test(lines[i + 1])) {
        const valLine = lines[i + 1];
        const parts = valLine.split(/\s{2,}|\s(?=[가-힣\w]+(?:업|제조|도소매|서비스|건설|발전))/);
        if (parts.length >= 2) {
          businessType = cleanValue(parts[0]);
          businessItem = cleanValue(parts.slice(1).join(' '));
          break;
        }
      }
    }

    // Case 2: 행에 "업태" 가 포함된 경우
    const typeMatch = line.match(/업\s*태(?:\s*[:：]|\s|$)/);
    if (typeMatch && !businessType) {
      const after = line.slice(typeMatch.index! + typeMatch[0].length).trim();
      // 같은 줄에 "종목"도 함께 있는 경우
      const itemInLine = after.match(/종\s*목(?:\s*[:：]|\s|$)/);
      if (itemInLine) {
        businessType = cleanValue(after.slice(0, itemInLine.index));
        const afterItem = after.slice(itemInLine.index! + itemInLine[0].length);
        if (afterItem) businessItem = cleanValue(afterItem);
      } else if (after) {
        businessType = cleanValue(after);
      } else if (i + 1 < lines.length && !STOP_LABEL.test(lines[i + 1]) && !/종\s*목/.test(lines[i + 1])) {
        // "업태" 라벨만 단독으로 있고 다음 줄에 값이 오는 경우 (PDF/표 양식)
        businessType = cleanValue(lines[i + 1]);
      }
    }

    // Case 3: 행에 "종목" 이 포함된 경우
    const itemMatch = line.match(/종\s*목(?:\s*[:：]|\s|$)/);
    if (itemMatch && !businessItem) {
      const after = line.slice(itemMatch.index! + itemMatch[0].length).trim();
      if (after) {
        businessItem = cleanValue(after);
      } else if (i + 1 < lines.length && !STOP_LABEL.test(lines[i + 1])) {
        // "종목" 라벨만 단독으로 있고 다음 줄에 값이 오는 경우
        businessItem = cleanValue(lines[i + 1]);
      }
    }
  }

  return { businessType, businessItem };
}

function findLabeled(
  lines: string[],
  label: RegExp,
  opts: { skipIf?: RegExp; allowNextLine?: boolean } = {}
): { value: string; index: number } | null {
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (opts.skipIf && opts.skipIf.test(line)) continue;
    const m = line.match(label);
    if (!m || m.index === undefined) continue;
    let rest = line.slice(m.index + m[0].length).replace(/^[\s:：;.\-]+/, '').trim();
    if (!rest && opts.allowNextLine !== false && i + 1 < lines.length && !STOP_LABEL.test(lines[i + 1])) {
      rest = lines[i + 1];
      return { value: rest, index: i + 1 };
    }
    if (rest) return { value: rest, index: i };
  }
  return null;
}

export function parseBusinessLicenseText(rawText: string): LicenseParseResult {
  const warnings: string[] = [];
  const fields: OperatorInput = {};

  const text = rawText.replace(/\r/g, '');
  const lines = text
    .split('\n')
    .map((l) => l.replace(/[|｜¦]/g, ' ').replace(/\s+/g, ' ').trim())
    .filter(Boolean);

  // 1. 사업자등록번호
  const reg = findRegistrationNumber(text);
  if (reg.value) {
    fields.registrationNumber = `${reg.value.slice(0, 3)}-${reg.value.slice(3, 5)}-${reg.value.slice(5)}`;
    if (!reg.valid) {
      warnings.push('사업자등록번호가 체크섬 검증을 통과하지 못했습니다. 오인식일 수 있으니 원본과 대조해 수정해 주세요.');
    }
  } else {
    warnings.push('사업자등록번호를 인식하지 못했습니다. 직접 입력해 주세요.');
  }

  // 2. 상호(법인명)
  const nameHit = findLabeled(lines, /(?:법\s*인\s*명(?:\s*\(\s*단\s*체\s*명\s*\))?|상\s*호)(?:\s*\([^)]*\))?/);
  if (nameHit) {
    const v = cleanValue(nameHit.value);
    if (v) fields.businessName = v;
  }
  if (!fields.businessName) warnings.push('상호(법인명)를 인식하지 못했습니다.');

  // 3. 대표자(성명)
  const repHit = findLabeled(lines, /(?:대\s*표\s*자|성\s*명)(?:\s*\([^)]*\))?/);
  if (repHit) {
    const v = cleanValue(repHit.value).match(/[가-힣]{2,5}/);
    if (v) fields.representative = v[0];
  }
  if (!fields.representative) warnings.push('대표자(성명)를 인식하지 못했습니다.');

  // 4. 개업연월일
  const dateMatch = text.match(/개\s*업\s*연\s*월\s*일\s*[:：;]?\s*(\d{4})\s*[년.\-/]\s*(\d{1,2})\s*[월.\-/]\s*(\d{1,2})/);
  if (dateMatch) {
    fields.openedDate = `${dateMatch[1]}-${dateMatch[2].padStart(2, '0')}-${dateMatch[3].padStart(2, '0')}`;
  }

  // 5. 사업장 소재지 (본점 소재지 제외, 다음 줄로 이어지는 주소 보정 및 띄어쓰기 정규화)
  const addrHit = findLabeled(lines, /사\s*업\s*장\s*(?:\(\s*[^)]*\)\s*)?(?:소\s*재\s*지)?/, {
    skipIf: /본\s*점/,
    allowNextLine: true,
  });
  if (addrHit) {
    let v = cleanValue(addrHit.value);
    for (let k = addrHit.index + 1; k <= addrHit.index + 1 && k < lines.length; k++) {
      const next = lines[k];
      if (!STOP_LABEL.test(next) && !/[:：]/.test(next) && next.length <= 40 && v) {
        v = `${v} ${cleanValue(next)}`.trim();
      }
    }
    if (v) fields.address = formatKoreanAddress(v);
  }
  if (!fields.address) warnings.push('사업장 소재지를 인식하지 못했습니다.');

  // 6. 업태 / 종목 (동일 행, 헤더-데이터 행, 단독 행 양식 모두 지원)
  const { businessType, businessItem } = extractBusinessTypeAndItem(lines);
  if (businessType) fields.businessType = businessType;
  if (businessItem) fields.businessItem = businessItem;

  return { fields, warnings };
}
