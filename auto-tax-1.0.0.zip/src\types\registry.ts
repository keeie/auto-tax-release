// 사업자(사업자등록증 기준) 및 발전소 관리용 타입

// 사업자에 등록된 공동인증서(공인인증서)의 "표시용 요약". 파일과 비밀번호는 secrets/ 에만 저장되며
// registry.json 에는 비밀값이 들어가지 않는다.
export interface CertificateMeta {
  kind: 'npki' | 'pfx';          // npki: signCert.der + signPri.key, pfx: .pfx/.p12
  fileNames: string[];           // 업로드 당시 원본 파일명(표시용)
  subject: string;               // 인증서 소유자(CN). PFX 는 서버에서 읽을 수 없어 ''
  issuer: string;
  validFrom: string;             // ISO 날짜, 모르면 ''
  validTo: string;
  passwordSaved: boolean;
  passwordVerified: boolean | null;  // true: 개인키 복호화로 확인됨, null: 이 형식은 서버에서 검증할 수 없음
  keyMatchesCert: boolean | null;    // 개인키와 인증서 짝 확인 결과, null: 확인 불가
  registeredAt: string;
  updatedAt: string;
}

export interface Operator {
  id: string;
  businessName: string;        // 상호(법인명)
  representative: string;      // 대표자(성명)
  registrationNumber: string;  // 사업자등록번호 000-00-00000
  openedDate: string;          // 개업연월일 YYYY-MM-DD (없으면 '')
  address: string;             // 사업장 소재지
  businessType: string;        // 업태
  businessItem: string;        // 종목
  certificate?: CertificateMeta;
  createdAt: string;
  updatedAt: string;
}

export type OperatorInput = Partial<Omit<Operator, 'id' | 'createdAt' | 'updatedAt' | 'certificate'>>;

export type MailPlatform = 'naver' | 'gmail';

/**
 * 발전소의 한전 요금 메일을 받는 메일함. 비밀번호는 여기에 두지 않고
 * secrets/mail/ 에 계정(플랫폼 + ID)별로 암호화해 저장한다(mailAccounts.ts).
 */
export interface PlantMailSettings {
  platform: MailPlatform;
  account: string;   // 네이버 ID 또는 Gmail 주소
  mailbox: string;   // 네이버: 메일함 폴더 번호, Gmail: 라벨 이름
}

// 발전소(메일함) 부가 정보. 발전소 자체의 목록/이름은 config.json 의 folders 가 기준이다.
// folderId 는 발전소 식별자(데이터 폴더 이름 앞부분)이며, 예전에 등록한 발전소는 네이버 메일함 번호와 같다.
export interface PlantRecord {
  folderId: string;
  operatorId: string;
  address: string;
  capacity: string;
  contractNumber: string;
  mail?: PlantMailSettings;
  /** true: 마법사로 만든 발전소. 첫 메일 수집 때 발전소명·주소·용량·고객번호를 메일에서 채운 뒤 false 로 바꾼다. */
  autoFill?: boolean;
  updatedAt: string;
}

export type PlantPatch = Partial<Pick<PlantRecord, 'operatorId' | 'address' | 'capacity' | 'contractNumber' | 'mail' | 'autoFill'>>;

export interface PlantInput extends Omit<PlantPatch, 'mail'> {
  folderId?: string;
  plantName?: string;
  description?: string;
  mailPlatform?: string;
  mailAccount?: string;
  mailbox?: string;
  mailPassword?: string; // 비우면 저장된 비밀번호 유지
  autoFill?: boolean;
}

export interface PlantView {
  folderId: string;
  plantName: string;
  description: string;
  operatorId: string;
  operatorName: string;
  address: string;
  capacity: string;
  contractNumber: string;
  mail: PlantMailSettings | null;
  mailPasswordSaved: boolean;
  hasData: boolean;
}

/** 발전월별 세금계산서 발행 완료 여부(직접 표시). 수집 데이터(periods/*.json)는 재수집 때 덮어써지므로 여기에 따로 둔다. */
export interface InvoiceIssueRecord {
  folderId: string;
  generationPeriod: string;
  issued: boolean;
  updatedAt: string;
}

export interface RegistryFile {
  operators: Operator[];
  plants: PlantRecord[];
  invoices: InvoiceIssueRecord[];
}

export interface LicenseParseResult {
  fields: OperatorInput;
  warnings: string[];
}
