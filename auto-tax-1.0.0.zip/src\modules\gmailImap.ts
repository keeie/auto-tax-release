import { ImapFlow } from 'imapflow';
import { simpleParser } from 'mailparser';
import { FolderConfig, MailItem } from '../types';
import { isTargetKepcoMail } from './mailScraper';
import { parseGenerationData } from './parser';

/**
 * Gmail 수집. Google 은 자동화된 브라우저 로그인을 막으므로 IMAP(imap.gmail.com) + 앱 비밀번호로 접속한다.
 * Gmail 라벨은 IMAP 메일함으로 보이므로 라벨 이름을 메일함 경로로 연다(하위 라벨은 "상위/하위").
 * 메일은 읽기 전용으로 열고 본문도 PEEK 로 받으므로 읽음 표시가 바뀌지 않는다.
 */

export interface GmailScrapeOptions {
  maxMails?: number;
  onlyUnread?: boolean;
  /** HTML 본문을 화면에 보이는 텍스트로 바꾼다(네이버 수집과 같은 형식이 되도록 브라우저 innerText 사용). */
  htmlToText: (html: string) => Promise<string>;
}

export async function connectGmail(account: string, password: string): Promise<ImapFlow> {
  const client = new ImapFlow({
    host: 'imap.gmail.com',
    port: 993,
    secure: true,
    auth: { user: account, pass: password },
    logger: false, // 로그에 계정 정보가 남지 않도록 끈다
  });
  try {
    await client.connect();
  } catch (err: any) {
    client.close();
    if (err?.authenticationFailed) {
      // Google 은 2단계 인증이 켜진 계정에 일반 비밀번호를 주면 이 문구로 거절한다(비밀번호 값은 메시지에 넣지 않는다).
      const needsAppPassword = /Application-specific password required/i.test(String(err?.responseText || err?.message || ''));
      throw new Error(
        needsAppPassword
          ? `Gmail(${account})은 일반 비밀번호로 접속할 수 없습니다. 발전소 관리에서 "앱 비밀번호"(16자리)로 비밀번호를 다시 입력해 주세요.`
          : `Gmail(${account}) 로그인에 실패했습니다. 앱 비밀번호(16자리)가 맞는지, Gmail 설정에서 IMAP 사용이 켜져 있는지 확인해 주세요.`
      );
    }
    throw new Error(`Gmail(${account}) IMAP 서버에 접속하지 못했습니다: ${err?.message || err}`);
  }
  return client;
}

async function resolveLabelPath(client: ImapFlow, label: string): Promise<string> {
  if (/^(inbox|받은편지함)$/i.test(label)) return 'INBOX';
  const boxes = await client.list();
  const found = boxes.find((b) => b.path === label) || boxes.find((b) => b.path.toLowerCase() === label.toLowerCase());
  if (!found) throw new Error(`Gmail 라벨 "${label}"을(를) 찾을 수 없습니다. 라벨 이름(하위 라벨은 "상위/하위")을 확인해 주세요.`);
  return found.path;
}

export async function scrapeGmailLabel(
  client: ImapFlow,
  label: string,
  folder: FolderConfig,
  options: GmailScrapeOptions
): Promise<MailItem[]> {
  const { maxMails = 50, onlyUnread = false } = options;
  const path = await resolveLabelPath(client, label);
  const lock = await client.getMailboxLock(path, { readOnly: true });
  try {
    const total = client.mailbox ? client.mailbox.exists : 0;
    if (!total) {
      console.log(`[Gmail] 라벨 [${label}]에 메일이 없습니다.`);
      return [];
    }

    // 최근 maxMails 건의 머리글만 먼저 받고(fetch 반복 중에는 다른 명령을 보내면 안 됨) 최신순으로 살펴본다.
    const from = Math.max(1, total - Math.max(1, maxMails) + 1);
    const headers: { uid: number; seq: number; subject: string; senderName: string; senderEmail: string; date?: Date; unread: boolean }[] = [];
    for await (const msg of client.fetch(`${from}:*`, { uid: true, envelope: true, flags: true })) {
      const sender = msg.envelope?.from?.[0];
      headers.push({
        uid: msg.uid,
        seq: msg.seq,
        subject: msg.envelope?.subject || '',
        senderName: sender?.name || '',
        senderEmail: sender?.address || '',
        date: msg.envelope?.date ? new Date(msg.envelope.date) : undefined,
        unread: !msg.flags?.has('\\Seen'),
      });
    }
    headers.sort((a, b) => b.seq - a.seq);

    const target = headers.find((h) => (!onlyUnread || h.unread) && isTargetKepcoMail(h.senderName, h.senderEmail, h.subject));
    if (!target) {
      console.log(`[Gmail] 라벨 [${label}]에서 한국전력공사 요금안내 메일을 찾지 못했습니다.`);
      return [];
    }

    const full = await client.fetchOne(String(target.uid), { source: true }, { uid: true });
    if (!full || !full.source) throw new Error(`Gmail 메일 본문을 받지 못했습니다: ${target.subject}`);
    const parsed = await simpleParser(full.source);
    const bodyText = parsed.html ? await options.htmlToText(parsed.html) : parsed.text || '';
    const subject = parsed.subject || target.subject;
    const generationData = parseGenerationData(subject, bodyText, folder.businessName);

    console.log(`[Gmail] [${folder.businessName}] "${subject}" 수집 (발전기간: ${generationData.generationPeriod || '미분류'})`);

    return [
      {
        id: `gmail_${target.uid}`,
        folderId: folder.folderId,
        folderName: folder.businessName,
        subject,
        senderName: target.senderName,
        senderEmail: target.senderEmail,
        receivedDate: (parsed.date || target.date || new Date()).toISOString(),
        isUnread: target.unread,
        previewText: bodyText.replace(/\s+/g, ' ').slice(0, 200),
        bodyText,
        hasAttachment: (parsed.attachments?.length ?? 0) > 0,
        generationData,
        collectedAt: new Date().toISOString(),
      },
    ];
  } finally {
    lock.release();
  }
}
