import fs from 'fs';
import path from 'path';
import { BusinessData, FolderConfig, FolderSummary, MailItem, OverallStats, PeriodDataPayload } from '../types';

export class DataStorage {
  private baseDir: string;

  constructor(outputDir: string = './data') {
    this.baseDir = path.resolve(process.cwd(), outputDir);
    this.ensureDir(this.baseDir);
  }

  private ensureDir(dirPath: string) {
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
    }
  }

  private sanitizeFilename(name: string): string {
    return name.replace(/[\\/:*?"<>|]/g, '_').trim();
  }

  public saveFolderMails(folder: FolderConfig, mails: MailItem[]): FolderSummary {
    const safeFolderName = this.sanitizeFilename(`${folder.folderId}_${folder.businessName}`);
    const folderDir = path.join(this.baseDir, safeFolderName);
    this.ensureDir(folderDir);

    // 1. 기존 저장된 메일 데이터 불러오기 (중복 방지 및 누적 보존)
    const allMailsFile = path.join(folderDir, 'all_mails.json');
    let existingMails: MailItem[] = [];
    if (fs.existsSync(allMailsFile)) {
      try {
        const raw = fs.readFileSync(allMailsFile, 'utf-8');
        existingMails = JSON.parse(raw);
      } catch (err) {
        console.warn(`[Storage] 기존 파일(${allMailsFile}) 읽기 실패:`, err);
      }
    }

    // 발전 기간(Period) 또는 ID를 고유 키로 하여 중복 병합 (새로운 발전월은 누적 추가)
    const mailMap = new Map<string, MailItem>();
    const getMailKey = (m: MailItem, idx: number) => {
      const period = m.generationData?.generationPeriod;
      if (period && period !== '미분류') {
        return `${m.folderId}_${period}`;
      }
      return m.id || `${m.folderId}_${idx}_${m.receivedDate}`;
    };

    for (let i = 0; i < existingMails.length; i++) {
      const m = existingMails[i];
      mailMap.set(getMailKey(m, i), m);
    }
    for (let i = 0; i < mails.length; i++) {
      const m = mails[i];
      mailMap.set(getMailKey(m, i), m);
    }
    const mergedMails = Array.from(mailMap.values());

    // all_mails.json 저장
    fs.writeFileSync(allMailsFile, JSON.stringify(mergedMails, null, 2), 'utf-8');

    // 2. 발전 기간별(Generation Period)로 그룹화하여 각각 저장
    const periodGroups = new Map<string, MailItem[]>();
    for (const m of mergedMails) {
      const period = m.generationData.generationPeriod || '미분류';
      if (!periodGroups.has(period)) {
        periodGroups.set(period, []);
      }
      periodGroups.get(period)!.push(m);
    }

    const periodsDir = path.join(folderDir, 'periods');
    this.ensureDir(periodsDir);

    for (const [period, items] of periodGroups.entries()) {
      const periodFileName = `${this.sanitizeFilename(period)}.json`;
      const periodFilePath = path.join(periodsDir, periodFileName);

      const periodDataPayload: PeriodDataPayload = {
        folderId: folder.folderId,
        businessName: folder.businessName,
        generationPeriod: period,
        totalItems: items.length,
        items: items,
        aggregated: {
          totalSupplyAmount: items.reduce((sum, item) => sum + (item.generationData.supplyAmount || 0), 0),
          totalTaxAmount: items.reduce((sum, item) => sum + (item.generationData.taxAmount || 0), 0),
          totalAmount: items.reduce((sum, item) => sum + (item.generationData.totalAmount || 0), 0),
          totalGenerationAmount: items.reduce((sum, item) => sum + (item.generationData.generationAmount || 0), 0),
        },
        lastUpdated: new Date().toISOString(),
      };

      fs.writeFileSync(periodFilePath, JSON.stringify(periodDataPayload, null, 2), 'utf-8');
    }

    // 3. 폴더 요약 생성
    const summary: FolderSummary = {
      folderId: folder.folderId,
      businessName: folder.businessName,
      totalMails: mergedMails.length,
      newMails: mails.filter((m) => m.isUnread).length,
      periods: Array.from(periodGroups.keys()),
      lastUpdated: new Date().toISOString(),
    };

    return summary;
  }

  public saveSummary(summaries: FolderSummary[]) {
    const summaryFile = path.join(this.baseDir, 'summary.json');
    const masterData = {
      lastCollectedAt: new Date().toISOString(),
      totalFolders: summaries.length,
      folders: summaries,
    };
    fs.writeFileSync(summaryFile, JSON.stringify(masterData, null, 2), 'utf-8');
    console.log(`[Storage] 전체 수집 요약 파일 저장 완료: ${summaryFile}`);
  }

  public getAllBusinessesData(configuredFolders?: FolderConfig[]): {
    businesses: BusinessData[];
    stats: OverallStats;
  } {
    const businesses: BusinessData[] = [];
    const knownFolderMap = new Map<string, FolderConfig>();
    if (configuredFolders) {
      for (const f of configuredFolders) {
        knownFolderMap.set(f.folderId, f);
      }
    }

    if (!fs.existsSync(this.baseDir)) {
      return {
        businesses: [],
        stats: {
          totalBusinesses: 0,
          totalPeriods: 0,
          totalGenerationAmount: 0,
          totalSupplyAmount: 0,
          totalTaxAmount: 0,
          totalAmount: 0,
        },
      };
    }

    const dirEntries = fs.readdirSync(this.baseDir, { withFileTypes: true });

    for (const entry of dirEntries) {
      if (!entry.isDirectory()) continue;

      const folderDirName = entry.name;
      // Format: {folderId}_{businessName}
      const splitIdx = folderDirName.indexOf('_');
      let folderId = splitIdx > 0 ? folderDirName.substring(0, splitIdx) : folderDirName;
      let businessName = splitIdx > 0 ? folderDirName.substring(splitIdx + 1) : folderDirName;

      if (knownFolderMap.has(folderId)) {
        businessName = knownFolderMap.get(folderId)!.businessName;
      }

      const fullFolderPath = path.join(this.baseDir, folderDirName);
      const periodsDir = path.join(fullFolderPath, 'periods');

      const periods: PeriodDataPayload[] = [];
      let plantName = '';
      let address = '';
      let capacity = '';
      let contractNumber = '';
      let latestUpdated = '';

      if (fs.existsSync(periodsDir)) {
        const periodFiles = fs.readdirSync(periodsDir).filter((f) => f.endsWith('.json'));

        for (const file of periodFiles) {
          try {
            const content = fs.readFileSync(path.join(periodsDir, file), 'utf-8');
            const parsed = JSON.parse(content) as PeriodDataPayload;
            periods.push(parsed);

            if (!latestUpdated || parsed.lastUpdated > latestUpdated) {
              latestUpdated = parsed.lastUpdated;
            }

            // 대표 메타데이터 추출 (가장 최신 데이터 기준)
            if (parsed.items && parsed.items.length > 0) {
              const latestItem = parsed.items[0];
              if (!plantName && latestItem.generationData.plantName) {
                plantName = latestItem.generationData.plantName;
              }
              if (!address && latestItem.generationData.address) {
                address = latestItem.generationData.address;
              }
              if (!capacity && latestItem.generationData.capacity) {
                capacity = latestItem.generationData.capacity;
              }
              if (!contractNumber && latestItem.generationData.contractNumber) {
                contractNumber = latestItem.generationData.contractNumber;
              }
            }
          } catch (err) {
            console.warn(`[Storage] 기간 파일 읽기 실패: ${file}`, err);
          }
        }
      }

      // 기간 내림차순 정렬 (최신 발전월이 맨 위로)
      periods.sort((a, b) => b.generationPeriod.localeCompare(a.generationPeriod));

      const totalSupplyAmount = periods.reduce((sum, p) => sum + (p.aggregated.totalSupplyAmount || 0), 0);
      const totalTaxAmount = periods.reduce((sum, p) => sum + (p.aggregated.totalTaxAmount || 0), 0);
      const totalAmount = periods.reduce((sum, p) => sum + (p.aggregated.totalAmount || 0), 0);
      const totalGenerationAmount = periods.reduce((sum, p) => sum + (p.aggregated.totalGenerationAmount || 0), 0);

      businesses.push({
        folderId,
        folderName: folderDirName,
        businessName,
        plantName: plantName || businessName,
        address: address || '-',
        capacity: capacity || '-',
        contractNumber: contractNumber || '-',
        periods,
        totalPeriods: periods.length,
        aggregated: {
          totalSupplyAmount,
          totalTaxAmount,
          totalAmount,
          totalGenerationAmount,
        },
        lastUpdated: latestUpdated || new Date().toISOString(),
      });
    }

    // 설정에는 있으나 아직 수집된 데이터가 없는 폴더도 표시
    if (configuredFolders) {
      for (const cf of configuredFolders) {
        if (!businesses.some((b) => b.folderId === cf.folderId)) {
          businesses.push({
            folderId: cf.folderId,
            folderName: `${cf.folderId}_${cf.businessName}`,
            businessName: cf.businessName,
            plantName: cf.businessName,
            address: '-',
            capacity: '-',
            contractNumber: '-',
            periods: [],
            totalPeriods: 0,
            aggregated: {
              totalSupplyAmount: 0,
              totalTaxAmount: 0,
              totalAmount: 0,
              totalGenerationAmount: 0,
            },
            lastUpdated: '-',
          });
        }
      }
    }

    // 사업자 정렬 (ID 오름차순)
    businesses.sort((a, b) => a.folderId.localeCompare(b.folderId, undefined, { numeric: true }));

    // 전체 통계 산출
    const stats: OverallStats = {
      totalBusinesses: businesses.filter((b) => b.totalPeriods > 0).length,
      totalPeriods: businesses.reduce((sum, b) => sum + b.totalPeriods, 0),
      totalGenerationAmount: businesses.reduce((sum, b) => sum + b.aggregated.totalGenerationAmount, 0),
      totalSupplyAmount: businesses.reduce((sum, b) => sum + b.aggregated.totalSupplyAmount, 0),
      totalTaxAmount: businesses.reduce((sum, b) => sum + b.aggregated.totalTaxAmount, 0),
      totalAmount: businesses.reduce((sum, b) => sum + b.aggregated.totalAmount, 0),
    };

    // summary.json 읽어서 lastCollectedAt 보강
    const summaryFile = path.join(this.baseDir, 'summary.json');
    if (fs.existsSync(summaryFile)) {
      try {
        const summaryRaw = JSON.parse(fs.readFileSync(summaryFile, 'utf-8'));
        stats.lastCollectedAt = summaryRaw.lastCollectedAt;
      } catch {}
    }

    return { businesses, stats };
  }

  /**
   * 발전소 이름이 바뀔 때 기존 수집 데이터 폴더({folderId}_{이름})의 이름도 함께 바꾼다.
   * 이름만 바꾸고 폴더를 그대로 두면 다음 수집 때 새 폴더가 생겨 데이터가 둘로 갈라진다.
   * 기존 데이터 폴더가 없으면 false, 이름을 바꿨거나 이미 같은 이름이면 true.
   */
  public renameFolderDir(folderId: string, newBusinessName: string): boolean {
    if (!fs.existsSync(this.baseDir)) return false;

    let oldDir = '';
    for (const entry of fs.readdirSync(this.baseDir, { withFileTypes: true })) {
      if (!entry.isDirectory()) continue;
      const idx = entry.name.indexOf('_');
      const entryFolderId = idx > 0 ? entry.name.substring(0, idx) : entry.name;
      if (entryFolderId === folderId) {
        oldDir = path.join(this.baseDir, entry.name);
        break;
      }
    }
    if (!oldDir) return false;

    const newDir = path.join(this.baseDir, this.sanitizeFilename(`${folderId}_${newBusinessName}`));
    if (newDir === oldDir) return true;
    if (fs.existsSync(newDir) && newDir.toLowerCase() !== oldDir.toLowerCase()) {
      throw new Error(`같은 이름의 데이터 폴더가 이미 있습니다: ${path.basename(newDir)}`);
    }
    fs.renameSync(oldDir, newDir);
    console.log(`[Storage] 데이터 폴더 이름 변경: ${path.basename(oldDir)} -> ${path.basename(newDir)}`);
    return true;
  }

  public deletePeriodData(folderId: string, generationPeriod: string): boolean {
    if (!fs.existsSync(this.baseDir)) return false;

    // 폴더 디렉터리 탐색 (e.g. "102_테스트 발전소" or folderId === "102")
    const dirEntries = fs.readdirSync(this.baseDir, { withFileTypes: true });
    let targetFolderDir = '';

    for (const entry of dirEntries) {
      if (!entry.isDirectory()) continue;
      const folderDirName = entry.name;
      const splitIdx = folderDirName.indexOf('_');
      const entryFolderId = splitIdx > 0 ? folderDirName.substring(0, splitIdx) : folderDirName;

      if (entryFolderId === folderId || folderDirName === folderId) {
        targetFolderDir = path.join(this.baseDir, folderDirName);
        break;
      }
    }

    if (!targetFolderDir || !fs.existsSync(targetFolderDir)) {
      return false;
    }

    let deletedAny = false;

    // 1. periods/ 디렉터리 내의 해당 기간 JSON 파일 삭제
    const periodsDir = path.join(targetFolderDir, 'periods');
    if (fs.existsSync(periodsDir)) {
      const targetFileName = `${this.sanitizeFilename(generationPeriod)}.json`;
      const targetFilePath = path.join(periodsDir, targetFileName);
      if (fs.existsSync(targetFilePath)) {
        fs.unlinkSync(targetFilePath);
        deletedAny = true;
        console.log(`[Storage] 발전 기간 파일 삭제 완료: ${targetFilePath}`);
      }
    }

    // 2. all_mails.json 내의 해당 발전기간 메일 데이터 제거
    const allMailsFile = path.join(targetFolderDir, 'all_mails.json');
    if (fs.existsSync(allMailsFile)) {
      try {
        const raw = fs.readFileSync(allMailsFile, 'utf-8');
        const mails = JSON.parse(raw) as MailItem[];
        const filteredMails = mails.filter(
          (m) => (m.generationData?.generationPeriod || '미분류') !== generationPeriod
        );
        if (filteredMails.length !== mails.length) {
          deletedAny = true;
          fs.writeFileSync(allMailsFile, JSON.stringify(filteredMails, null, 2), 'utf-8');
          console.log(
            `[Storage] all_mails.json 에서 [${generationPeriod}] 메일 ${mails.length - filteredMails.length}건 제거 완료`
          );
        }
      } catch (err) {
        console.warn(`[Storage] all_mails.json 업데이트 실패:`, err);
      }
    }

    return deletedAny;
  }
}
