import { execFile, spawn } from 'child_process';
import crypto from 'crypto';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { HttpError } from './registry';
import { UPDATE_PUBLIC_KEY_PEM } from './updateKey';

/**
 * 자동 업데이트. 배포 zip 은 공개 저장소의 Release 에 올라가며, 받는 쪽은 다음을 모두 통과해야 설치한다.
 *  1. manifest(latest.json)의 주소는 https
 *  2. zip 의 SHA-256 이 manifest 와 같음
 *  3. zip 의 Ed25519 서명이 프로그램에 든 공개 키로 확인됨(배포 PC 의 개인 키로만 만들 수 있음)
 *  4. zip 안에는 배포 대상 파일만 있음(UPDATE_FILES 밖의 경로는 거부)
 * 설치는 zip 에 든 파일만 덮어쓴다. config.json, data/, secrets/, logs/ 등은 건드리지 않는다.
 */

/** 배포 zip 에 들어갈 수 있는 최상위 경로. release.ts 도 이 목록으로 zip 을 만든다. */
export const UPDATE_FILES = ['src', 'public', 'package.json', 'package-lock.json', 'tsconfig.json', 'launcher.ps1', 'auto-tax.vbs'];

const MAX_MANIFEST_BYTES = 64 * 1024;
const MAX_ZIP_BYTES = 80 * 1024 * 1024;

export interface UpdateManifest {
  version: string;
  zipUrl: string;
  sha256: string;
  signature: string;
  notes?: string;
  releasedAt?: string;
}

export interface UpdateCheck {
  configured: boolean;
  current: string;
  latest: string | null;
  available: boolean;
  notes: string;
}

export function readCurrentVersion(root: string = process.cwd()): string {
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf-8'));
  return String(pkg.version);
}

/** 버전 비교(1.2.3 형식). a > b 이면 양수. */
export function compareVersions(a: string, b: string): number {
  const pa = a.split('.').map(Number);
  const pb = b.split('.').map(Number);
  for (let i = 0; i < 3; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d > 0 ? 1 : -1;
  }
  return 0;
}

export function parseManifest(raw: unknown): UpdateManifest {
  const m = raw as Record<string, unknown>;
  const str = (v: unknown) => (typeof v === 'string' ? v : '');
  const version = str(m?.version);
  const zipUrl = str(m?.zipUrl);
  const sha256 = str(m?.sha256);
  const signature = str(m?.signature);
  if (!/^\d+\.\d+\.\d+$/.test(version)) throw new HttpError(502, '업데이트 정보의 버전 형식이 올바르지 않습니다.');
  if (!/^https:\/\//i.test(zipUrl)) throw new HttpError(502, '업데이트 파일 주소는 https 여야 합니다.');
  if (!/^[0-9a-f]{64}$/i.test(sha256)) throw new HttpError(502, '업데이트 정보의 체크섬 형식이 올바르지 않습니다.');
  if (!signature) throw new HttpError(502, '업데이트 정보에 서명이 없습니다.');
  return { version, zipUrl, sha256, signature, notes: str(m?.notes), releasedAt: str(m?.releasedAt) };
}

async function download(url: string, maxBytes: number): Promise<Buffer> {
  if (!/^https:\/\//i.test(url)) throw new HttpError(502, '업데이트 주소는 https 여야 합니다.');
  let res: Response;
  try {
    res = await fetch(url, { signal: AbortSignal.timeout(60_000) });
  } catch (err: any) {
    throw new HttpError(502, `업데이트 서버에 연결하지 못했습니다: ${err?.message || err}`);
  }
  if (!res.ok) throw new HttpError(502, `업데이트 파일을 받지 못했습니다(${res.status}).`);
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length > maxBytes) throw new HttpError(502, '업데이트 파일이 너무 큽니다.');
  return buf;
}

export async function fetchManifest(manifestUrl: string): Promise<UpdateManifest> {
  const buf = await download(manifestUrl, MAX_MANIFEST_BYTES);
  let parsed: unknown;
  try {
    parsed = JSON.parse(buf.toString('utf-8'));
  } catch {
    throw new HttpError(502, '업데이트 정보를 읽을 수 없습니다.');
  }
  return parseManifest(parsed);
}

export async function checkForUpdate(manifestUrl: string, root: string = process.cwd()): Promise<UpdateCheck> {
  const current = readCurrentVersion(root);
  if (!manifestUrl) return { configured: false, current, latest: null, available: false, notes: '' };
  const m = await fetchManifest(manifestUrl);
  return {
    configured: true,
    current,
    latest: m.version,
    available: compareVersions(m.version, current) > 0,
    notes: m.notes || '',
  };
}

/** zip 의 체크섬과 서명을 확인한다. 하나라도 틀리면 설치하지 않도록 예외를 던진다. */
export function verifyPackage(zip: Buffer, m: UpdateManifest, publicKeyPem: string = UPDATE_PUBLIC_KEY_PEM): void {
  if (!publicKeyPem.includes('BEGIN PUBLIC KEY')) throw new HttpError(500, '이 프로그램에 업데이트 공개 키가 없어 설치할 수 없습니다.');
  const digest = crypto.createHash('sha256').update(zip).digest('hex');
  if (digest !== m.sha256.toLowerCase()) throw new HttpError(502, '다운로드한 파일의 체크섬이 맞지 않습니다. 설치하지 않았습니다.');
  const ok = crypto.verify(null, zip, crypto.createPublicKey(publicKeyPem), Buffer.from(m.signature, 'base64'));
  if (!ok) throw new HttpError(502, '업데이트 파일의 서명이 맞지 않습니다. 설치하지 않았습니다.');
}

/** zip 안의 경로가 배포 대상(UPDATE_FILES) 안에 있는지 확인한다. 상위 폴더(..)나 절대 경로는 거부한다. */
export function validateEntries(relPaths: string[]): void {
  if (!relPaths.includes('package.json') || !relPaths.some((p) => p.startsWith('src/'))) {
    throw new HttpError(502, '업데이트 파일 구성이 올바르지 않습니다(package.json, src 가 필요합니다).');
  }
  for (const rel of relPaths) {
    const parts = rel.split('/');
    if (path.isAbsolute(rel) || parts.includes('..') || parts.includes('')) {
      throw new HttpError(502, `업데이트 파일에 허용되지 않은 경로가 있습니다: ${rel}`);
    }
    if (!UPDATE_FILES.includes(parts[0])) {
      throw new HttpError(502, `업데이트 파일에 허용되지 않은 항목이 있습니다: ${rel}`);
    }
  }
}

function listFiles(dir: string, base = dir): string[] {
  const out: string[] = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...listFiles(full, base));
    else out.push(path.relative(base, full).split(path.sep).join('/'));
  }
  return out;
}

function runPowerShell(script: string, env: Record<string, string>): Promise<void> {
  return new Promise((resolve, reject) => {
    execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script],
      { env: { ...process.env, ...env }, windowsHide: true, timeout: 300_000 },
      (err, _stdout, stderr) => (err ? reject(new Error(String(stderr || err.message).trim())) : resolve())
    );
  });
}

function runNpmInstall(root: string): Promise<boolean> {
  return new Promise((resolve) => {
    execFile(
      'cmd.exe',
      ['/c', 'npm install --no-audit --no-fund'],
      { cwd: root, windowsHide: true, timeout: 600_000 },
      (err) => resolve(!err)
    );
  });
}

export interface ApplyResult {
  from: string;
  to: string;
  depsChanged: boolean;
  backupDir: string;
}

/**
 * 업데이트를 내려받아 검증한 뒤 설치한다. 설치 전에 바뀔 파일을 backupDir 에 백업하고,
 * 패키지 설치가 실패하면 백업으로 되돌린다. 설치 후 재시작은 restartServerSoon() 으로 한다.
 */
export async function applyUpdate(manifestUrl: string, root: string = process.cwd()): Promise<ApplyResult> {
  const current = readCurrentVersion(root);
  const m = await fetchManifest(manifestUrl);
  if (compareVersions(m.version, current) <= 0) throw new HttpError(400, '이미 최신 버전입니다.');

  const zip = await download(m.zipUrl, MAX_ZIP_BYTES);
  verifyPackage(zip, m);

  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'autotax-update-'));
  try {
    const zipPath = path.join(work, 'package.zip');
    const dest = path.join(work, 'files');
    fs.writeFileSync(zipPath, zip);
    fs.mkdirSync(dest);
    await runPowerShell('Expand-Archive -LiteralPath $env:AT_ZIP -DestinationPath $env:AT_DEST -Force', {
      AT_ZIP: zipPath,
      AT_DEST: dest,
    });

    const files = listFiles(dest);
    validateEntries(files);
    const newPkg = JSON.parse(fs.readFileSync(path.join(dest, 'package.json'), 'utf-8'));
    if (newPkg.version !== m.version) throw new HttpError(502, '패키지 버전이 업데이트 정보와 다릅니다.');

    // 설치 전 백업: 기존 파일은 복사해 두고, 새로 생기는 파일은 목록만 남긴다(되돌릴 때 지운다).
    const backupDir = path.join(root, '.update-backup', `${current}-${Date.now()}`);
    const existing: string[] = [];
    const created: string[] = [];
    for (const rel of files) {
      const target = path.join(root, rel);
      if (fs.existsSync(target)) {
        fs.mkdirSync(path.dirname(path.join(backupDir, rel)), { recursive: true });
        fs.copyFileSync(target, path.join(backupDir, rel));
        existing.push(rel);
      } else {
        created.push(rel);
      }
    }
    fs.mkdirSync(backupDir, { recursive: true });
    fs.writeFileSync(path.join(backupDir, '_created.json'), JSON.stringify(created, null, 2));

    // 의존성(dependencies/devDependencies)이나 잠금 파일이 바뀐 경우에만 npm install 을 다시 한다.
    const depsChanged = dependenciesChanged(root, dest);

    for (const rel of files) {
      const target = path.join(root, rel);
      fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.copyFileSync(path.join(dest, rel), target);
    }

    if (depsChanged && !(await runNpmInstall(root))) {
      restoreBackup(root, backupDir, existing, created);
      throw new HttpError(502, '새 패키지를 설치하지 못해 이전 버전으로 되돌렸습니다. 콘솔에서 npm install 을 직접 실행해 확인하세요.');
    }

    return { from: current, to: m.version, depsChanged, backupDir: path.relative(root, backupDir) };
  } finally {
    fs.rmSync(work, { recursive: true, force: true });
  }
}

function readDeps(dir: string): string {
  const pkgFile = path.join(dir, 'package.json');
  if (!fs.existsSync(pkgFile)) return '';
  const pkg = JSON.parse(fs.readFileSync(pkgFile, 'utf-8'));
  return JSON.stringify({ dependencies: pkg.dependencies ?? {}, devDependencies: pkg.devDependencies ?? {} });
}

function dependenciesChanged(oldDir: string, newDir: string): boolean {
  if (readDeps(oldDir) !== readDeps(newDir)) return true;
  const oldLock = path.join(oldDir, 'package-lock.json');
  const newLock = path.join(newDir, 'package-lock.json');
  if (!fs.existsSync(newLock)) return false;
  if (!fs.existsSync(oldLock)) return true;
  return !fs.readFileSync(newLock).equals(fs.readFileSync(oldLock));
}

function restoreBackup(root: string, backupDir: string, existing: string[], created: string[]) {
  for (const rel of existing) fs.copyFileSync(path.join(backupDir, rel), path.join(root, rel));
  for (const rel of created) fs.rmSync(path.join(root, rel), { force: true });
}

/**
 * 몇 초 뒤 서버를 다시 띄운다(npm run start). 현재 프로세스는 이 함수를 부른 쪽에서 종료한다.
 * 포트가 풀릴 때까지 잠깐 기다렸다가 시작하며, 로그는 기존 로그 파일에 이어 쓴다.
 */
export function restartServerSoon(root: string = process.cwd()): void {
  const logFile = path.join(root, 'logs', 'server.log');
  fs.mkdirSync(path.dirname(logFile), { recursive: true });
  const script = `ping -n 4 127.0.0.1 >nul & npm run start >> "${logFile}" 2>&1`;
  const child = spawn('cmd.exe', ['/c', script], { cwd: root, detached: true, stdio: 'ignore', windowsHide: true });
  child.unref();
}
