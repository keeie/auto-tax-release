import { GenerationData } from '../types';

export function parseGenerationData(
  subject: string,
  bodyText: string = '',
  defaultBusinessName: string = ''
): GenerationData {
  const fullText = `${subject}\n${bodyText}`;
  const data: GenerationData = {
    businessName: defaultBusinessName || undefined,
  };

  // 1. 발전소명 / 상호명 추출 (○ 발전소명 : 테스트발전소)
  const plantNameMatch = fullText.match(
    /(?:○|\*|-)?\s*(?:발전소명|상호명|상호|사업장명|고객명)\s*[:\s]+\s*([^\n\r,()<>{}[\]]{2,50})/
  );
  if (plantNameMatch) {
    const extractedPlant = plantNameMatch[1].trim();
    data.plantName = extractedPlant;
    data.businessName = extractedPlant;
  } else if (!data.businessName) {
    const keywordMatch = fullText.match(/([가-힣A-Za-z0-9]+(?:태양광|발전소|솔라|에너지))/);
    if (keywordMatch) {
      data.businessName = keywordMatch[1].trim();
      data.plantName = data.businessName;
    }
  } else {
    data.plantName = data.businessName;
  }

  // 2. 주소 추출 (○ 주 소 : 서울특별시 테스트구 테스트로 1)
  const addressMatch = fullText.match(
    /(?:○|\*|-)?\s*주\s*소\s*[:\s]+\s*([^\n\r]+)/
  );
  if (addressMatch) {
    data.address = addressMatch[1].trim();
  }

  // 3. 용량 추출 (○ 용 량 : 99 kW)
  const capacityMatch = fullText.match(
    /(?:○|\*|-)?\s*용\s*량\s*[:\s]+\s*([0-9.,]+\s*(?:kW|kw|MW|mw|W|w)?|[^\n\r]+)/
  );
  if (capacityMatch) {
    data.capacity = capacityMatch[1].trim();
  }

  // 4. 발전기간 추출 (○ 발전기간 : 2026.08.01 ~ 2026.08.31)
  const explicitPeriodMatch = fullText.match(
    /(?:○|\*|-)?\s*발전기간\s*[:\s]+\s*([0-9]{4}[.-/][0-9]{1,2}[.-/][0-9]{1,2}\s*[~-]\s*[0-9]{4}[.-/][0-9]{1,2}[.-/][0-9]{1,2})/
  );
  if (explicitPeriodMatch) {
    data.generationPeriod = explicitPeriodMatch[1].trim();
  } else {
    const periodRangeMatch = fullText.match(
      /(\d{4}[.-/]\d{1,2}[.-/]\d{1,2})\s*[~-]\s*(\d{4}[.-/]\d{1,2}[.-/]\d{1,2})/
    );
    if (periodRangeMatch) {
      data.generationPeriod = `${periodRangeMatch[1]} ~ ${periodRangeMatch[2]}`;
    } else {
      const yearMonthMatch = fullText.match(/(20\d{2}|\d{2})[년.-](\s*\d{1,2})월?(?:\s*분)?/);
      if (yearMonthMatch) {
        let year = yearMonthMatch[1];
        if (year.length === 2) year = `20${year}`;
        const month = yearMonthMatch[2].replace(/\s+/g, '').padStart(2, '0');
        data.generationPeriod = `${year}년 ${month}월`;
      }
    }
  }

  // 5. 공급가액 추출 ([공급가액 : 1,758,273원 VAT : 175,827원] 또는 "공급가액 기준 1,758,273원")
  const supplyMatch = fullText.match(
    /(?:공급가액|공급가|공급금액)(?:\s*기준)?[:\s]*([0-9,]+)\s*원?/
  );
  if (supplyMatch) {
    data.supplyAmount = parseAmount(supplyMatch[1]);
  }

  // 6. VAT (세액) 추출 (VAT : 175,827원(일반사업자) 또는 세액/부가가치세)
  const taxMatch = fullText.match(
    /(?:VAT|부가가치세|세액|부가세)[:\s]*([0-9,]+)\s*원?/i
  );
  if (taxMatch) {
    data.taxAmount = parseAmount(taxMatch[1]);
  }

  // 합계금액 (공급가액 + VAT 또는 직접 명시된 합계)
  if (data.supplyAmount !== undefined && data.taxAmount !== undefined) {
    data.totalAmount = data.supplyAmount + data.taxAmount;
  } else {
    const totalMatch = fullText.match(
      /(?:합계금액|총금액|지급금액)[:\s]*([0-9,]+)\s*원?/
    );
    if (totalMatch) {
      data.totalAmount = parseAmount(totalMatch[1]);
    }
  }

  // 7. 상세내역 > 발전량 추출
  // 한전 표 패턴: "전월지침 당월지침 차감지침 계기배수 발전량 \n 233.44 529.66 296.22 40 11,849"
  // 또는 "전력구입량(kWh) ... 11,849 kWh"
  const tableGenMatch = fullText.match(
    /전월지침[\s\S]*?발전량[\s\r\n]+(?:[\d.,]+\s+){4}([\d,]+(?:\.\d+)?)/
  );
  if (tableGenMatch) {
    data.generationAmount = parseFloat(tableGenMatch[1].replace(/,/g, ''));
  } else {
    const powerPurchaseMatch = fullText.match(
      /전력구입량\s*\(kWh\)[\s\S]*?([\d,]+(?:\.\d+)?)\s*kWh/i
    );
    if (powerPurchaseMatch) {
      data.generationAmount = parseFloat(powerPurchaseMatch[1].replace(/,/g, ''));
    } else {
      const generalGenMatch = fullText.match(
        /(?:발전량|송전량|검침량)[:\s]*([0-9,.]+)\s*(?:kWh|MWh|kwh|mwh|kw)?/i
      );
      if (generalGenMatch) {
        data.generationAmount = parseFloat(generalGenMatch[1].replace(/,/g, ''));
      }
    }
  }

  // 8. 상세내역 > 기준단가 추출
  // 한전 표 패턴: "구입단가(원) 기준단가 SMP 단가 손실단가 \n 148.39 원/kWh 148.39 원/kWh 160.14 원/kWh"
  // 또는 "기준단가 ... 148.39 원/kWh"
  const basePriceMatch = fullText.match(
    /기준단가[\s\S]*?([0-9,]+(?:\.[0-9]+)?)\s*원\/kWh/
  );
  if (basePriceMatch) {
    data.basePrice = parseFloat(basePriceMatch[1].replace(/,/g, ''));
  } else {
    const singleBasePriceMatch = fullText.match(
      /(?:기준단가|기준가격)[:\s]*([0-9,]+(?:\.[0-9]+)?)\s*(?:원\/kWh|원)?/
    );
    if (singleBasePriceMatch) {
      data.basePrice = parseFloat(singleBasePriceMatch[1].replace(/,/g, ''));
    }
  }

  // 고객번호 / 계약번호 추출
  const contractMatch = fullText.match(/(?:고객번호|계약번호|접수번호)[:\s]*([0-9-]+)/);
  if (contractMatch) {
    data.contractNumber = contractMatch[1].trim();
  }

  // 발전 기간 기본값
  if (!data.generationPeriod) {
    data.generationPeriod = '미분류';
  }

  // 추출된 상세 데이터 매핑
  data.extractedDetails = {
    plantName: data.plantName || '',
    address: data.address || '',
    capacity: data.capacity || '',
    generationPeriod: data.generationPeriod || '',
    supplyAmount: data.supplyAmount || 0,
    taxAmount: data.taxAmount || 0,
    totalAmount: data.totalAmount || 0,
    generationAmount: data.generationAmount || 0,
    basePrice: data.basePrice || 0,
  };

  return data;
}

function parseAmount(val: string): number {
  const cleaned = val.replace(/[^0-9]/g, '');
  return parseInt(cleaned, 10) || 0;
}
