import { Page } from 'playwright';
import { FolderConfig, MailItem } from '../types';
import { parseGenerationData } from './parser';

export interface ScraperOptions {
  mailboxId?: string; // 네이버 메일함 폴더 번호(없으면 folder.folderId)
  maxMails?: number;
  onlyUnread?: boolean;
  timeoutMs?: number;
}

/** 답장·전달 접두어(RE:, FW:, Fwd:, 전달:, 답장:)를 여러 번 붙어 있어도 떼어 낸다. */
const REPLY_PREFIX = /^\s*(?:(?:re|fw|fwd)\s*[:：]|(?:전달|답장)\s*[:：])\s*/i;

export function stripReplyPrefix(subject: string): string {
  let out = (subject || '').trim();
  let prev: string;
  do {
    prev = out;
    out = out.replace(REPLY_PREFIX, '');
  } while (out !== prev);
  return out.trim();
}

export function isForwardedSubject(subject: string): boolean {
  return stripReplyPrefix(subject) !== (subject || '').trim();
}

export function isTargetKepcoMail(senderName: string, senderEmail: string, subject: string): boolean {
  // 접두어('보낸 사람\n', '메일 제목\n' 등) 제거 및 정규화
  const cleanSender = (senderName || '').replace(/^보낸\s*사람\s*[:\n\r]*/i, '').trim();
  const cleanSubject = stripReplyPrefix((subject || '').replace(/^메일\s*제목\s*[:\n\r]*/i, '').trim());

  const normSender = cleanSender.replace(/\s+/g, '');
  const normEmail = (senderEmail || '').toLowerCase();
  const normSubject = cleanSubject.replace(/\s+/g, '');

  // 1. 발신자 "한국전력공사" 검사. 전달(FW:) 메일은 발신자가 나 자신이므로 제목으로만 판단한다.
  const isKepcoSender =
    normSender.includes('한국전력공사') ||
    normSender.includes('한국전력') ||
    normEmail.includes('kepco') ||
    cleanSubject.includes('한국전력공사');
  const isForwarded = isForwardedSubject(subject || '');

  // 2. 제목 "신재생에너지 요금안내"로 시작하는지 검사
  const isTargetSubject =
    normSubject.startsWith('신재생에너지요금안내') ||
    cleanSubject.startsWith('신재생에너지 요금안내') ||
    cleanSubject.startsWith('신재생에너지요금안내');

  return (isKepcoSender || isForwarded) && isTargetSubject;
}

async function extractMailDetailText(page: Page): Promise<string> {
  // 본문 렌더링 대기
  await page.waitForTimeout(2000);

  let fullBodyText = '';

  // 1. iframe 내부 본문 탐색 (네이버 메일 본문 iframe)
  const frames = page.frames();
  for (const frame of frames) {
    if (frame === page.mainFrame()) continue;
    try {
      const frameText = await frame.locator('body').innerText({ timeout: 2000 }).catch(() => '');
      if (frameText && frameText.length > 50) {
        fullBodyText += '\n' + frameText;
      }
    } catch {}
  }

  // 2. 메인 프레임 내 상세 보기 컨테이너 탐색
  const bodySelectors = [
    'div[class*="mail_view_body"]',
    'div[class*="mail_body"]',
    'div[class*="view_body"]',
    'div[class*="mail_view"]',
    'div[class*="MailView"]',
    'div[class*="read_content"]',
    '#mail_read_scroll',
    'div.mail_content',
    'div[class*="mail_content"]',
    'div[class*="content_area"]',
    'div[class*="viewer"]',
  ];

  for (const sel of bodySelectors) {
    try {
      const el = page.locator(sel).first();
      if (await el.isVisible({ timeout: 500 }).catch(() => false)) {
        const txt = await el.innerText().catch(() => '');
        if (txt && txt.length > 50) {
          fullBodyText += '\n' + txt;
        }
      }
    } catch {}
  }

  // 3. 만약 위에서 충분한 텍스트를 찾지 못했다면 전체 페이지 본문 텍스트 사용
  if (!fullBodyText || fullBodyText.trim().length < 50) {
    const mainBody = await page.locator('body').innerText().catch(() => '');
    fullBodyText = mainBody;
  }

  return fullBodyText.trim();
}

export async function scrapeFolderMails(
  page: Page,
  folder: FolderConfig,
  options: ScraperOptions = {}
): Promise<MailItem[]> {
  const { timeoutMs = 30000, onlyUnread = false, maxMails = 10 } = options;
  const mailboxId = options.mailboxId ?? folder.folderId;
  const targetUrl = `https://mail.naver.com/v2/folders/${encodeURIComponent(mailboxId)}`;

  console.log(`[Scraper] 폴더 이동 중: ${folder.businessName} (메일함: ${mailboxId}) -> ${targetUrl}`);
  await page.goto(targetUrl, { waitUntil: 'domcontentloaded', timeout: timeoutMs });
  await page.waitForTimeout(2000);

  // 메일 목록 로딩 대기
  try {
    await page.waitForSelector(
      'ol.mail_list, ul.mail_list, [class*="mail_list"], [class*="MailList"], li[class*="mail_item"], [class*="empty"]',
      { timeout: 10000 }
    );
  } catch {
    console.log('[Scraper] 메일 목록 로딩 대기 타임아웃, 현재 DOM에서 확인 시도...');
  }

  await page.waitForTimeout(1000);

  // 빈 메일함 확인
  const isEmpty = await page
    .locator('[class*="empty"], [class*="Empty"], p:has-text("메일이 없습니다")')
    .first()
    .isVisible({ timeout: 1000 })
    .catch(() => false);

  if (isEmpty) {
    console.log(`[Scraper] 폴더 [${folder.businessName}]에 메일이 없습니다.`);
    return [];
  }

  // 메일 항목 추출
  const collectedMails: MailItem[] = [];

  // 브라우저 DOM 내의 메일 리스트 탐색
  const mailElements = await page.locator(
    'li[class*="mail_item"], div[class*="mail_item"], [class*="MailItem"], [class*="mail_item_"]'
  ).all();

  console.log(`[Scraper] 화면에서 감지된 메일 행 수: ${mailElements.length}개`);

  // 최신 메일부터 순회하며 '한국전력공사' 발신 메일 1건 탐색
  for (let i = 0; i < mailElements.length; i++) {
    const el = mailElements[i];

    try {
      // 1. 읽지 않음(신규 메일) 여부 확인
      const unreadEl = el.locator('[class*="unread"], [aria-label*="안읽음"], .is_unread, [class*="is_read_false"]');
      const isUnread = (await unreadEl.count()) > 0 || (await el.getAttribute('class'))?.includes('unread') || false;

      if (onlyUnread && !isUnread) {
        continue;
      }

      // 2. 제목 추출
      const subjectEl = el.locator(
        '[class*="subject"], [class*="title"], [class*="mail_title"], strong[class*="text"], a.title'
      ).first();
      const subject = (await subjectEl.innerText().catch(() => '')).trim() || '제목 없음';

      // 3. 발신자 정보 추출
      const senderEl = el.locator(
        '[class*="sender"], [class*="from"], [class*="name"], .name, a[class*="sender"]'
      ).first();
      const senderName = (await senderEl.innerText().catch(() => '')).trim() || '발신자 미상';

      // 발신자 이메일 (title 또는 data 속성)
      const senderEmail =
        (await senderEl.getAttribute('title').catch(() => '')) ||
        (await senderEl.getAttribute('data-email').catch(() => '')) ||
        '';

      // [1-1] 보낸사람 "한국전력공사" 및 제목 "신재생에너지 요금안내" 시작 필터링
      if (!isTargetKepcoMail(senderName, senderEmail, subject)) {
        continue;
      }

      // 4. 수신 일시 추출
      const dateEl = el.locator('[class*="date"], [class*="time"], time, span[class*="time"]').first();
      const receivedDate = (await dateEl.innerText().catch(() => '')).trim() || new Date().toISOString();

      // 5. 미리보기 본문(snippet) 추출
      const previewEl = el.locator('[class*="preview"], [class*="snippet"], [class*="summary"], [class*="desc"]').first();
      const previewText = (await previewEl.innerText().catch(() => '')).trim();

      // 6. 첨부파일 유무
      const attachEl = el.locator('[class*="clip"], [class*="attach"], [class*="file"], [aria-label*="첨부"]');
      const hasAttachment = (await attachEl.count()) > 0;

      // 7. 메일 고유 식별자 추출
      const mailId =
        (await el.getAttribute('data-id')) ||
        (await el.getAttribute('id')) ||
        `mail_${folder.folderId}_${i}_${encodeURIComponent(subject.slice(0, 15))}`;

      console.log(`[Scraper] [한국전력공사 메일 발견] "${subject}" (${receivedDate}, ${senderName})`);
      console.log(`[Scraper] 메일 상세페이지 진입하여 데이터 추출 진행...`);

      // [1-3] 메일 상세페이지 들어가서 세부 데이터 추출
      let opened = false;
      const clickCandidates = [
        el.locator('a.title, a[class*="mail_title"], [class*="subject"] a, a[class*="link"]').first(),
        el.locator('[class*="subject"], [class*="title"]').first(),
        el,
      ];

      for (const candidate of clickCandidates) {
        if (await candidate.isVisible({ timeout: 1000 }).catch(() => false)) {
          await candidate.click({ timeout: 3000 }).catch(() => {});
          opened = true;
          break;
        }
      }

      let bodyText = '';
      if (opened) {
        bodyText = await extractMailDetailText(page);
        console.log(`[Scraper] 메일 상세 본문 추출 완료 (${bodyText.length}자)`);
      } else {
        console.warn('[Scraper] 메일 클릭 실패로 미리보기 본문을 활용합니다.');
        bodyText = previewText;
      }

      // [1-3] 공급가액, VAT, 발전소명, 주소, 용량, 발전기간, 발전량, 기준단가 파싱
      const generationData = parseGenerationData(subject, bodyText, folder.businessName);

      console.log(`[Scraper] --- 추출 데이터 확인 ---`);
      console.log(`  - 발전소명: ${generationData.plantName || generationData.businessName || '미상'}`);
      console.log(`  - 주소: ${generationData.address || '미상'}`);
      console.log(`  - 용량: ${generationData.capacity || '미상'}`);
      console.log(`  - 발전기간: ${generationData.generationPeriod || '미분류'}`);
      console.log(`  - 공급가액: ${generationData.supplyAmount?.toLocaleString() || 0} 원`);
      console.log(`  - VAT: ${generationData.taxAmount?.toLocaleString() || 0} 원`);
      console.log(`  - 합계금액: ${generationData.totalAmount?.toLocaleString() || 0} 원`);
      console.log(`  - 발전량: ${generationData.generationAmount?.toLocaleString() || 0} kWh`);
      console.log(`  - 기준단가: ${generationData.basePrice || 0} 원/kWh`);
      console.log(`------------------------------`);

      const safePeriodId = generationData.generationPeriod
        ? generationData.generationPeriod.replace(/[^0-9a-zA-Z]/g, '_')
        : `${i}`;
      const finalMailId = mailId || `mail_${folder.folderId}_${safePeriodId}`;

      const mailItem: MailItem = {
        id: finalMailId,
        folderId: folder.folderId,
        folderName: folder.businessName,
        subject,
        senderName,
        senderEmail,
        receivedDate,
        isUnread,
        previewText,
        bodyText,
        hasAttachment,
        generationData,
        collectedAt: new Date().toISOString(),
      };

      collectedMails.push(mailItem);

      // 최신 1건만 수집하므로 즉시 루프 종료
      console.log(`[Scraper] [${folder.businessName}] 최신 한국전력 요금안내 메일 1건 수집 완료.`);
      break;
    } catch (err) {
      console.warn(`[Scraper] ${i + 1}번째 메일 처리 중 오류:`, err);
    }
  }

  console.log(`[Scraper] 폴더 [${folder.businessName}]에서 한국전력공사 메일 총 ${collectedMails.length}개 수집 완료.`);
  return collectedMails;
}
