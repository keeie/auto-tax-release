import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { MailPlatform, PlantMailSettings } from '../types/registry';
import { decryptSecret, encryptSecret, getSecretsDir } from './secretBox';

/**
 * 발전소 메일 계정 정보 정리와 메일 비밀번호 보관.
 *
 * 비밀번호는 계정(플랫폼 + ID)마다 하나씩 secrets/mail/<해시>.enc 에 암호화해 둔다.
 * 같은 계정을 쓰는 발전소가 여러 개여도 비밀번호는 한 번만 입력하면 되고, 바꾸면 모두에 적용된다.
 * 비밀번호는 로그·API 응답·화면 어디에도 내보내지 않는다(저장 여부만 알려 준다).
 */

export class MailSettingsError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'MailSettingsError';
  }
}

export const MAIL_PLATFORMS: MailPlatform[] = ['naver', 'gmail'];
export const platformLabel = (p: MailPlatform) => (p === 'gmail' ? 'Gmail' : '네이버');

const clean = (v: unknown, max: number): string =>
  typeof v === 'string' ? v.replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max) : '';

/** 같은 계정을 같은 키로 묶기 위한 정규화(대소문자 무시, 네이버는 @naver.com 제거) */
export function normalizeAccount(platform: MailPlatform, account: string): string {
  const a = account.trim().toLowerCase();
  return platform === 'naver' ? a.replace(/@naver\.com$/, '') : a;
}

export function accountKey(platform: MailPlatform, account: string): string {
  return `${platform}:${normalizeAccount(platform, account)}`;
}

/** 입력값을 검증해 저장할 메일 설정으로 만든다. */
export function normalizeMailSettings(platformRaw: unknown, accountRaw: unknown, mailboxRaw: unknown): PlantMailSettings {
  const platform = clean(platformRaw, 10) as MailPlatform;
  if (!MAIL_PLATFORMS.includes(platform)) throw new MailSettingsError('메일 플랫폼은 네이버 또는 Gmail 중에서 골라 주세요.');

  const account = normalizeAccount(platform, clean(accountRaw, 100));
  if (!account) throw new MailSettingsError('메일 ID를 입력해 주세요.');
  if (platform === 'naver' && !/^[a-z0-9._-]{2,40}$/.test(account)) {
    throw new MailSettingsError('네이버 ID는 영문 소문자, 숫자, -, _ 로만 입력해 주세요. (예: myid 또는 myid@naver.com)');
  }
  if (platform === 'gmail' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(account)) {
    throw new MailSettingsError('Gmail 은 전체 메일 주소를 입력해 주세요. (예: myid@gmail.com)');
  }

  const mailbox = clean(mailboxRaw, 100);
  if (platform === 'naver' && !/^\d{1,6}$/.test(mailbox)) {
    throw new MailSettingsError('네이버 메일함 폴더 번호는 숫자여야 합니다. (예: 101)');
  }
  if (platform === 'gmail' && !mailbox) throw new MailSettingsError('Gmail 라벨 이름을 입력해 주세요.');

  return { platform, account, mailbox };
}

/** 비밀번호 입력값 정리. Gmail 앱 비밀번호는 "abcd efgh ijkl mnop"처럼 띄어 쓴 그대로 붙여넣어도 되게 공백을 뺀다. */
export function normalizeMailPassword(platform: MailPlatform, raw: unknown): string {
  if (typeof raw !== 'string') return '';
  const pw = platform === 'gmail' ? raw.replace(/\s+/g, '') : raw;
  if (pw.length > 200) throw new MailSettingsError('메일 비밀번호가 너무 깁니다.');
  if (platform === 'gmail' && pw && pw.length !== 16) {
    throw new MailSettingsError('Gmail 앱 비밀번호는 16자리입니다. 일반 Google 비밀번호는 IMAP 접속에 쓸 수 없습니다.');
  }
  return pw;
}

function passwordFile(platform: MailPlatform, account: string): string {
  const hash = crypto.createHash('sha256').update(accountKey(platform, account)).digest('hex').slice(0, 32);
  return path.join(getSecretsDir(), 'mail', `${hash}.enc`);
}

export function hasMailPassword(platform: MailPlatform, account: string): boolean {
  return fs.existsSync(passwordFile(platform, account));
}

export async function saveMailPassword(platform: MailPlatform, account: string, password: string): Promise<void> {
  if (!password) throw new MailSettingsError('메일 비밀번호를 입력해 주세요.');
  const file = passwordFile(platform, account);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = `${file}.tmp`;
  fs.writeFileSync(tmp, await encryptSecret(password), { mode: 0o600 });
  fs.renameSync(tmp, file);
}

/** 수집에서만 사용한다. HTTP 라우트에 연결하지 말 것. */
export async function loadMailPassword(platform: MailPlatform, account: string): Promise<string | undefined> {
  const file = passwordFile(platform, account);
  if (!fs.existsSync(file)) return undefined;
  return decryptSecret(fs.readFileSync(file, 'utf-8'));
}
