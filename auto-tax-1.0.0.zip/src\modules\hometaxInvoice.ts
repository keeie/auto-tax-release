import fs from 'fs';
import path from 'path';
import type { Frame, Page } from 'playwright';
import { HometaxError, HometaxSession, LogFn } from './hometax';

/**
 * 홈택스 로그인 이후 전자세금계산서 건별발급 화면의 발행정보 입력 자동화.
 *
 * 순서: 전체메뉴 → 계산서·영수증·카드 → 전자(세금)계산서 발급 → 전자(세금)계산서 건별발급 →
 *       거래처 조회 → 한국전력공사 선택 → 확인 → 품목 행(일/품목/규격/수량/단가/공급가액/세액) 입력
 *
 * 주의
 * - 입력까지만 한다. "발급하기" 등 발급 버튼은 절대 누르지 않는다(사용자가 화면에서 확인 후 직접 발급).
 * - 메뉴 경로는 2026-10 직접 확인한 값. 건별발급 화면은 로그인 후에만 보여 선택자를 직접 확인하지 못했으므로
 *   화면의 글자(버튼 문구, 표 머리글)로 요소를 찾는다. 찾지 못하면 화면 구조(입력값 제외)를 .debug/ 에 남긴다.
 * - page.evaluate 는 tsx(esbuild) 변환 문제(__name)를 피하려고 문자열 스크립트로 실행한다.
 */

export const PARTNER_NAME = '한국전력공사';
export const ITEM_SPEC = 'kW';

// 홈택스 메뉴 요소 (2026-10 기준, 로그인 전 화면에서 직접 확인한 값. 창 폭 1280 의 반응형 화면)
const SEL = {
  allMenu: '#mf_wfHeader_hdGroup005', // 오른쪽 위 "전체메뉴"
  menuTab: 'a[id$="_tabHTML"]', // 전체메뉴 안의 대분류 탭 (id 가운데가 uuid 라 끝부분으로 찾는다)
  issueGroup: '#grpMenuTextBox_46_4601000000', // "전자(세금)계산서 발급" (title 이 '열려있음(닫기)' 이면 펼쳐진 상태)
  issueEach: '#grpMenuAtag_46_4601010100', // "전자(세금)계산서 건별발급"
};

// 건별발급 화면 요소 (2026-10 실제 로그인 화면의 구조 기록에서 확인. Splr = 공급자, Dmnr = 공급받는자)
const FORM = {
  splrBizNo: '#mf_txppWframe_edtSplrTxprNoTop', // 공급자 등록번호 (화면 준비가 끝나면 로그인한 사업자로 채워진다)
  dmnrLookup: '#mf_txppWframe_btnDmnrClplcInqrTop', // 공급받는자 "거래처 조회" (공급자 쪽에도 같은 문구의 버튼이 있다)
  dmnrName: '#mf_txppWframe_edtDmnrTnmNmTop', // 공급받는자 상호
};

// ---------- 입력값 만들기 (순수 함수: 테스트 가능) ----------

export interface InvoiceSource {
  generationPeriod: string;
  generationAmount: number; // 발전량(kWh)
  basePrice: number; // 기준단가(원/kWh)
  supplyAmount: number; // 공급가액
  taxAmount: number; // 세액
}

export interface InvoiceDraft {
  day: string; // 품목 행의 "일" (오늘, 2자리)
  itemName: string; // "{MM}월 발전대금"
  spec: string;
  quantity: string;
  unitPrice: string;
  supplyAmount: string;
  taxAmount: string;
}

/** 발전기간 문자열(예: "2026.09.01 ~ 2026.09.30", "2024년 05월")에서 발전월(MM)을 읽는다. */
export function generationMonth(period: string): string | null {
  const m = period.match(/(\d{4})\s*[.\-/년]\s*(\d{1,2})(?!\d)/);
  if (!m) return null;
  const month = Number(m[2]);
  return month >= 1 && month <= 12 ? String(month).padStart(2, '0') : null;
}

const KST_DAY = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Seoul', day: '2-digit' });

/** 숫자를 입력창에 칠 문자열로 바꾼다(쉼표 없이, 소수는 필요한 자리까지). */
const numText = (n: number) => String(Math.round(n * 10000) / 10000);

export function buildInvoiceDraft(src: InvoiceSource, now: Date = new Date()): InvoiceDraft {
  const month = generationMonth(src.generationPeriod);
  if (!month) throw new Error(`발전기간(${src.generationPeriod})에서 발전월을 읽을 수 없습니다.`);
  const positive = (n: number) => Number.isFinite(n) && n > 0;
  if (!positive(src.generationAmount)) throw new Error('발전량이 없어 수량을 입력할 수 없습니다.');
  if (!positive(src.basePrice)) throw new Error('기준단가가 없어 단가를 입력할 수 없습니다.');
  if (!positive(src.supplyAmount)) throw new Error('공급가액이 없습니다.');
  if (!(Number.isFinite(src.taxAmount) && src.taxAmount >= 0)) throw new Error('세액이 없습니다.');
  return {
    day: KST_DAY.format(now),
    itemName: `${month}월 발전대금`,
    spec: ITEM_SPEC,
    quantity: numText(src.generationAmount),
    unitPrice: numText(src.basePrice),
    supplyAmount: String(Math.trunc(src.supplyAmount)),
    taxAmount: String(Math.trunc(src.taxAmount)),
  };
}

/** 입력창에서 읽은 값이 입력하려던 값과 같은지(쉼표·공백·숫자 표기 차이는 무시) */
export function sameFieldValue(actual: string, expected: string): boolean {
  const a = actual.replace(/[,\s]/g, '');
  const e = expected.replace(/[,\s]/g, '');
  if (a === e) return true;
  const isNum = (s: string) => /^-?\d+(\.\d+)?$/.test(s);
  return isNum(a) && isNum(e) && Number(a) === Number(e);
}

// ---------- 화면 스크립트 ----------

const HELPERS = `
  var norm = function (s) { return (s || '').replace(/\\s+/g, ''); };
  var visible = function (el) {
    var r = el.getBoundingClientRect();
    if (!(r.width > 0 && r.height > 0)) return false;
    var st = window.getComputedStyle(el);
    return st.visibility !== 'hidden' && st.display !== 'none';
  };
  var labelOf = function (el) { return el.tagName === 'INPUT' ? (el.value || '') : (el.innerText || el.textContent || ''); };
  var clearMark = function (key) {
    var old = document.querySelectorAll('[data-autotax="' + key + '"]');
    for (var i = 0; i < old.length; i++) old[i].removeAttribute('data-autotax');
  };
  var innermost = function (list) {
    return list.filter(function (el) { return !list.some(function (o) { return o !== el && el.contains(o); }); });
  };
  var CLICKABLE = 'a, button, input[type=button], input[type=submit], span, div, li, label';
`;

const script = (body: string, args: unknown) => `((args) => {${HELPERS}\n${body}\n})(${JSON.stringify(args)})`;

/**
 * 거래처 목록에서 거래처명 칸이 이름과 정확히 같은 행의 맨 왼쪽 라디오 버튼에 표시를 붙인다.
 * 홈택스 거래처 조회 창(clplcInqrPopup)의 grdResult 표 라디오를 먼저 보고, 없으면 화면 전체의 표에서 찾는다.
 */
const markPartnerRadio = (name: string) =>
  script(
    `clearMark('partner-pick'); clearMark('partner-radio');
    var collect = function (radios) {
      var out = [];
      for (var i = 0; i < radios.length; i++) {
        var tr = radios[i].closest('tr');
        if (!tr || !visible(tr) || tr.querySelector('input[type=radio]') !== radios[i]) continue;
        for (var c = 0; c < tr.cells.length; c++) {
          if (norm(tr.cells[c].innerText) === norm(args.name)) { out.push(radios[i]); break; }
        }
      }
      return out;
    };
    var hits = collect(document.querySelectorAll('input[type=radio][id*="' + args.grid + '"]'));
    if (!hits.length) hits = collect(document.querySelectorAll('input[type=radio]'));
    if (hits.length !== 1) return hits.length;
    var radio = hits[0];
    radio.setAttribute('data-autotax', 'partner-radio');
    var target = radio;
    if (!visible(radio)) {
      var lbl = radio.id ? document.querySelector('label[for="' + radio.id + '"]') : null;
      target = lbl && visible(lbl) ? lbl : (radio.closest('td') || radio);
    }
    if (target !== radio) target.setAttribute('data-autotax', 'partner-pick');
    return 1;`,
    { name, grid: 'clplcInqrPopup_wframe_grdResult' }
  );

const PARTNER_CHECKED = script(`var r = document.querySelector('[data-autotax="partner-radio"]'); return !!(r && r.checked);`, null);

// 마우스 클릭이 표 위의 다른 요소에 가로막힐 때 라디오 요소에 직접 클릭 이벤트를 보낸다.
const CLICK_PARTNER_RADIO = script(`var r = document.querySelector('[data-autotax="partner-radio"]'); if (!r) return false; r.click(); return true;`, null);

/** 거래처 조회 창의 "확인"(btnProcess) 또는 선택한 라디오에서 가장 가까운 "확인" 버튼에 표시를 붙인다(같은 거리에 여러 개면 개수를 돌려준다). */
const MARK_PARTNER_CONFIRM = script(
  `clearMark('partner-confirm');
  var process = document.getElementById('mf_txppWframe_clplcInqrPopup_wframe_btnProcess');
  if (process && visible(process) && norm(labelOf(process)) === '확인') { process.setAttribute('data-autotax', 'partner-confirm'); return 1; }
  var radio = document.querySelector('[data-autotax="partner-radio"]');
  if (!radio) return 0;
  for (var node = radio.parentElement; node; node = node.parentElement) {
    var hits = [];
    var els = node.querySelectorAll(CLICKABLE);
    for (var i = 0; i < els.length; i++) {
      if (norm(labelOf(els[i])) === '확인' && visible(els[i])) hits.push(els[i]);
    }
    hits = innermost(hits);
    if (hits.length === 1) { hits[0].setAttribute('data-autotax', 'partner-confirm'); return 1; }
    if (hits.length > 1) return hits.length;
  }
  return 0;`,
  null
);

const inputHasValue = (name: string, selector: string) =>
  script(
    `var el = document.querySelector(args.selector);
    return !!(el && norm(el.value).indexOf(norm(args.name)) >= 0);`,
    { name, selector }
  );

// 품목 표의 머리글 → 입력값 키
// idPart: 홈택스 품목 표 머리글 id(mf_txppWframe_grpTxt<idPart>Top)의 가운데 부분. 입력창 id 에도 같은 이름이 들어갈 것으로 보고 마지막 수단으로 쓴다.
const ITEM_COLUMNS: Array<{ header: string; key: keyof InvoiceDraft; idPart: string }> = [
  { header: '일', key: 'day', idPart: 'LsatSplDd' },
  { header: '품목', key: 'itemName', idPart: 'LsatNm' },
  { header: '규격', key: 'spec', idPart: 'LsatRszeNm' },
  { header: '수량', key: 'quantity', idPart: 'LsatQty' },
  { header: '단가', key: 'unitPrice', idPart: 'LsatUtprc' },
  { header: '공급가액', key: 'supplyAmount', idPart: 'LsatSplCft' },
  { header: '세액', key: 'taxAmount', idPart: 'LsatTxamt' },
];

/**
 * 품목 표(머리글에 '품목'과 '규격'이 있는 표)의 첫 입력 행에서 각 열의 입력창에 표시(data-autotax="item-<key>")를 붙인다.
 * 머리글과 입력 행이 서로 다른 table 로 나뉜 그리드도 고려해 열 위치(colspan 포함)로 맞춘다.
 * 표로 찾지 못한 열은 입력창의 title/aria-label 이 머리글과 같은 것으로 찾는다. 찾은 키 목록을 돌려준다.
 */
const MARK_ITEM_INPUTS = script(
  `var EDITABLE = 'input:not([type=hidden]):not([type=checkbox]):not([type=radio]):not([type=button]), textarea';
  args.cols.forEach(function (c) { clearMark('item-' + c.key); });
  var positions = function (tr) {
    var pos = 0, out = [];
    for (var i = 0; i < tr.cells.length; i++) { out.push({ cell: tr.cells[i], start: pos, end: pos + (tr.cells[i].colSpan || 1) }); pos += tr.cells[i].colSpan || 1; }
    return out;
  };
  var editableIn = function (el) {
    var list = el.querySelectorAll(EDITABLE);
    for (var i = 0; i < list.length; i++) if (visible(list[i]) && !list[i].readOnly && !list[i].disabled) return list[i];
    return null;
  };
  var found = {};
  var heads = document.querySelectorAll('th, td');
  for (var h = 0; h < heads.length && Object.keys(found).length === 0; h++) {
    if (norm(heads[h].innerText) !== '품목' || !visible(heads[h])) continue;
    var headRow = heads[h].closest('tr');
    var table = heads[h].closest('table');
    if (!headRow || !table || norm(headRow.innerText).indexOf('규격') < 0) continue;
    var colStart = {};
    positions(headRow).forEach(function (p) { colStart[norm(p.cell.innerText)] = p.start; });
    // 머리글 아래(같은 표 또는 바로 뒤의 표들)에서 입력창이 있는 첫 행
    var tables = Array.prototype.slice.call(document.querySelectorAll('table'));
    var ti = tables.indexOf(table);
    var dataRow = null;
    for (var t = ti; t < tables.length && t <= ti + 3 && !dataRow; t++) {
      var rows = tables[t].rows;
      for (var r = 0; r < rows.length; r++) {
        if (t === ti && rows[r].rowIndex <= headRow.rowIndex) continue;
        if (editableIn(rows[r])) { dataRow = rows[r]; break; }
      }
    }
    if (!dataRow) continue;
    var cells = positions(dataRow);
    args.cols.forEach(function (c) {
      var start = colStart[c.header];
      if (start === undefined) return;
      for (var i = 0; i < cells.length; i++) {
        if (cells[i].start <= start && start < cells[i].end) {
          var inp = editableIn(cells[i].cell);
          if (inp) { inp.setAttribute('data-autotax', 'item-' + c.key); found[c.key] = true; }
          return;
        }
      }
    });
  }
  // 표로 찾지 못한 열: id 에 머리글 id 이름이 들어 있는 입력창 → title / aria-label 이 머리글과 같은 입력창 (각각 첫 번째)
  var usable = function (el) { return visible(el) && !el.readOnly && !el.disabled; };
  args.cols.forEach(function (c) {
    if (found[c.key]) return;
    var list = document.querySelectorAll(EDITABLE);
    var hit = null;
    for (var i = 0; i < list.length && !hit; i++) {
      if ((list[i].id || '').indexOf(c.idPart) >= 0 && usable(list[i])) hit = list[i];
    }
    for (var j = 0; j < list.length && !hit; j++) {
      var t = norm(list[j].getAttribute('title') || list[j].getAttribute('aria-label') || '');
      if ((t === c.header || t === c.header + '입력') && usable(list[j])) hit = list[j];
    }
    if (hit) { hit.setAttribute('data-autotax', 'item-' + c.key); found[c.key] = true; }
  });
  return Object.keys(found);`,
  { cols: ITEM_COLUMNS }
);

// 화면 구조 기록용(입력값은 넣지 않고 길이만 남긴다)
const SNAPSHOT = script(
  `var pick = function (sel, max, fn) { return Array.prototype.slice.call(document.querySelectorAll(sel), 0, max).map(fn); };
  return {
    url: location.href,
    title: document.title,
    inputs: pick('input, textarea, select', 400, function (el) {
      return { tag: el.tagName, id: el.id, name: el.name || '', type: el.type || '', title: el.getAttribute('title') || '', ariaLabel: el.getAttribute('aria-label') || '', readOnly: !!el.readOnly, visible: visible(el), valueLength: (el.value || '').length };
    }),
    buttons: pick('a, button, input[type=button]', 600, function (el) {
      return { tag: el.tagName, id: el.id, text: norm(labelOf(el)).slice(0, 30), visible: visible(el) };
    }).filter(function (b) { return b.visible && b.text; }),
    headers: pick('th', 300, function (el) { return { id: el.id, text: norm(el.innerText).slice(0, 30), visible: visible(el) }; }),
    // 품목 표 구조(입력값 속성은 지운다): 행/입력칸이 어떻게 만들어지는지 확인용
    itemTable: (function () {
      var th = document.querySelector('[id*="grpTxtLsatNm"]');
      var table = th && th.closest('table');
      if (!table) return null;
      var copy = table.cloneNode(true);
      var all = copy.querySelectorAll('*');
      for (var i = 0; i < all.length; i++) { all[i].removeAttribute('value'); }
      // 머리글(th) 밖의 글자(칸에 표시된 값)도 지운다
      var walker = document.createTreeWalker(copy, NodeFilter.SHOW_TEXT);
      var texts = [];
      while (walker.nextNode()) texts.push(walker.currentNode);
      texts.forEach(function (t) { if (!(t.parentElement && t.parentElement.closest('th'))) t.nodeValue = t.nodeValue.trim() ? '#' : ''; });
      return copy.outerHTML.slice(0, 30000);
    })(),
  };`,
  null
);

// ---------- 공통 ----------

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function allFrames(page: Page): Frame[] {
  return page
    .context()
    .pages()
    .filter((p) => !p.isClosed())
    .flatMap((p) => p.frames());
}

/** 모든 창·프레임에서 스크립트를 실행해 결과가 0보다 큰(또는 true) 프레임을 찾는다. */
async function findFrame(page: Page, js: string, timeoutMs: number): Promise<{ frame: Frame; result: number } | { counts: number[] }> {
  const deadline = Date.now() + timeoutMs;
  let counts: number[] = [];
  do {
    counts = [];
    for (const f of allFrames(page)) {
      const r = (await f.evaluate(js).catch(() => 0)) as number;
      if (r === 1) return { frame: f, result: r };
      if (r > 1) counts.push(r);
    }
    if (counts.length) return { counts };
    await sleep(500);
  } while (Date.now() < deadline);
  return { counts };
}

/** 실패 원인 분석용으로 화면 구조를 .debug/ 에 남긴다(입력값 제외). 저장한 경로를 돌려준다. */
export async function saveFormSnapshot(page: Page, reason: string): Promise<string | null> {
  try {
    const frames = [];
    for (const f of allFrames(page)) frames.push(await f.evaluate(SNAPSHOT).catch((e) => ({ url: f.url(), error: String(e).slice(0, 200) })));
    const dir = path.resolve(process.cwd(), '.debug');
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, `hometax-form-${new Date().toISOString().replace(/[:.]/g, '-')}.json`);
    fs.writeFileSync(file, JSON.stringify({ reason, savedAt: new Date().toISOString(), frames }, null, 2), 'utf-8');
    return file;
  } catch {
    return null;
  }
}

// ---------- 발행정보 입력 ----------

export async function fillInvoiceForm(session: HometaxSession, draft: InvoiceDraft, log: LogFn): Promise<void> {
  const { page } = session;
  // 로그인 안내 팝업 자동 닫기를 멈춘다(거래처 조회가 새 창으로 열릴 수 있음).
  session.autoClosePopups = false;

  const dialogs: string[] = [];
  const onDialog = (d: import('playwright').Dialog) => {
    dialogs.push(d.message());
    (d.type() === 'alert' ? d.accept() : d.dismiss()).catch(() => {});
  };
  const watch = (p: Page) => p.on('dialog', onDialog);
  page.context().pages().forEach(watch);
  page.context().on('page', watch);

  const fail = async (code: ConstructorParameters<typeof HometaxError>[0], message: string): Promise<never> => {
    const file = await saveFormSnapshot(page, message);
    const lastDialog = dialogs.length ? ` (홈택스 안내: ${dialogs[dialogs.length - 1].replace(/\s+/g, ' ').slice(0, 120)})` : '';
    throw new HometaxError(code, `${message}${lastDialog}${file ? `\n화면 구조를 저장했습니다: ${path.relative(process.cwd(), file)}` : ''}`, true);
  };

  try {
    // 7. 메뉴 이동
    log('7. 전체메뉴 → 계산서·영수증·카드 → 전자(세금)계산서 발급 → 건별발급으로 이동합니다.');
    try {
      await page.locator(SEL.allMenu).click({ timeout: 15_000 });
      const tab = page.locator(SEL.menuTab, { hasText: '계산서·영수증·카드' }).first();
      await tab.waitFor({ state: 'visible', timeout: 15_000 });
      await tab.click();
      const group = page.locator(SEL.issueGroup);
      const each = page.locator(SEL.issueEach);
      await group.waitFor({ state: 'visible', timeout: 10_000 });
      if (!(await each.isVisible())) await group.click();
      await each.waitFor({ state: 'visible', timeout: 10_000 });
      await each.click();
    } catch (err: any) {
      return await fail('menu-failed', `전자(세금)계산서 건별발급 메뉴로 이동하지 못했습니다: ${String(err?.message || err).split('\n')[0].slice(0, 150)}`);
    }

    // 8. 공급받는자 거래처 조회
    log('8. 건별발급 화면을 기다린 뒤 공급받는자의 거래처 조회를 클릭합니다.');
    const lookupBtn = page.locator(FORM.dmnrLookup);
    try {
      await lookupBtn.waitFor({ state: 'visible', timeout: 60_000 });
    } catch {
      return await fail('form-not-found', `건별발급 화면에서 공급받는자 '거래처 조회' 버튼을 찾지 못했습니다.`);
    }
    // 화면이 막 열렸을 때는 공급자 정보·작성일자가 비어 있다. 로그인한 사업자 정보가 채워질 때까지 기다린다.
    const ready = await page
      .waitForFunction(`(() => { var el = document.querySelector('${FORM.splrBizNo}'); return !!(el && el.value.replace(/\\D/g, '').length >= 10); })()`, null, { timeout: 30_000 })
      .then(() => true, () => false);
    if (!ready) log('공급자 등록번호가 채워지지 않았습니다. 화면 준비가 덜 됐을 수 있지만 계속 진행합니다.', 'warn');
    await lookupBtn.click();

    // 9. 한국전력공사 선택
    log(`9. 거래처 목록에서 ${PARTNER_NAME}을(를) 선택합니다.`);
    const partner = await findFrame(page, markPartnerRadio(PARTNER_NAME), 30_000);
    if (!('frame' in partner)) {
      return await fail(
        partner.counts.length ? 'partner-ambiguous' : 'partner-not-found',
        partner.counts.length
          ? `거래처 목록에 ${PARTNER_NAME} 항목이 여러 개라 안전하게 고를 수 없습니다. 거래처 창에서 직접 선택해 주세요.`
          : `거래처 목록에서 ${PARTNER_NAME}을(를) 찾지 못했습니다. 홈택스 거래처 관리에 등록되어 있는지 확인해 주세요.`
      );
    }
    const pf = partner.frame;
    const pick = pf.locator('[data-autotax="partner-pick"]');
    const clicked = await ((await pick.count()) ? pick : pf.locator('[data-autotax="partner-radio"]'))
      .first()
      .click({ timeout: 5_000 })
      .then(() => true, () => false);
    if (!clicked) {
      log('라디오 버튼 클릭이 화면 요소에 가로막혀 라디오에 직접 클릭을 보냅니다.');
      await pf.evaluate(CLICK_PARTNER_RADIO).catch(() => false);
    }
    let checked = false;
    for (let i = 0; i < 10 && !checked; i++) {
      checked = (await pf.evaluate(PARTNER_CHECKED).catch(() => false)) === true;
      if (!checked) await sleep(300);
    }
    if (!checked) return await fail('partner-not-found', `${PARTNER_NAME} 라디오 버튼 선택을 확인하지 못했습니다.`);

    // 10. 확인
    log('10. 거래처 선택창의 확인을 클릭합니다.');
    const confirmCount = (await pf.evaluate(MARK_PARTNER_CONFIRM).catch(() => 0)) as number;
    if (confirmCount !== 1) {
      return await fail('partner-not-found', confirmCount ? `거래처 선택창의 '확인' 버튼이 여러 개라 고를 수 없습니다.` : `거래처 선택창의 '확인' 버튼을 찾지 못했습니다.`);
    }
    const confirm = pf.locator('[data-autotax="partner-confirm"]');
    if (!(await confirm.click({ timeout: 5_000 }).then(() => true, () => false))) {
      await confirm.evaluate((el) => (el as HTMLElement).click());
    }
    const filled = await page
      .waitForFunction(`(${inputHasValue(PARTNER_NAME, FORM.dmnrName)})`, null, { timeout: 15_000 })
      .then(() => true, () => false);
    if (!filled) return await fail('partner-not-found', `공급받는자 상호에 ${PARTNER_NAME}이(가) 채워지지 않았습니다.`);
    log(`공급받는자에 ${PARTNER_NAME}이(가) 입력되었습니다.`);

    // 11. 품목 행 입력
    log(`11. 품목 행을 입력합니다. (일 ${draft.day} / ${draft.itemName} / ${draft.spec} / 수량 ${draft.quantity} / 단가 ${draft.unitPrice} / 공급가액 ${draft.supplyAmount} / 세액 ${draft.taxAmount})`);
    // 품목 입력칸이 화면 준비 뒤에 만들어질 수 있어 잠시 기다리며 찾는다.
    let itemFrame: Frame | null = null;
    let keys: string[] = [];
    const itemDeadline = Date.now() + 15_000;
    while (keys.length < ITEM_COLUMNS.length && Date.now() < itemDeadline) {
      for (const f of allFrames(page)) {
        const k = ((await f.evaluate(MARK_ITEM_INPUTS).catch(() => [])) as string[]) || [];
        if (k.length > keys.length) {
          keys = k;
          itemFrame = f;
        }
      }
      if (keys.length < ITEM_COLUMNS.length) await sleep(1000);
    }
    const missing = ITEM_COLUMNS.filter((c) => !keys.includes(c.key)).map((c) => c.header);
    if (!itemFrame || missing.length) {
      return await fail('form-not-found', `품목 입력칸을 찾지 못했습니다: ${missing.join(', ')}`);
    }

    // 수량·단가를 넣으면 홈택스가 공급가액·세액을 계산하므로, 명세서 값으로 덮어쓰도록 공급가액·세액은 마지막에 넣는다.
    for (const c of ITEM_COLUMNS) {
      const input = itemFrame.locator(`[data-autotax="item-${c.key}"]`).first();
      await input.click();
      await input.press('Control+A');
      await input.press('Delete');
      await input.pressSequentially(draft[c.key], { delay: 30 });
      await input.press('Tab');
      await sleep(300);
    }

    const wrong: string[] = [];
    for (const c of ITEM_COLUMNS) {
      const actual = await itemFrame.locator(`[data-autotax="item-${c.key}"]`).first().inputValue().catch(() => '');
      if (!sameFieldValue(actual, draft[c.key])) wrong.push(`${c.header}(입력 ${draft[c.key]} / 화면 ${actual || '빈칸'})`);
    }
    if (wrong.length) return await fail('form-mismatch', `입력한 값이 화면과 다릅니다: ${wrong.join(', ')}`);

    log('12. 세금계산서 발행정보 입력을 마쳤습니다. 화면에서 내용을 확인한 뒤 직접 발급해 주세요.', 'success');
  } catch (err: any) {
    if (err instanceof HometaxError) throw err;
    return await fail('page-error', `발행정보 입력 중 오류가 발생했습니다: ${String(err?.message || err).split('\n')[0].slice(0, 200)}`);
  } finally {
    page.context().off('page', watch);
    page.context().pages().forEach((p) => p.off('dialog', onDialog));
  }
}
