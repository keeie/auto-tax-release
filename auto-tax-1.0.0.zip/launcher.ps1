﻿param([switch]$Headless)

# auto-tax 제어 패널: 서버 시작/중지/브라우저 열기/로그 보기
# 실행: auto-tax.vbs (콘솔 창 없이 이 파일을 띄움)

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$port = if ($env:PORT) { [int]$env:PORT } else { 3000 }
$url = "http://127.0.0.1:$port"
$pidFile = Join-Path $root '.run\server.pid'
$logFile = Join-Path $root 'logs\server.log'

function Get-ListenerPid {
  $conn = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($conn) { return [int]$conn.OwningProcess }
  return 0
}

function Test-AutoTaxProcess([int]$targetPid, [string]$pattern) {
  $p = Get-CimInstance Win32_Process -Filter "ProcessId=$targetPid" -ErrorAction SilentlyContinue
  return [bool]($p -and $p.CommandLine -match $pattern)
}

# running: 우리 서버가 포트를 사용 중 / foreign: 다른 프로그램이 사용 중 / stopped: 비어 있음
function Get-ServerState {
  $listenerPid = Get-ListenerPid
  if ($listenerPid -eq 0) { return 'stopped' }
  if (Test-AutoTaxProcess $listenerPid 'src.index\.ts') { return 'running' }
  return 'foreign'
}

function Wait-Until([scriptblock]$condition, [int]$seconds) {
  for ($i = 0; $i -lt ($seconds * 2); $i++) {
    if (& $condition) { return $true }
    Start-Sleep -Milliseconds 500
    if (-not $Headless) { [System.Windows.Forms.Application]::DoEvents() }
  }
  return [bool](& $condition)
}

function Start-Server {
  if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    return 'Node.js가 설치되어 있지 않습니다. https://nodejs.org 에서 LTS 버전을 설치하세요.'
  }
  if ((Get-ServerState) -ne 'stopped') { return '포트가 이미 사용 중입니다.' }

  if (-not (Test-Path (Join-Path $root 'node_modules'))) {
    $install = Start-Process -FilePath 'cmd.exe' -ArgumentList '/c npm install' -WorkingDirectory $root -WindowStyle Hidden -PassThru
    if (-not $Headless) {
      while (-not $install.HasExited) { Start-Sleep -Milliseconds 200; [System.Windows.Forms.Application]::DoEvents() }
    } else {
      $install.WaitForExit()
    }
    if ($install.ExitCode -ne 0) { return 'npm install 실패. 콘솔에서 npm install을 직접 실행해 확인하세요.' }
  }

  New-Item -ItemType Directory -Force -Path (Split-Path $logFile), (Split-Path $pidFile) | Out-Null
  $proc = Start-Process -FilePath 'cmd.exe' -ArgumentList "/c npm run start >> `"$logFile`" 2>&1" -WorkingDirectory $root -WindowStyle Hidden -PassThru
  Set-Content -Path $pidFile -Value $proc.Id -Encoding ascii

  if (Wait-Until { (Get-ServerState) -eq 'running' } 60) { return $null }
  return '60초 안에 서버가 시작되지 않았습니다. 로그를 확인하세요.'
}

function Stop-Server {
  # 시작할 때 저장한 PID(cmd → npm → node 트리)를 먼저 종료
  if (Test-Path $pidFile) {
    $savedPid = (Get-Content $pidFile -ErrorAction SilentlyContinue | Select-Object -First 1)
    if ($savedPid -match '^\d+$' -and (Test-AutoTaxProcess ([int]$savedPid) 'npm run start')) {
      & taskkill /T /F /PID $savedPid | Out-Null
    }
    Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
  }
  # PID 파일이 없을 때 대비: 포트 사용 프로세스가 우리 서버이면 종료
  $listenerPid = Get-ListenerPid
  if ($listenerPid -ne 0 -and (Test-AutoTaxProcess $listenerPid 'src.index\.ts')) {
    & taskkill /T /F /PID $listenerPid | Out-Null
  }
  if (Wait-Until { (Get-ServerState) -eq 'stopped' } 10) { return $null }
  return '서버를 완전히 종료하지 못했습니다.'
}

if ($Headless) {
  Write-Output "state before: $(Get-ServerState)"
  $err = Start-Server
  Write-Output "start result: $err, state: $(Get-ServerState)"
  $err = Stop-Server
  Write-Output "stop result: $err, state: $(Get-ServerState)"
  exit 0
}

# ---------- 패널 UI ----------
[System.Windows.Forms.Application]::EnableVisualStyles()

$form = New-Object System.Windows.Forms.Form
$form.Text = 'auto-tax'
$form.Size = New-Object System.Drawing.Size(440, 250)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.Font = New-Object System.Drawing.Font('Segoe UI', 10)

$title = New-Object System.Windows.Forms.Label
$title.Text = 'auto-tax 서버'
$title.Font = New-Object System.Drawing.Font('Segoe UI', 14, [System.Drawing.FontStyle]::Bold)
$title.Location = New-Object System.Drawing.Point(20, 15)
$title.AutoSize = $true
$form.Controls.Add($title)

$stateLabel = New-Object System.Windows.Forms.Label
$stateLabel.Location = New-Object System.Drawing.Point(22, 56)
$stateLabel.Size = New-Object System.Drawing.Size(390, 24)
$form.Controls.Add($stateLabel)

$msgLabel = New-Object System.Windows.Forms.Label
$msgLabel.Location = New-Object System.Drawing.Point(22, 84)
$msgLabel.Size = New-Object System.Drawing.Size(390, 40)
$msgLabel.ForeColor = [System.Drawing.Color]::DimGray
$form.Controls.Add($msgLabel)

function New-Button([string]$text, [int]$x, [int]$y) {
  $b = New-Object System.Windows.Forms.Button
  $b.Text = $text
  $b.Location = New-Object System.Drawing.Point($x, $y)
  $b.Size = New-Object System.Drawing.Size(92, 36)
  $form.Controls.Add($b)
  return $b
}

$startButton = New-Button '시작' 22 135
$stopButton = New-Button '중지' 122 135
$browserButton = New-Button '브라우저' 222 135
$logButton = New-Button '로그' 322 135

function Update-Ui {
  $state = Get-ServerState
  switch ($state) {
    'running' {
      $stateLabel.Text = "● 실행 중  ($url)"
      $stateLabel.ForeColor = [System.Drawing.Color]::ForestGreen
    }
    'foreign' {
      $stateLabel.Text = "● 포트 $port 를 다른 프로그램이 사용 중"
      $stateLabel.ForeColor = [System.Drawing.Color]::Firebrick
    }
    default {
      $stateLabel.Text = '● 중지됨'
      $stateLabel.ForeColor = [System.Drawing.Color]::Gray
    }
  }
  $startButton.Enabled = ($state -eq 'stopped')
  $stopButton.Enabled = ($state -eq 'running')
}

function Invoke-Busy([string]$message, [scriptblock]$action) {
  $startButton.Enabled = $false
  $stopButton.Enabled = $false
  $msgLabel.Text = $message
  $form.Refresh()
  $result = & $action
  $msgLabel.Text = if ($result) { $result } else { '' }
  Update-Ui
}

$startButton.Add_Click({
  Invoke-Busy '서버를 시작하는 중... (처음이면 패키지 설치로 몇 분 걸릴 수 있습니다)' {
    $err = Start-Server
    if (-not $err) { Start-Process $url }
    $err
  }
})

$stopButton.Add_Click({
  Invoke-Busy '서버를 중지하는 중...' { Stop-Server }
})

$browserButton.Add_Click({ Start-Process $url })

$logButton.Add_Click({
  if (-not (Test-Path $logFile)) { $msgLabel.Text = '아직 로그 파일이 없습니다.'; return }
  Start-Process notepad.exe $logFile
})

# 패널을 닫을 때 서버가 돌고 있으면 계속 둘지, 같이 끌지 묻는다
$form.Add_FormClosing({
  param($sender, $e)
  if ((Get-ServerState) -ne 'running') { return }
  $answer = [System.Windows.Forms.MessageBox]::Show(
    "서버가 실행 중입니다.`n`n예: 서버는 계속 실행하고 패널만 닫기`n아니오: 서버도 중지하고 닫기`n취소: 닫지 않기",
    'auto-tax', [System.Windows.Forms.MessageBoxButtons]::YesNoCancel, [System.Windows.Forms.MessageBoxIcon]::Question)
  if ($answer -eq [System.Windows.Forms.DialogResult]::Cancel) { $e.Cancel = $true }
  elseif ($answer -eq [System.Windows.Forms.DialogResult]::No) { Stop-Server | Out-Null }
})

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 2000
$timer.Add_Tick({ Update-Ui })
$timer.Start()

Update-Ui
[System.Windows.Forms.Application]::Run($form)
