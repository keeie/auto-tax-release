/** 발전소 목록(config.json folders). folderId 는 발전소 식별자이고, 메일함 정보는 registry.json 의 plants[].mail 에 있다. */
export interface FolderConfig {
  folderId: string;
  businessName: string;
  description?: string;
}

export interface AppOptions {
  headless: boolean;
  slowMo?: number;
  outputDir: string;
  maxMailsPerFolder?: number;
  onlyUnread?: boolean;
  /** 업데이트 정보(latest.json) 주소. 비워 두면 자동 업데이트를 쓰지 않는다. */
  updateManifestUrl?: string;
}

export interface AppConfig {
  folders: FolderConfig[];
  options: AppOptions;
}

export interface GenerationData {
  generationPeriod?: string; // 발전 기간 (예: 2026.08.01 ~ 2026.08.31, 2024년 05월)
  businessName?: string;     // 사업자명 / 발전소명
  plantName?: string;        // 발전소명
  address?: string;          // 주소
  capacity?: string;         // 용량 (예: 99 kW)
  supplyAmount?: number;     // 공급가액
  taxAmount?: number;        // VAT (세액)
  totalAmount?: number;      // 합계금액
  generationAmount?: number; // 상세내역 > 발전량 (kWh 등)
  basePrice?: number;        // 상세내역 > 기준단가 (원/kWh 등)
  contractNumber?: string;   // 고객번호 / 계약번호
  extractedDetails?: Record<string, string | number>;
}

export interface MailItem {
  id: string;
  folderId: string;
  folderName: string;
  subject: string;
  senderName: string;
  senderEmail: string;
  receivedDate: string;
  isUnread: boolean;
  previewText?: string;
  bodyText?: string;
  hasAttachment?: boolean;
  generationData: GenerationData;
  collectedAt: string;
}

export interface FolderSummary {
  folderId: string;
  businessName: string;
  totalMails: number;
  newMails: number;
  periods: string[];
  lastUpdated: string;
}

export interface PeriodDataPayload {
  folderId: string;
  businessName: string;
  generationPeriod: string;
  totalItems: number;
  items: MailItem[];
  aggregated: {
    totalSupplyAmount: number;
    totalTaxAmount: number;
    totalAmount: number;
    totalGenerationAmount: number;
  };
  lastUpdated: string;
  invoiceIssued?: boolean; // 세금계산서 발행 완료 여부 (registry.json 에서 덧붙임)
  invoiceIssuedUpdatedAt?: string;
}

export interface BusinessData {
  folderId: string;
  folderName: string;
  businessName: string;
  plantName?: string;
  address?: string;
  capacity?: string;
  contractNumber?: string;
  operatorId?: string;
  operatorName?: string;
  periods: PeriodDataPayload[];
  totalPeriods: number;
  aggregated: {
    totalSupplyAmount: number;
    totalTaxAmount: number;
    totalAmount: number;
    totalGenerationAmount: number;
  };
  lastUpdated: string;
}

export interface OverallStats {
  totalBusinesses: number;
  totalPeriods: number;
  totalGenerationAmount: number;
  totalSupplyAmount: number;
  totalTaxAmount: number;
  totalAmount: number;
  lastCollectedAt?: string;
}

export interface CollectionLog {
  timestamp: string;
  message: string;
  level: 'info' | 'warn' | 'error' | 'success';
}

export interface CollectionStatus {
  status: 'idle' | 'running' | 'completed' | 'error';
  startedAt?: string;
  finishedAt?: string;
  progressMessage?: string;
  error?: string;
  logs: CollectionLog[];
}
