import { loadConfig } from '../config';
import { getLicenseStatus, TRIAL_PLANT_LIMIT } from './license';

/**
 * 라이선스에 따른 발전소 수 제한.
 * - 활성화된 라이선스: 코드에 적힌 최대 발전소 수(없으면 제한 없음).
 * - 체험판(라이선스 파일 없음): 3개.
 * - 만료된 라이선스: 3개. 이미 더 많이 등록되어 있으면 상위 3개(목록 순서)만 수정·발행·순서 변경을 할 수 있다.
 * 메일 수집은 제한과 관계없이 모든 발전소를 대상으로 한다.
 */

export class PlantLimitError extends Error {
  readonly status = 403;
}

export interface PlantLimit {
  /** null 이면 제한 없음 */
  limit: number | null;
  mode: 'licensed' | 'trial' | 'expired';
  expiresAt?: string;
}

export function currentPlantLimit(now: Date = new Date()): PlantLimit {
  const status = getLicenseStatus(now);
  if (status.active) return { limit: status.maxPlants ?? null, mode: 'licensed', expiresAt: status.expiresAt };
  if (status.expiresAt) return { limit: TRIAL_PLANT_LIMIT, mode: 'expired', expiresAt: status.expiresAt };
  return { limit: TRIAL_PLANT_LIMIT, mode: 'trial' };
}

/** 새 발전소를 더 등록할 수 없으면 그 이유 문구를, 등록할 수 있으면 null 을 돌려준다. currentCount 는 지금 등록된 발전소 수. */
export function plantAddBlockReason(currentCount: number, lim: PlantLimit): string | null {
  // 체험판은 발전소 추가 제한이 없다(상위 3개 제어 제한은 별도로 적용된다).
  if (lim.mode === 'trial') return null;
  if (lim.limit === null || currentCount < lim.limit) return null;
  if (lim.mode === 'expired') {
    return `라이선스가 만료되어 발전소는 최대 ${lim.limit}개까지만 등록할 수 있습니다. 새 활성화 코드를 입력해 주세요.`;
  }
  return `라이선스에서 허용한 발전소 수(${lim.limit}개)를 모두 사용했습니다.`;
}

/** 새 발전소를 더 등록할 수 있는지 확인한다. currentCount 는 지금 등록된 발전소 수. */
export function assertCanAddPlant(currentCount: number, lim: PlantLimit): void {
  const reason = plantAddBlockReason(currentCount, lim);
  if (reason) throw new PlantLimitError(reason);
}

/** index(0부터, 발전소 목록 순서)번째 발전소를 action(수정, 순서 변경, 세금계산서 발행)할 수 있는지 확인한다. */
export function assertControllable(index: number, lim: PlantLimit, action: string): void {
  if (lim.limit === null || index < lim.limit) return;
  if (lim.mode === 'trial') {
    throw new PlantLimitError(`체험판은 상위 ${lim.limit}개 발전소만 ${action}할 수 있습니다.`);
  }
  if (lim.mode === 'expired') {
    throw new PlantLimitError(`라이선스가 만료되어 상위 ${lim.limit}개 발전소만 ${action}할 수 있습니다. 새 활성화 코드를 입력해 주세요.`);
  }
  throw new PlantLimitError(`라이선스에서 허용한 발전소 수(${lim.limit}개)를 넘어 ${action}할 수 없습니다.`);
}

/** 발전소 ID 로 제한을 확인한다(목록에 없는 ID 는 확인하지 않는다). */
export function assertFolderControllable(folderId: string, action: string): void {
  const index = loadConfig().folders.findIndex((f) => f.folderId === folderId);
  if (index < 0) return;
  assertControllable(index, currentPlantLimit(), action);
}

/** 순서 변경: 제한 밖(하위) 발전소의 자리는 바꿀 수 없다. 상위 limit 개끼리만 순서를 바꿀 수 있다. */
export function assertReorderAllowed(currentIds: string[], newIds: string[], lim: PlantLimit): void {
  if (lim.limit === null) return;
  for (let i = lim.limit; i < currentIds.length; i++) {
    if (newIds[i] !== currentIds[i]) {
      throw new PlantLimitError(`상위 ${lim.limit}개 발전소 순서만 바꿀 수 있습니다.`);
    }
  }
}

/** 서버 시작 로그에 찍을 한 줄 설명 */
export function describePlantLimit(lim: PlantLimit): string {
  if (lim.mode === 'licensed') {
    return lim.limit === null ? '활성화됨 (발전소 수 제한 없음)' : `활성화됨 (발전소 최대 ${lim.limit}개, 만료 ${lim.expiresAt?.slice(0, 10)})`;
  }
  if (lim.mode === 'expired') return `만료됨 (발전소 상위 ${lim.limit}개만 제어 가능, 만료 ${lim.expiresAt?.slice(0, 10)})`;
  return `체험판 (발전소 최대 ${lim.limit}개)`;
}
