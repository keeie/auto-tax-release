import crypto from 'crypto';

// 개발자 패널 비밀번호. 평문은 저장하지 않고 scrypt 해시만 둔다.
// 해시를 바꾸려면 scrypt 로 새 salt/hash 를 만들어 아래 두 값을 교체한다.
const DEV_SALT_B64 = 'Daa4lL8JepJCz72W+e2j+g==';
const DEV_HASH_B64 = '+WuPTmGb9sBBG5VUQPyoUn67DgQaFE+H/18mZxwaJMCOVevH4vH5NlrLs4sKSMte9EEBk1Rc/xE1dMhUR90FLQ==';
const SCRYPT_OPTIONS = { N: 16384, r: 8, p: 1 };
const SESSION_MS = 30 * 60 * 1000;

const sessions = new Map<string, number>(); // token → 만료 시각(ms), 서버 메모리에만 둔다

export function checkDevPassword(password: string): boolean {
  if (typeof password !== 'string' || password.length === 0 || password.length > 256) return false;
  const expected = Buffer.from(DEV_HASH_B64, 'base64');
  const actual = crypto.scryptSync(password, Buffer.from(DEV_SALT_B64, 'base64'), expected.length, SCRYPT_OPTIONS);
  return crypto.timingSafeEqual(actual, expected);
}

export function createDevSession(now: number = Date.now()): { token: string; expiresAt: number } {
  for (const [token, exp] of sessions) if (exp < now) sessions.delete(token);
  const token = crypto.randomBytes(32).toString('hex');
  const expiresAt = now + SESSION_MS;
  sessions.set(token, expiresAt);
  return { token, expiresAt };
}

export function isDevSessionValid(token: string | undefined, now: number = Date.now()): boolean {
  if (!token) return false;
  const exp = sessions.get(token);
  if (exp === undefined) return false;
  if (exp < now) {
    sessions.delete(token);
    return false;
  }
  return true;
}

export function revokeDevSession(token: string | undefined): void {
  if (token) sessions.delete(token);
}
