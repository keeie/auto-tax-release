import path from 'path';
import { createWorker, OEM, PSM } from 'tesseract.js';

// pdf-parse 는 index.js 가 디버그 코드를 실행하므로 내부 모듈을 직접 불러온다.
// eslint-disable-next-line @typescript-eslint/no-var-requires
const pdfParse = require('pdf-parse/lib/pdf-parse.js') as (data: Buffer) => Promise<{ text: string; numpages: number }>;

export class LicenseError extends Error {
  constructor(message: string, public status: number = 400) {
    super(message);
    this.name = 'LicenseError';
  }
}

export type LicenseFileKind = 'pdf' | 'image';

/** 클라이언트가 보낸 MIME 을 믿지 않고 파일 앞부분(매직 바이트)으로 종류를 판별한다. */
export function sniffFileKind(buf: Buffer): LicenseFileKind | null {
  if (buf.length < 12) return null;
  if (buf.subarray(0, 5).toString('latin1') === '%PDF-') return 'pdf';
  if (buf[0] === 0x89 && buf.subarray(1, 4).toString('latin1') === 'PNG') return 'image';
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image';
  if (buf.subarray(0, 4).toString('latin1') === 'RIFF' && buf.subarray(8, 12).toString('latin1') === 'WEBP') return 'image';
  if (buf[0] === 0x42 && buf[1] === 0x4d) return 'image'; // BMP
  return null;
}

const OCR_TIMEOUT_MS = 180_000; // 최초 실행 시 한글 학습데이터 다운로드 시간 포함
const CACHE_PATH = path.resolve(process.cwd(), '.ocr-cache');

// OCR 은 메모리를 많이 쓰므로 한 번에 하나만 실행한다.
let queue: Promise<unknown> = Promise.resolve();
function runExclusive<T>(task: () => Promise<T>): Promise<T> {
  const next = queue.then(task, task);
  queue = next.catch(() => undefined);
  return next;
}

// 페이지 분할 방식이 다르면 읽히는 칸이 달라진다(실제 사업자등록증 샘플에서 확인). 여러 번 읽고 결과를 합친다.
const OCR_PASSES: PSM[] = [PSM.AUTO, PSM.SINGLE_COLUMN, PSM.SINGLE_BLOCK];

async function ocrImage(buf: Buffer): Promise<string[]> {
  const worker = await createWorker(['kor', 'eng'], OEM.LSTM_ONLY, { cachePath: CACHE_PATH });
  let timer: NodeJS.Timeout | undefined;
  try {
    const run = async () => {
      const texts: string[] = [];
      for (const psm of OCR_PASSES) {
        await worker.setParameters({ tessedit_pageseg_mode: psm });
        const result = await worker.recognize(buf);
        texts.push(result.data.text || '');
      }
      return texts;
    };
    return await Promise.race([
      run(),
      new Promise<never>((_, reject) => {
        timer = setTimeout(() => reject(new LicenseError('이미지 인식 시간이 초과되었습니다.', 504)), OCR_TIMEOUT_MS);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
    await worker.terminate().catch(() => undefined);
  }
}

/**
 * 파일의 글자를 읽는다. texts 는 읽기 방식별 결과(이미지는 여러 번, PDF 는 한 번), text 는 첫 번째 결과.
 * 여러 결과는 licenseParser 의 parseBusinessLicenseTexts 로 합친다.
 */
export async function extractLicenseText(buf: Buffer): Promise<{ kind: LicenseFileKind; text: string; texts: string[] }> {
  const kind = sniffFileKind(buf);
  if (!kind) {
    throw new LicenseError('지원하지 않는 파일 형식입니다. PNG, JPG, WEBP, BMP 이미지 또는 PDF만 업로드할 수 있습니다.', 415);
  }

  if (kind === 'pdf') {
    let text = '';
    try {
      const parsed = await pdfParse(buf);
      text = parsed.text || '';
    } catch (err: any) {
      throw new LicenseError(`PDF를 읽을 수 없습니다: ${err?.message || err}`, 422);
    }
    if (text.replace(/\s/g, '').length < 30) {
      throw new LicenseError(
        '텍스트가 포함되지 않은 스캔(이미지) PDF입니다. 사업자등록증을 이미지(PNG/JPG)로 저장해 다시 업로드해 주세요.',
        422
      );
    }
    return { kind, text, texts: [text] };
  }

  try {
    const texts = await runExclusive(() => ocrImage(buf));
    return { kind, text: texts[0] ?? '', texts };
  } catch (err: any) {
    if (err instanceof LicenseError) throw err;
    throw new LicenseError(`이미지 인식 중 오류가 발생했습니다: ${err?.message || err}`, 500);
  }
}
