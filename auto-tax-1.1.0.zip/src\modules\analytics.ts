import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { loadConfig } from '../config';

/**
 * 사용 집계 이벤트를 중계 서버(Cloudflare Worker)로 보낸다. 중계 서버가 GA4 secret 으로 GA4 에 전달한다.
 * 프로그램에는 GA4 secret 이 없다. 보내는 값: 설치마다 만든 무작위 ID, 앱 버전, 이벤트 이름.
 * 발전소·사업자·메일·인증서 정보는 보내지 않는다. 전송 실패는 무시한다.
 * 임시 설정 파일(configPath)을 쓰는 테스트 실행이나 AUTOTAX_NO_ANALYTICS=1 이면 보내지 않는다.
 * 중계 서버 코드는 worker/analytics-worker.js 에 있다.
 */

export const ANALYTICS_ENDPOINT = 'https://auto-tax-analytics.keeie.workers.dev/collect';
const SEND_TIMEOUT_MS = 5000;
const ID_FILE_NAME = 'telemetry-id.json';

export interface AnalyticsPaths {
  configPath?: string;
  outputDir?: string;
}

function readAppVersion(): string {
  try {
    const pkg = JSON.parse(fs.readFileSync(path.resolve(__dirname, '..', '..', 'package.json'), 'utf-8'));
    return typeof pkg.version === 'string' ? pkg.version : 'unknown';
  } catch {
    return 'unknown';
  }
}

/** 설치마다 한 번 만든 무작위 ID 를 data/telemetry-id.json 에 저장해 재사용한다. 저장에 실패하면 이번 실행 동안만 쓴다. */
function getClientId(outputDir: string): string {
  const file = path.resolve(outputDir, ID_FILE_NAME);
  try {
    const saved = JSON.parse(fs.readFileSync(file, 'utf-8'));
    if (typeof saved.clientId === 'string' && saved.clientId) return saved.clientId;
  } catch {
    // 파일이 없거나 깨졌으면 새로 만든다
  }
  const clientId = crypto.randomUUID();
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify({ clientId }, null, 2), 'utf-8');
  } catch {
    // 저장하지 못하면 이번 실행 동안만 사용한다
  }
  return clientId;
}

/** 이벤트 하나를 중계 서버로 보낸다. 실패해도 예외를 던지지 않는다. */
export async function sendAnalyticsEvent(name: string, paths: AnalyticsPaths = {}): Promise<void> {
  try {
    if (process.env.AUTOTAX_NO_ANALYTICS === '1' || paths.configPath) return;
    const outputDir = paths.outputDir ?? loadConfig().options.outputDir;
    const body = JSON.stringify({
      client_id: getClientId(outputDir),
      name,
      app_version: readAppVersion(),
    });
    await fetch(ANALYTICS_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body,
      signal: AbortSignal.timeout(SEND_TIMEOUT_MS),
    });
  } catch {
    // 집계 실패는 프로그램 동작에 영향을 주지 않는다
  }
}
