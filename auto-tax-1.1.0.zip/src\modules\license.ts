import crypto from 'crypto';
import fs from 'fs';
import os from 'os';
import path from 'path';

// 활성화 코드/라이선스 파일 처리.
// - 코드 = base64url(페이로드 JSON) + "." + base64url(Ed25519 서명). 검증은 앱에 든 공개 키로 오프라인에서 한다.
// - 서명 개인 키는 개발자 PC에만 있다(프로젝트 밖). `npm run license:keygen` 으로 한 번 만든다.
// - 라이선스 파일(secrets/license.json)에는 코드와 같은 형식의 서명된 내용을 저장한다.

export const LICENSE_PUBLIC_KEY_PEM = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAnE59dA36HJKltLKLTGOhbRkRkAdqx85nIzQMGwA578o=
-----END PUBLIC KEY-----
`;

export const LICENSE_PRIVATE_KEY_PATH =
  process.env.AUTOTAX_LICENSE_KEY || path.join(os.homedir(), '.autotax-license', 'license-private.pem');

export const LICENSE_FILE_PATH = path.resolve(process.cwd(), 'secrets', 'license.json');

const KST_OFFSET = '+09:00';

export interface LicensePayload {
  v: 1;
  licenseId: string;
  issuedAt: string; // ISO
  expiresAt: string; // ISO, 만료일 23:59:59 (KST)
  maxPlants?: number; // 등록 가능한 발전소 수(없으면 제한 없음: 예전 코드)
}

export interface LicenseStatus {
  active: boolean;
  expiresAt?: string;
  maxPlants?: number | null; // active 일 때만 의미. null 이면 제한 없음
  reason?: string;
}

/** 체험판 또는 만료된 라이선스일 때 등록할 수 있는 발전소 수 */
export const TRIAL_PLANT_LIMIT = 3;
export const MAX_PLANTS_LIMIT = 999;
/** 활성화 코드를 만들 때 입력할 수 있는 최소 발전소 수 */
export const MIN_PLANTS_FOR_CODE = 3;

function b64url(buf: Buffer): string {
  return buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function fromB64url(s: string): Buffer {
  const pad = s.length % 4 === 0 ? '' : '='.repeat(4 - (s.length % 4));
  return Buffer.from(s.replace(/-/g, '+').replace(/_/g, '/') + pad, 'base64');
}

/** 'YYYY-MM-DD' → 그날 23:59:59 (KST) ISO 문자열 */
export function endOfDayKst(date: string): string {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error('만료일 형식이 올바르지 않습니다.');
  const iso = `${date}T23:59:59${KST_OFFSET}`;
  if (Number.isNaN(Date.parse(iso))) throw new Error('만료일이 올바르지 않습니다.');
  return iso;
}

/** 개발자 PC에서만 호출. 개인 키가 없으면 실패한다. */
export function createActivationCode(expiresDate: string, maxPlants?: number): { code: string; payload: LicensePayload } {
  if (!fs.existsSync(LICENSE_PRIVATE_KEY_PATH)) {
    throw new Error('라이선스 서명 키가 없습니다. 개발자 PC에서만 코드를 만들 수 있습니다.');
  }
  const privateKey = crypto.createPrivateKey(fs.readFileSync(LICENSE_PRIVATE_KEY_PATH, 'utf-8'));
  const payload: LicensePayload = {
    v: 1,
    licenseId: crypto.randomBytes(8).toString('hex'),
    issuedAt: new Date().toISOString(),
    expiresAt: endOfDayKst(expiresDate),
  };
  if (maxPlants !== undefined) {
    if (!Number.isInteger(maxPlants) || maxPlants < MIN_PLANTS_FOR_CODE || maxPlants > MAX_PLANTS_LIMIT) {
      throw new Error(`발전소 수는 ${MIN_PLANTS_FOR_CODE}~${MAX_PLANTS_LIMIT}개 사이로 입력해 주세요.`);
    }
    payload.maxPlants = maxPlants;
  }
  const body = b64url(Buffer.from(JSON.stringify(payload), 'utf-8'));
  const signature = b64url(crypto.sign(null, Buffer.from(body, 'utf-8'), privateKey));
  return { code: `${body}.${signature}`, payload };
}

/** 코드의 서명을 공개 키로 확인하고 페이로드를 돌려준다. 실패하면 예외. */
export function parseActivationCode(rawCode: string): LicensePayload {
  const code = rawCode.trim();
  const dot = code.indexOf('.');
  if (dot <= 0 || dot === code.length - 1) throw new Error('활성화 코드 형식이 올바르지 않습니다.');
  const body = code.slice(0, dot);
  const signature = fromB64url(code.slice(dot + 1));
  const publicKey = crypto.createPublicKey(LICENSE_PUBLIC_KEY_PEM);
  if (!crypto.verify(null, Buffer.from(body, 'utf-8'), publicKey, signature)) {
    throw new Error('유효하지 않은 활성화 코드입니다.');
  }
  let payload: LicensePayload;
  try {
    payload = JSON.parse(fromB64url(body).toString('utf-8'));
  } catch {
    throw new Error('활성화 코드 내용을 읽을 수 없습니다.');
  }
  if (payload.v !== 1 || !payload.expiresAt || Number.isNaN(Date.parse(payload.expiresAt))) {
    throw new Error('활성화 코드 내용이 올바르지 않습니다.');
  }
  if (payload.maxPlants !== undefined && !isValidMaxPlants(payload.maxPlants)) {
    throw new Error('활성화 코드 내용이 올바르지 않습니다.');
  }
  return payload;
}

/** 라이선스 파일을 읽어 서명이 맞으면 페이로드를 돌려준다. 없거나 깨졌으면 null. */
export function readLicenseFile(): LicensePayload | null {
  try {
    const raw = JSON.parse(fs.readFileSync(LICENSE_FILE_PATH, 'utf-8')) as { code?: string };
    if (!raw.code) return null;
    return parseActivationCode(raw.code);
  } catch {
    return null;
  }
}

export function getLicenseStatus(now: Date = new Date()): LicenseStatus {
  const payload = readLicenseFile();
  if (!payload) return { active: false, reason: '활성화되지 않았습니다.' };
  if (Date.parse(payload.expiresAt) < now.getTime()) {
    return { active: false, expiresAt: payload.expiresAt, reason: '라이선스 기간이 만료되었습니다.' };
  }
  return { active: true, expiresAt: payload.expiresAt, maxPlants: payload.maxPlants ?? null };
}

function isValidMaxPlants(n: unknown): n is number {
  return typeof n === 'number' && Number.isInteger(n) && n >= 1 && n <= MAX_PLANTS_LIMIT;
}

/**
 * 활성화 코드를 검증하고 라이선스 파일에 저장한다.
 * 이미 저장된 파일이 있으면 만료일이 더 늦은 쪽을 남긴다(같으면 기존 파일 유지).
 */
export function activateLicense(rawCode: string, now: Date = new Date()): { saved: boolean; status: LicenseStatus; message: string } {
  const incoming = parseActivationCode(rawCode);
  if (Date.parse(incoming.expiresAt) < now.getTime()) {
    throw new Error('이미 만료된 활성화 코드입니다.');
  }

  const existing = readLicenseFile();
  if (existing && Date.parse(existing.expiresAt) >= Date.parse(incoming.expiresAt)) {
    return {
      saved: false,
      status: getLicenseStatus(now),
      message: `기존 라이선스(만료 ${existing.expiresAt})가 더 길어서 그대로 유지합니다.`,
    };
  }

  fs.mkdirSync(path.dirname(LICENSE_FILE_PATH), { recursive: true });
  const tmp = `${LICENSE_FILE_PATH}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify({ code: rawCode.trim(), savedAt: now.toISOString() }, null, 2), 'utf-8');
  fs.renameSync(tmp, LICENSE_FILE_PATH);
  return { saved: true, status: getLicenseStatus(now), message: '라이선스가 활성화되었습니다.' };
}
