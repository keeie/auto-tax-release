import { Page } from 'playwright';

export interface LoginOptions {
  id: string;
  password: string;
  timeoutMs?: number;
}

/** session: 저장된 로그인 상태가 살아 있어 비밀번호를 입력하지 않음 / password: ID·비밀번호로 새로 로그인 */
export type NaverLoginResult = 'session' | 'password';

const NID_HOST = /^https?:\/\/nid\.naver\.com\//;
// 새 기기 로그인 뒤 "자주 사용하는 기기로 등록" 화면의 등록 버튼(등록안함: #new.dontsave).
const DEVICE_SAVE = '#new\\.save, a:text-is("등록"), button:text-is("등록")';

/**
 * 이 창(저장된 쿠키)으로 이미 로그인되어 있는지 확인한다. 비밀번호를 쓰지 않는다.
 * 로그인되어 있지 않으면 메일 주소가 nid.naver.com 로그인 화면으로 넘어간다.
 */
export async function hasNaverSession(page: Page): Promise<boolean> {
  await page.goto('https://mail.naver.com/', { waitUntil: 'domcontentloaded' });
  const redirected = await page
    .waitForURL((u) => NID_HOST.test(u.href), { timeout: 5000 })
    .then(() => true, () => false);
  return !redirected && /^https?:\/\/mail\.naver\.com\//.test(page.url());
}

export async function loginNaver(page: Page, options: LoginOptions): Promise<NaverLoginResult> {
  const { id, password, timeoutMs = 60000 } = options;

  // 지난 수집 때 저장한 로그인 상태가 살아 있으면 다시 로그인하지 않는다(새 기기 알림 메일이 오지 않음).
  if (await hasNaverSession(page).catch(() => false)) {
    console.log('[Auth] 저장된 로그인 상태로 접속했습니다. (비밀번호 입력 없음)');
    return 'session';
  }

  if (!id || !password || id === 'YOUR_NAVER_ID' || password === 'YOUR_NAVER_PASSWORD') {
    throw new Error(
      '[Auth] 네이버 ID와 비밀번호가 없습니다. 발전소 관리에서 메일 정보를 입력해 주세요.'
    );
  }

  console.log('[Auth] 1. www.naver.com 접속 중...');
  await page.goto('https://www.naver.com', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(1000);

  console.log('[Auth] 2. NAVER 로그인 버튼 찾는 중...');
  // Find NAVER login button on the main page
  const loginButtonSelectors = [
    'a.link_login',
    'a[href*="nidlogin.login"]',
    'a:has-text("NAVER 로그인")',
    'a:has-text("로그인")',
    '.MyView-module__link_login___HpHMW',
  ];

  let clicked = false;
  for (const selector of loginButtonSelectors) {
    const el = page.locator(selector).first();
    if (await el.isVisible({ timeout: 1500 }).catch(() => false)) {
      console.log(`[Auth] 로그인 버튼 클릭: ${selector}`);
      await el.click();
      clicked = true;
      break;
    }
  }

  if (!clicked) {
    console.log('[Auth] 메인화면 로그인 버튼을 직접 찾지 못해 로그인 페이지로 직접 이동합니다.');
    await page.goto('https://nid.naver.com/nidlogin.login', { waitUntil: 'domcontentloaded' });
  }

  // Wait for login form to load
  await page.waitForSelector('#id', { timeout: 10000 });
  await page.waitForTimeout(500);

  console.log('[Auth] 3. 계정 정보 입력 중 (자동입력 방지 우회 처리)...');

  // Inject ID and PW via DOM evaluation to avoid Naver's automated bot detection captcha
  await page.evaluate(
    ({ uid, upw }) => {
      const idInput = document.querySelector('#id') as HTMLInputElement;
      const pwInput = document.querySelector('#pw') as HTMLInputElement;

      if (idInput) {
        idInput.focus();
        idInput.value = uid;
        idInput.dispatchEvent(new Event('input', { bubbles: true }));
        idInput.dispatchEvent(new Event('change', { bubbles: true }));
      }

      if (pwInput) {
        pwInput.focus();
        pwInput.value = upw;
        pwInput.dispatchEvent(new Event('input', { bubbles: true }));
        pwInput.dispatchEvent(new Event('change', { bubbles: true }));
      }

      // "로그인 상태 유지": 저장해 둔 쿠키로 다음 수집 때도 로그인된 상태를 이어 쓰기 위해 켠다.
      const keep = document.querySelector('#keep') as HTMLInputElement | null;
      if (keep && !keep.checked) keep.click();
    },
    { uid: id, upw: password }
  );

  await page.waitForTimeout(500);

  // Click submit login button
  console.log('[Auth] 로그인 제출 버튼 클릭...');
  const submitSelectors = [
    'button.btn_login[type="submit"]',
    '#log\\.login',
    'button.btn_login',
    'button[type="submit"]',
    '.btn_login_wrap button',
    'button:has-text("로그인")',
    'input[type="submit"]',
  ];

  let submitted = false;
  for (const selector of submitSelectors) {
    try {
      const btn = page.locator(selector).first();
      if (await btn.isVisible({ timeout: 1000 }).catch(() => false)) {
        console.log(`[Auth] 로그인 제출 버튼 클릭: ${selector}`);
        await btn.click({ timeout: 3000 });
        submitted = true;
        break;
      }
    } catch {
      // 다음 셀렉터 시도
    }
  }

  if (!submitted) {
    console.log('[Auth] 버튼 클릭 실패 -> 엔터키 입력 및 직접 폼 제출 시도...');
    try {
      await page.locator('#pw').focus();
      await page.keyboard.press('Enter');
      submitted = true;
    } catch {
      await page.evaluate(() => {
        const submitBtn = document.querySelector('button[type="submit"], .btn_login, #log\\.login') as HTMLElement;
        if (submitBtn) {
          submitBtn.click();
        } else {
          const form = document.querySelector('form') as HTMLFormElement;
          if (form) form.submit();
        }
      });
    }
  }

  console.log('[Auth] 로그인 완료 대기 중...');

  // Handle post-login conditions: device registration or 2FA or successful navigation
  const startTime = Date.now();
  let leftLoginFormAt = 0;
  while (Date.now() - startTime < timeoutMs) {
    const currentUrl = page.url();

    // 새 기기 등록 화면("자주 사용하는 기기로 등록"): 등록해 두면 다음부터 같은 기기로 인식되어 알림 메일이 오지 않는다.
    const saveDeviceBtn = page.locator(DEVICE_SAVE).first();
    if (await saveDeviceBtn.isVisible({ timeout: 500 }).catch(() => false)) {
      console.log('[Auth] 새 기기 등록 화면 감지 -> "등록" 클릭');
      await saveDeviceBtn.click();
      await page.waitForTimeout(1500);
      continue;
    }

    // 로그인 화면을 벗어났으면 성공. 단, 기기 등록 화면은 nid.naver.com 에서 조금 늦게 뜰 수 있어 몇 초 더 지켜본다.
    if (!currentUrl.includes('nidlogin.login')) {
      if (!leftLoginFormAt) leftLoginFormAt = Date.now();
      if (!NID_HOST.test(currentUrl) || Date.now() - leftLoginFormAt > 5000) {
        console.log('[Auth] 네이버 로그인 성공!');
        await page.waitForTimeout(1000);
        return 'password';
      }
      await page.waitForTimeout(500);
      continue;
    }

    // Check if captcha / 2FA is presented to the user
    const captchaImg = page.locator('#chptcha, #captcha, .captcha_wrap').first();
    const isCaptcha = await captchaImg.isVisible({ timeout: 200 }).catch(() => false);
    if (isCaptcha) {
      console.log('[Auth] 자동입력 방지 문자(캡차) 또는 2단계 인증이 표시되었습니다. 브라우저 창에서 직접 인증을 완료해주세요...');
    }

    await page.waitForTimeout(1000);
  }

  throw new Error(`[Auth] ${timeoutMs / 1000}초 내에 로그인이 완료되지 않았습니다.`);
}
