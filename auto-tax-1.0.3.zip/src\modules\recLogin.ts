import fs from 'fs';
import path from 'path';
import { Locator, Page } from 'playwright';
import type { CertificateMaterial } from './certStore';
import {
  describeCertificate,
  ExpectedCert,
  HometaxError,
  HometaxSession,
  LogFn,
  selectMatchingCertificate,
  submitCertificatePassword,
  waitForCertList,
} from './hometax';

/**
 * REC 발행(재생에너지 공급인증서) 사이트 공동인증서 로그인 자동화.
 *
 * 순서: REC 로그인 페이지 접속 → 팝업(창·레이어) 모두 닫기 → 발전사업자 "공동인증서로그인" → 사업자번호 입력 후 다시 "공동인증서로그인" →
 *       인증서 로그인 페이지(kcert) 이동 → "공동인증서 로그인" → 인증서 선택창 대기 → 사업자에 등록된 인증서와 같은 인증서 선택 → 비밀번호 입력 후 확인
 *
 * 현재 구현 범위: 로그인까지. 로그인 이후 REC 발급 화면은 아직 자동화하지 않는다.
 *
 * 주의
 * - 홈택스와 같은 인증서 선택창 처리(hometax.ts)를 쓴다. 비밀번호는 입력에만 쓰고 로그에 남기지 않는다.
 * - 비밀번호가 틀리면 절대 재시도하지 않는다(인증서 잠김 방지).
 * - 사이트 화면은 2026-11 기준 직접 확인한 구조다. 실제 로그인으로는 아직 끝까지 검증하지 못했다.
 */

export const REC_LOGIN_URL = 'https://rps.energy.or.kr/login2.do';
export const REC_ORIGIN = 'https://rps.energy.or.kr';
export const KCERT_ORIGIN = 'https://kcert.energy.or.kr';

const WRONG_PASSWORD_RE =/(비밀번호|암호).*(틀|올바르|오류|일치|잘못)|(틀|올바르|오류|일치|잘못).*(비밀번호|암호)/;
const LOCKED_RE = /(횟수|잠금|잠겼|폐기)/;

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/**
 * 페이지 안 스크립트를 실행한다. 페이지가 이동(새로고침)하는 중이면 "Execution context was destroyed"가 나므로,
 * 이동이 끝날 때까지 기다린 뒤 다시 실행한다.
 */
async function evalStable(page: Page, script: string): Promise<any> {
  for (let attempt = 0; ; attempt++) {
    try {
      return await page.evaluate(script);
    } catch (err: any) {
      const navigating = /Execution context was destroyed|navigation/i.test(String(err?.message));
      if (!navigating || attempt >= 3) throw err;
      await page.waitForLoadState('domcontentloaded', { timeout: 15_000 }).catch(() => {});
      await sleep(500);
    }
  }
}

/**
 * 화면의 팝업(모달 레이어)을 찾거나 닫는 스크립트. clickIt 이 true 면 닫기 버튼을 누르고, false 면 찾기만 한다.
 * 찾은 팝업의 안내 문구(앞부분)를 돌려주고, 없으면 null. 화면 전체를 덮는 레이어는 제외한다.
 */
const popupScript = (clickIt: boolean) => `(() => {
  var CLICK = ${clickIt};
  var CLOSE_TEXT = /^(확인|닫기|close)$/i;
  var vw = window.innerWidth, vh = window.innerHeight;
  var visible = function (el) {
    var r = el.getBoundingClientRect();
    var cs = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none';
  };
  var isModal = function (el) {
    var r = el.getBoundingClientRect();
    var pos = getComputedStyle(el).position;
    var coversPage = r.width >= vw * 0.8 && r.height >= vh * 0.8;
    return (pos === 'fixed' || pos === 'absolute') && !coversPage;
  };
  var candidates = Array.prototype.filter.call(
    document.querySelectorAll('[role="dialog"], [role="alertdialog"], [class*="dialog"], [id*="dialog"], [class*="popup"], [class*="layer"], [id*="popup"], [id*="layer"]'),
    function (el) { return visible(el) && isModal(el) && (el.innerText || '').trim().length > 0; }
  );
  for (var i = 0; i < candidates.length; i++) {
    var summary = (candidates[i].innerText || '').replace(/\\s+/g, ' ').trim().slice(0, 80);
    var buttons = Array.prototype.filter.call(
      candidates[i].querySelectorAll('button, a, input[type="button"], input[type="submit"]'),
      visible
    );
    for (var j = 0; j < buttons.length; j++) {
      var label = ((buttons[j].innerText || buttons[j].value || '') + '').replace(/\\s+/g, '').trim();
      if (CLOSE_TEXT.test(label) || /close/i.test(buttons[j].className || '')) {
        if (CLICK) buttons[j].click();
        return summary || label;
      }
    }
  }
  return null;
})()`;

/** 팝업 창(새 창)과 화면 레이어 팝업을 모두 닫고, 남은 것이 없을 때까지 확인한다. */
async function closeRecPopups(session: HometaxSession, log: LogFn): Promise<void> {
  const { page, context } = session;
  const extraWindows = () => context.pages().filter((p) => p !== page && !p.isClosed());
  await page.waitForLoadState('load', { timeout: 15_000 }).catch(() => {});

  // 팝업이 늦게 뜰 수 있으므로 연속 3번(약 1.5초) 아무것도 없을 때까지 반복한다.
  let quietRounds = 0;
  for (let round = 0; round < 30 && quietRounds < 3; round++) {
    let closed = 0;
    for (const w of extraWindows()) {
      log('팝업 창을 닫습니다.');
      await w.close().catch(() => {});
      closed++;
    }
    const closedDom = await evalStable(page, popupScript(true)).catch(() => null);
    if (typeof closedDom === 'string') {
      log(`팝업을 닫았습니다: ${closedDom}`);
      closed++;
    }
    quietRounds = closed ? 0 : quietRounds + 1;
    await sleep(500);
  }

  const leftDom = await evalStable(page, popupScript(false)).catch(() => null);
  const left = extraWindows().length + (typeof leftDom === 'string' ? 1 : 0);
  if (left > 0) {
    throw new HometaxError(
      'page-error',
      `팝업이 ${left}개 남아 있어 로그인을 진행하지 않았습니다. 열려 있는 팝업을 직접 닫은 뒤 다시 시도해 주세요.`,
      true
    );
  }
  log('팝업이 모두 닫혔는지 확인했습니다.', 'success');
}

/**
 * 로그인 관련 요소의 위치·클래스·가려짐 여부를 .debug/ 에 저장한다(입력값과 인증서 정보는 넣지 않는다).
 * 화면 구조를 보고 선택자를 고치기 위한 용도다.
 */
async function saveDebugSnapshot(page: Page, label: string): Promise<string | null> {
  const DUMP_SCRIPT = `(() => {
    var out = [];
    var els = document.querySelectorAll('a, button, input, div, span, img, iframe');
    for (var i = 0; i < els.length && out.length < 300; i++) {
      var el = els[i];
      var r = el.getBoundingClientRect();
      if (r.width <= 0 || r.height <= 0) continue;
      var text = (el.tagName === 'INPUT' ? '' : (el.innerText || '')).replace(/\\s+/g, ' ').trim();
      var attrs = String(el.className || '') + ' ' + (el.id || '');
      if (!/로그인|인증|load|spin/i.test(text + ' ' + attrs)) continue;
      var top = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
      out.push({
        tag: el.tagName,
        id: el.id,
        cls: String(el.className || '').slice(0, 120),
        text: text.slice(0, 60),
        type: el.getAttribute('type'),
        href: (el.getAttribute('href') || '').slice(0, 80),
        rect: [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)],
        coveredBy: top ? { tag: top.tagName, id: top.id, cls: String(top.className || '').slice(0, 120) } : null,
      });
    }
    return {
      elements: out,
      certRows:Array.prototype.slice.call(document.querySelectorAll('#nx-cert-select tr'), 0, 12).map(function (tr) {
        return { cls: String(tr.className || ''), aria: tr.getAttribute('aria-selected'), html: tr.outerHTML.replace(/\\s+/g, ' ').slice(0, 500) };
      }),
      frames: Array.prototype.map.call(document.querySelectorAll('iframe'), function (f) { return { name: f.name, id: f.id }; }),
      bodyHead: ((document.body && document.body.innerText) || '').replace(/\\s+/g, ' ').slice(0, 300),
    };
  })()`;
  const snapshot = await evalStable(page, DUMP_SCRIPT).catch(() => null);
  if (!snapshot) return null;
  const dir = path.join(process.cwd(), '.debug');
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `rec-${label}-${Date.now()}.json`);
  fs.writeFileSync(file, JSON.stringify({ url: page.url(), snapshot }, null, 2), 'utf8');
  return file;
}

/** 로그인 후 화면의 메뉴·링크·표 칸 글자를 .debug/ 에 저장한다(화면 구조 확인용). */
async function saveMenuSnapshot(page: Page, label: string): Promise<string | null> {
  const MENU_SCRIPT = `(() => {
    var items = [];
    var els = document.querySelectorAll('a, button, li, span, td, th, img, input');
    for (var i = 0; i < els.length && items.length < 400; i++) {
      var el = els[i];
      var r = el.getBoundingClientRect();
      if (r.width <= 0 || r.height <= 0) continue;
      var t = (el.tagName === 'IMG' ? (el.alt || '') : el.tagName === 'INPUT' ? (el.value || el.type || '') : (el.innerText || '')).replace(/\\s+/g, ' ').trim();
      if (!t || t.length > 40) continue;
      items.push({
        tag: el.tagName,
        text: t,
        id: el.id,
        cls: String(el.className || '').slice(0, 80),
        href: (el.getAttribute('href') || '').slice(0, 80),
        onclick: (el.getAttribute('onclick') || '').slice(0, 80),
      });
    }
    var rows = Array.prototype.filter.call(document.querySelectorAll('tr'), function (tr) {
      var r = tr.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    }).slice(0, 200).map(function (tr) {
      return (tr.innerText || '').replace(/\\s+/g, ' ').trim().slice(0, 200);
    });
    return { url: location.href, items: items, rows: rows };
  })()`;
  const snapshot = await evalStable(page, MENU_SCRIPT).catch(() => null);
  if (!snapshot) return null;
  const dir = path.join(process.cwd(), '.debug');
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `rec-menu-${label}-${Date.now()}.json`);
  fs.writeFileSync(file, JSON.stringify(snapshot, null, 2), 'utf8');
  return file;
}

/** 글자가 같은 보이는 요소(링크, 버튼, 칸 등)를 찾아 클릭을 예약한다. 찾으면 true. 클릭은 페이지 안에서 예약만 한다. */
async function clickByText(page: Page, text: string): Promise<boolean> {
  const found = await evalStable(page, `(() => {
    var want = ${JSON.stringify(text)};
    var els = document.querySelectorAll('a, button, input, span, li, td');
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      var r = el.getBoundingClientRect();
      var t = (el.tagName === 'INPUT' ? (el.value || '') : (el.innerText || '')).replace(/\\s+/g, ' ').trim();
      if (r.width > 0 && r.height > 0 && t === want) {
        (function (target) { setTimeout(function () { target.click(); }, 0); })(el);
        return true;
      }
    }
    return false;
  })()`);
  return found === true;
}

const TABLE_ROWS_SCRIPT = `(() => {
  var out = [];
  var trs = document.querySelectorAll('tr');
  for (var i = 0; i < trs.length; i++) {
    var r = trs[i].getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) continue;
    out.push(Array.prototype.map.call(trs[i].querySelectorAll('th, td'), function (c) {
      return (c.innerText || '').replace(/\\s+/g, ' ').trim();
    }));
  }
  return out;
})()`;

/**
 * 발급신청 목록에서 대상 발전월 행을 찾고, 진행상태가 "게시"면 그 행의 "신청" 버튼을 표시한다.
 * 목록 표는 열 수가 헤더와 다를 수 있어 헤더 위치가 아니라 셀 글자로 찾는다.
 */
const MARK_APPLY_SCRIPT = (period: string) => `(() => {
  var want = ${JSON.stringify(period)};
  var trs = document.querySelectorAll('tr');
  for (var i = 0; i < trs.length; i++) {
    var r = trs[i].getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) continue;
    var cells = Array.prototype.map.call(trs[i].querySelectorAll('th, td'), function (c) {
      return (c.innerText || '').replace(/\\s+/g, ' ').trim();
    });
    if (cells.indexOf(want) < 0) continue;
    // 링크·버튼을 먼저 찾고, 없을 때만 칸(td 등)을 쓴다. 칸의 가운데는 링크를 빗나갈 수 있다.
    var pick = function (selector) {
      return Array.prototype.find.call(trs[i].querySelectorAll(selector), function (b) {
        var t = (b.tagName === 'INPUT' ? (b.value || '') : (b.innerText || '')).replace(/\\s+/g, '').trim();
        var rb = b.getBoundingClientRect();
        return t === '신청' && rb.width > 0 && rb.height > 0;
      });
    };
    var btn = pick('a, button, input') || pick('span, td, div');
    if (btn) btn.setAttribute('data-autotax-target', 'rec-apply');
    return { found: true, posted: cells.indexOf('게시') >= 0, hasButton: !!btn, completed: cells.indexOf('완료') >= 0 };
  }
  return { found: false, posted: false, hasButton: false, completed: false };
})()`;

async function applyToTargetRow(page: Page, period: string, log: LogFn): Promise<Page> {
  const row = (await evalStable(page, MARK_APPLY_SCRIPT(period))) as {
    found: boolean;
    posted: boolean;
    hasButton: boolean;
    completed: boolean;
  };
  if (!row.found) {
    log(`발급신청 목록에 ${period} 행이 없습니다.`, 'warn');
    throw new HometaxError('no-request', '아직 REC 발급 요청이 없습니다.', true);
  }
  if (row.completed) {
    log(`${period} 행의 발급신청이 "완료" 상태입니다.`, 'success');
    throw new HometaxError('already-completed', '신청 완료된 발전월입니다.', true);
  }
  if (!row.posted) {
    log(`${period} 행의 진행상태가 "게시"가 아닙니다. 신청하지 않습니다.`, 'warn');
    throw new HometaxError('not-posted', `${period} 행의 진행상태가 "게시"가 아니어서 신청하지 않았습니다.`, true);
  }
  if (!row.hasButton) {
    throw new HometaxError('apply-failed', `${period} 행에서 "신청" 버튼을 찾지 못했습니다.`, true);
  }
  // 목록 표(SBGrid)는 마우스 누름·놓기 이벤트로 동작해서 script 의 click() 으로는 반응하지 않았다. 실제 마우스 클릭을 쓴다.
  // 신청은 새 창(팝업)으로 열린다. 클릭 전에 새 창 이벤트를 걸어 둔다.
  log(`${period} 행의 "신청" 버튼을 누릅니다.`);
  const popupPromise = page.context().waitForEvent('page', { timeout: 15_000 }).catch(() => null);
  await page.locator('[data-autotax-target="rec-apply"]').click({ timeout: 10_000 });
  const popup = await popupPromise;
  if (!popup) {
    throw new HometaxError('apply-failed', '"신청" 버튼을 눌렀지만 신청 창이 열리지 않았습니다.', true);
  }
  await popup.waitForLoadState('load', { timeout: 30_000 }).catch(() => {});
  await sleep(2_000);
  log(`신청 창이 열렸습니다. (${popup.url()})`);
  const file = await saveMenuSnapshot(popup, 'apply-popup');
  log(`신청 창 화면 구조를 저장했습니다.${file ? ` ${file}` : ''}`, 'warn');
  return popup;
}

/**
 * 1단계(담당자 연락처 확인): "상기 내용을 모두 확인하였습니다." 옆 체크박스를 체크하고 "저장"을 누른다.
 */
async function completeStepOne(popup: Page, log: LogFn): Promise<void> {
  const CHECK_SCRIPT = `(() => {
    var text = '상기 내용을 모두 확인하였습니다.';
    var lis = document.querySelectorAll('li, span, label, td, div');
    for (var i = 0; i < lis.length; i++) {
      var t = (lis[i].innerText || '').replace(/\\s+/g, ' ').trim();
      if (t !== text) continue;
      var node = lis[i];
      for (var depth = 0; depth < 4 && node; depth++, node = node.parentElement) {
        var box = node.querySelector('input[type="checkbox"]');
        if (box) {
          if (box.checked) return 'already';
          box.setAttribute('data-autotax-target', 'rec-check');
          return 'marked';
        }
      }
      return 'not-found';
    }
    return 'not-found';
  })()`;
  const checkState = (await evalStable(popup, CHECK_SCRIPT)) as string;
  if (checkState === 'not-found') {
    const file = await saveMenuSnapshot(popup, 'step1-check-missing');
    throw new HometaxError('apply-failed', `1단계 체크박스를 찾지 못했습니다.${file ? ` 화면 구조 저장: ${file}` : ''}`, true);
  }
  if (checkState === 'marked') {
    await popup.locator('[data-autotax-target="rec-check"]').check({ timeout: 10_000 });
    log('1단계 확인 체크박스를 선택했습니다.');
  } else {
    log('1단계 확인 체크박스는 이미 선택되어 있습니다.');
  }
  await saveCurrentStep(popup, log);
}

/**
 * 현재 단계의 "저장"을 누른다. 저장 확인 창(alert/confirm)은 이 단계의 일부이므로 확인으로 닫고 문구를 로그에 남긴다.
 */
async function saveCurrentStep(popup: Page, log: LogFn): Promise<void> {
  const dialogs: string[] = [];
  const onDialog = (d: import('playwright').Dialog) => {
    dialogs.push(d.message());
    d.accept().catch(() => {});
  };
  popup.on('dialog', onDialog);
  try {
    const SAVE_SCRIPT = `(() => {
      var textOf = function (el) {
        if (el.tagName === 'INPUT') return (el.value || '').replace(/\\s+/g, '').trim();
        if (el.tagName === 'IMG') return (el.alt || '').replace(/\\s+/g, '').trim();
        return (el.innerText || '').replace(/\\s+/g, '').trim();
      };
      var visible = function (el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      var els = Array.prototype.filter.call(document.querySelectorAll('a, button, input, img'), visible);
      var el = els.find(function (e) { return textOf(e) === '저장' || (e.title || '').replace(/\\s+/g, '') === '저장'; });
      if (!el) {
        var more = Array.prototype.filter.call(document.querySelectorAll('span, td, div'), visible);
        el = more.find(function (e) { return textOf(e) === '저장'; });
      }
      if (!el) return false;
      el.setAttribute('data-autotax-target', 'rec-save');
      return true;
    })()`;
    if ((await evalStable(popup, SAVE_SCRIPT)) !== true) {
      const file = await saveMenuSnapshot(popup, 'save-missing');
      throw new HometaxError('apply-failed', `"저장" 버튼을 찾지 못했습니다.${file ? ` 화면 구조 저장: ${file}` : ''}`, true);
    }
    log('"저장" 버튼을 누릅니다.');
    await popup.locator('[data-autotax-target="rec-save"]').click({ timeout: 10_000 });
    // 저장 확인("예") → 완료 알림("확인") 순서로 뜬다. 완료 알림 확인을 누르면 신청 창이 닫히며 절차가 끝난다.
    // 완료 알림이 브라우저 알림(alert)이면 위의 알림 처리에서 이미 확인되어 창이 닫힐 수 있다.
    await clickDialogButton(popup, '예', false, log);
    if (!popup.isClosed()) {
      await clickDialogButton(popup, '확인', true, log).catch((err) => {
        if (!popup.isClosed()) throw err;
      });
    }
    await sleep(2_000);
    if (popup.isClosed()) log('신청 창이 닫혀 신청 절차가 끝났습니다.', 'success');
    if (dialogs.length > 0) log(`저장 확인 창: ${dialogs.join(' | ')}`);
  } finally {
    popup.off('dialog', onDialog);
  }
}

/**
 * 저장 뒤 "저장 하시겠습니까?" 확인 창이 뜨면 "예"를 누른다. 창이 없으면 로그만 남기고 넘어간다.
 * 확인 창은 사이트 화면 안의 레이어라서 "예" 버튼을 찾는다.
 */
async function clickDialogButton(popup: Page, label: '예' | '확인', requireDialog: boolean, log: LogFn): Promise<boolean> {
  const FIND_SCRIPT = `(() => {
    var label = ${JSON.stringify(label)};
    var requireDialog = ${requireDialog};
    var visible = function (el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    var textOf = function (el) { return (el.tagName === 'INPUT' ? (el.value || '') : (el.innerText || '')).replace(/\\s+/g, '').trim(); };
    var buttons = Array.prototype.filter.call(document.querySelectorAll('a, button, input[type="button"], input[type="submit"]'), function (b) {
      return visible(b) && textOf(b) === label;
    });
    if (buttons.length === 0) return false;
    var inDialog = buttons.find(function (b) {
      return !!b.closest('[role="dialog"], [role="alertdialog"], [class*="dialog"], [class*="popup"], [class*="layer"], [class*="alert"], [class*="confirm"]');
    });
    if (!inDialog && requireDialog) return false;
    (inDialog || buttons[0]).setAttribute('data-autotax-target', 'rec-dialog-button');
    return true;
  })()`;
  let found = false;
  for (let i = 0; i < 10 && !found; i++) {
    found = (await evalStable(popup, FIND_SCRIPT)) === true;
    if (!found) await sleep(300);
  }
  if (!found) {
    log(`"${label}" 버튼이 있는 창이 뜨지 않았습니다.`, 'warn');
    return false;
  }
  await popup.locator('[data-autotax-target="rec-dialog-button"]').click({ timeout: 10_000 });
  await evalStable(popup, `document.querySelector('[data-autotax-target="rec-dialog-button"]')?.removeAttribute('data-autotax-target')`);
  log(`"${label}" 버튼을 눌렀습니다.`, 'success');
  return true;
}

/** 2단계(발전량 확인) 화면의 "발전량 (A2)" 값을 kWh 숫자로 읽는다. 없으면 null. */
async function readRecGenerationAmount(popup: Page): Promise<number | null> {
  const text = (await evalStable(popup, `(() => {
    var ths = document.querySelectorAll('th');
    for (var i = 0; i < ths.length; i++) {
      var label = (ths[i].innerText || '').replace(/\\s+/g, ' ').trim();
      if (label !== '발전량 (A2)') continue;
      var next = ths[i].nextElementSibling;
      return next ? (next.innerText || '').replace(/\\s+/g, ' ').trim() : null;
    }
    return null;
  })()`)) as string | null;
  const digits = text?.match(/[\d,]+/)?.[0];
  return digits ? Number(digits.replace(/,/g, '')) : null;
}

/**
 * 2단계(발전량 확인): 화면의 발전량이 발급 대상 발전량과 같을 때만 "저장"을 누른다.
 * 다르면 저장하지 않고 두 값을 알려 주며 멈춘다.
 */
async function completeStepTwo(popup: Page, targetAmount: number, log: LogFn): Promise<void> {
  const shown = await readRecGenerationAmount(popup);
  if (shown === null) {
    const file = await saveMenuSnapshot(popup, 'step2-amount-missing');
    throw new HometaxError('apply-failed', `2단계 발전량을 읽지 못했습니다. 저장하지 않았습니다.${file ? ` 화면 구조 저장: ${file}` : ''}`, true);
  }
  if (shown !== targetAmount) {
    throw new HometaxError(
      'amount-mismatch',
      `2단계 발전량(${shown.toLocaleString()} kWh)이 발급 대상 발전량(${targetAmount.toLocaleString()} kWh)과 달라 저장하지 않았습니다.`,
      true
    );
  }
  log(`2단계 발전량(${shown.toLocaleString()} kWh)이 발급 대상과 같습니다. "저장"을 누릅니다.`, 'success');
  await saveCurrentStep(popup, log);
}

/**
 * 신청 창 상단의 3단계 표시(담당자 연락처 확인 → 발전량 확인 → 발전량 확인완료)를 읽어 현재 단계를 정한다.
 * 도달한 단계에는 "on" 표시가 붙으므로, "on" 이 붙은 마지막 단계를 현재 단계로 본다.
 */
async function readApplyStep(page: Page, log: LogFn): Promise<number> {
  const steps = (await evalStable(page, `(() => {
    var labels = ['담당자 연락처 확인', '발전량 확인', '발전량 확인완료'];
    var out = [];
    var lis = document.querySelectorAll('li');
    for (var i = 0; i < lis.length; i++) {
      var r = lis[i].getBoundingClientRect();
      var t = (lis[i].innerText || '').replace(/\\s+/g, ' ').trim();
      if (r.width <= 0 || r.height <= 0 || labels.indexOf(t) < 0) continue;
      out.push({ label: t, on: /(^| )on( |$)/.test(lis[i].className || '') });
    }
    return out;
  })()`)) as { label: string; on: boolean }[];

  if (steps.length !== 3) {
    log(`신청 단계 표시를 찾지 못했습니다(${steps.length}개).`, 'warn');
    return 0;
  }
  const current = steps.map((s) => s.on).lastIndexOf(true);
  if (current < 0) {
    log('신청 단계가 아직 표시되지 않았습니다.', 'warn');
    return 0;
  }
  log(`현재 신청 단계: ${current + 1}. ${steps[current].label} (${steps.map((s) => (s.on ? 'on' : 'off')).join(', ')})`, 'success');
  return current + 1;
}

/** 로그인이 끝난 뒤의 작업(발급신청 메뉴 → 대상 발전월 행 확인). */
async function afterLogin(page: Page, options: LoginOptions, log: LogFn): Promise<void> {
  const mainFile = await saveMenuSnapshot(page, 'main');
  log(`로그인 후 메뉴 구조를 저장했습니다.${mainFile ? ` ${mainFile}` : ''}`, 'warn');

  if (!(await clickByText(page, 'REC 발급신청'))) {
    log('"REC 발급신청" 메뉴를 찾지 못했습니다.', 'warn');
    return;
  }
  log('"REC 발급신청" 메뉴를 눌렀습니다. 목록을 기다립니다.');
  await page.waitForLoadState('load', { timeout: 30_000 }).catch(() => {});
  await sleep(2_000);
  const listFile = await saveMenuSnapshot(page, 'issue-list');
  log(`발급신청 목록 구조를 저장했습니다.${listFile ? ` ${listFile}` : ''}`, 'warn');

  if (options.targetPeriod) {
    const popup = await applyToTargetRow(page, options.targetPeriod, log);
    if ((await readApplyStep(popup, log)) === 1) {
      await completeStepOne(popup, log);
    }
    if ((await readApplyStep(popup, log)) === 2) {
      if (options.targetAmount === undefined) {
        throw new HometaxError('apply-failed', '발급 대상 발전량을 알 수 없어 2단계를 저장하지 않았습니다.', true);
      }
      await completeStepTwo(popup, options.targetAmount, log);
      if (!popup.isClosed()) await readApplyStep(popup, log);
    }
  }
}

/** 화면에서 "공동인증서로그인"(띄어쓰기 무시) 버튼을 찾아 누른다. 같은 문구가 여러 개면 DOM 순서상 첫 번째 보이는 것을 쓴다. */
async function clickCertLogin(page: Page): Promise<void> {
  // 로딩 중에는 화면 위 로딩 이미지(스피너)가 버튼을 덮을 수 있어, 버튼 가운데가 버튼 자신이 가장 위에 보일 때만 고른다.
  const MARK_SCRIPT = `(() => {
    var els = document.querySelectorAll('a, button, input, div, span');
    for (var i = 0; i < els.length; i++) {
      var r = els[i].getBoundingClientRect();
      var text = els[i].tagName === 'INPUT' ? (els[i].value || '') : (els[i].innerText || '');
      if (r.width > 0 && r.height > 0 && text.replace(/\\s+/g, '') === '공동인증서로그인') {
        els[i].setAttribute('data-autotax-target', 'rec-cert-login');
        return true;
      }
    }
    return false;
  })()`;
  // 버튼이 나타나는 즉시 진행한다(고정 간격으로 확인하지 않는다).
  await page.waitForFunction(MARK_SCRIPT, undefined, { timeout: 15_000, polling: 100 }).catch(async () => {
    const file = await saveDebugSnapshot(page, 'cert-login');
    throw new HometaxError(
      'page-error',
      `화면에서 "공동인증서로그인" 버튼을 찾지 못했습니다. (${page.url()})${file ? `\n화면 구조 저장: ${file}` : ''}`,
      true
    );
  });
  // 마우스 클릭은 버튼 위에 겹친 요소(표 크기 조절 손잡이 등)에 막히므로, 버튼의 click 을 직접 호출한다.
  // 클릭은 페이지 안에서 예약만 하고 바로 돌아온다. 클릭 호출이 페이지 이동이 끝날 때까지 붙잡혀 있으면
  // 그 시간이 다음 대기 시간으로 잘못 잡히기 때문이다.
  await evalStable(page, `(() => {
    var el = document.querySelector('[data-autotax-target="rec-cert-login"]');
    if (!el) return false;
    el.removeAttribute('data-autotax-target');
    setTimeout(function () { el.click(); }, 0);
    return true;
  })()`);
}

/**
 * 발전사업자 로그인 사업자번호 입력칸. 사업자번호는 3-2-5 세 칸(id number1~number3)으로 나뉘어 있다.
 * 세 칸이 보이는 순간 돌려준다(고정 간격으로 확인하지 않는다).
 */
async function waitForBusinessNumberParts(page: Page, timeout: number): Promise<[Locator, Locator, Locator]> {
  const parts = ['number1', 'number2', 'number3'].map((id) => page.locator(`input[id="${id}"]:visible`).first());
  await Promise.all(parts.map((p) => p.waitFor({ state: 'visible', timeout })));
  return [parts[0], parts[1], parts[2]];
}

/**
 * 사업자번호를 넘긴 뒤 열리는 인증서 로그인 페이지(kcert)를 기다린다.
 * 같은 탭에서 이동하거나 새 창으로 열릴 수 있어, 열린 창 중 주소가 kcert 인 가장 마지막 창을 쓴다.
 */
async function waitForKcertPage(session: HometaxSession): Promise<Page> {
  const deadline = Date.now() + 30_000;
  while (Date.now() < deadline) {
    const found = session.context
      .pages()
      .filter((p) => !p.isClosed() && p.url().startsWith(KCERT_ORIGIN))
      .pop();
    if (found) {
      await found.waitForLoadState('domcontentloaded', { timeout: 30_000 }).catch(() => {});
      return found;
    }
    await sleep(300);
  }
  throw new HometaxError('page-error', 'REC 인증서 로그인 페이지(kcert)로 넘어가지 않았습니다.', true);
}

// ---------- 인증서 로그인 페이지(kcert)의 화면 안 인증서 목록 ----------
// 홈택스와 달리 목록이 iframe 이 아니라 페이지 안(#nx-cert-select)에 있고, 로그인은 목록에서 고른 뒤 누른다.

type CertRowInfo = { index: number; id: string; text: string; selected: boolean };

/** 사이트 내부에서 "확인" 버튼이 쓰는 인증서 번호와 선택 번호를 읽는다(화면 표시가 아니라 실제 값). */
const INTERNAL_INDEX_SCRIPT = `(() => ({
  certIndex: (window.certListInfo && certListInfo.getCertListIndex) ? String(certListInfo.getCertListIndex()) : null,
  selectedRow: (typeof window.NX_SELECTED_ROW !== 'undefined') ? String(NX_SELECTED_ROW) : null
}))()`;

const CERT_ROWS_SCRIPT = `(() => {
  var trs = document.querySelectorAll('#nx-cert-select tr');
  var out = [];
  for (var i = 0; i < trs.length; i++) {
    var text = (trs[i].innerText || '').replace(/\\s+/g, ' ').trim();
    if (!/\\d{4}-\\d{2}-\\d{2}/.test(text)) continue;
    var selected = /select|active|checked/i.test(trs[i].className || '') || (' ' + (trs[i].className || '') + ' ').indexOf(' on ') >= 0 ||
      trs[i].getAttribute('aria-selected') === 'true' ||
      !!trs[i].querySelector('[class*="select"], [class*="active"], [aria-selected="true"], input:checked');
    out.push({ index: i, id: trs[i].id || '', text: text, selected: selected });
  }
  return out;
})()`;

const BODY_TEXT_SCRIPT = `(() => ((document.body && document.body.innerText) || ''))()`;

/** 보이는 비밀번호 칸이 속한 영역에서 "확인" 또는 "로그인" 버튼을 누른다. 누르면 true. */
const CONFIRM_PASSWORD_SCRIPT = `(() => {
  var pw = Array.prototype.find.call(document.querySelectorAll('input[type="password"]'), function (el) {
    var r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  });
  if (!pw) return false;
  var node = pw;
  for (var depth = 0; depth < 8 && node; depth++, node = node.parentElement) {
    var btns = node.querySelectorAll('button, a, input[type="button"], input[type="submit"]');
    for (var i = 0; i < btns.length; i++) {
      var t = ((btns[i].innerText || btns[i].value || '') + '').replace(/\\s+/g, '');
      var r = btns[i].getBoundingClientRect();
      if (r.width > 0 && r.height > 0 && (t === '확인' || t === '로그인')) {
        btns[i].click();
        return true;
      }
    }
  }
  return false;
})()`;

/** 목록에서 등록된 인증서(소유자명 + 만료일)와 같은 행을 고르고, 선택이 실제로 바뀌었는지 확인한다. */
async function selectCertificateInPage(page: Page, expected: ExpectedCert, log: LogFn): Promise<number> {
  // 목록이 새로 열리는 동안 기다린다(행이 보일 때까지).
  let rows: CertRowInfo[] = [];
  for (let i = 0; i < 50 && rows.length === 0; i++) {
    rows = (await evalStable(page, CERT_ROWS_SCRIPT)) as CertRowInfo[];
    if (rows.length === 0) await sleep(300);
  }
  const squeeze = (s: string) => s.replace(/\s+/g, '');
  const name = squeeze(expected.commonName);
  log(`인증서 목록에서 ${rows.length}개를 확인했습니다. 사업자 인증서를 찾습니다.`);

  let picked = rows.find((r) => squeeze(r.text).includes(name) && r.text.includes(expected.expiry));
  if (!picked) {
    // 표기가 조금 다를 때: 소유자명 끝의 고유번호(숫자 12자리 이상)와 만료일이 같은 행
    const tail = name.match(/(\d{12,})$/)?.[1];
    const loose = tail ? rows.filter((r) => squeeze(r.text).includes(tail) && r.text.includes(expected.expiry)) : [];
    if (loose.length > 1) {
      throw new HometaxError('cert-ambiguous', '인증서 목록에서 등록된 인증서와 비슷한 항목이 여러 개라 안전하게 고를 수 없습니다.', true);
    }
    picked = loose[0];
  }
  if (!picked) {
    throw new HometaxError('cert-not-found', `인증서 목록(${rows.length}개)에서 등록된 인증서와 일치하는 항목을 찾지 못했습니다.`, true);
  }

  // 실제 마우스 클릭으로 행을 고른다(사이트의 행 클릭 처리가 그대로 실행되도록 한다).
  await page.locator('#nx-cert-select tr').nth(picked.index).locator('td').first().click({ timeout: 10_000 });
  // 선택된 행이 이 행 하나뿐인지 확인한다. 처음 자동 선택된 인증서로 비밀번호를 넣으면 오류 횟수가 쌓일 수 있다.
  let selectedRows: CertRowInfo[] = [];
  for (let i = 0; i < 10; i++) {
    selectedRows = ((await evalStable(page, CERT_ROWS_SCRIPT)) as CertRowInfo[]).filter((r) => r.selected);
    if (selectedRows.length === 1 && selectedRows[0].index === picked.index) break;
    await sleep(300);
  }
  if (selectedRows.length !== 1 || selectedRows[0].index !== picked.index) {
    const file = await saveDebugSnapshot(page, 'cert-select');
    throw new HometaxError(
      'select-failed',
      `인증서 선택을 확인하지 못했습니다. 비밀번호는 입력하지 않았습니다.${file ? `\n화면 구조 저장: ${file}` : ''}`,
      true
    );
  }
  // 화면 표시만으로는 부족하다. 사이트가 "확인"에 쓰는 내부 번호가 이 행이고, 약 2초 동안 바뀌지 않아야 통과한다.
  // 사이트가 목록을 열고 나서 기본 선택을 다시 넣는 경우가 있어, 어긋나면 이 행을 다시 누른다.
  const want = picked.id;
  let stable = false;
  for (let attempt = 0; attempt < 3 && !stable; attempt++) {
    if (attempt > 0) {
      log('사이트 내부 선택이 바뀌어 같은 인증서를 다시 고릅니다.', 'warn');
      await page.locator(`#nx-cert-select tr[id="${want}"] td`).first().click({ timeout: 10_000 });
    }
    stable = true;
    for (let k = 0; k < 4; k++) {
      await sleep(500);
      const st = (await evalStable(page, INTERNAL_INDEX_SCRIPT)) as { certIndex: string | null; selectedRow: string | null };
      if (st.certIndex !== want || st.selectedRow !== want) {
        stable = false;
        break;
      }
    }
  }
  if (!stable) {
    const file = await saveDebugSnapshot(page, 'cert-select-internal');
    throw new HometaxError(
      'select-failed',
      `사이트 내부 인증서 선택이 한솔 행과 맞지 않아 중단했습니다. 비밀번호는 입력하지 않았습니다.${file ? `\n화면 구조 저장: ${file}` : ''}`,
      true
    );
  }
  log('일치하는 인증서를 선택했습니다(사이트 내부 선택 값 확인).');
  return picked.index;
}


/** 화면에 나타난 비밀번호 칸에 입력하고 확인을 누른다. */
async function enterPasswordInPage(page: Page, password: string, log: LogFn): Promise<void> {
  const pw = page.locator('input[type="password"]:visible').first();
  try {
    await pw.waitFor({ state: 'visible', timeout: 15_000 });
  } catch {
    const file = await saveDebugSnapshot(page, 'password');
    throw new HometaxError('password-input', `인증서 비밀번호 입력칸을 찾지 못했습니다.${file ? `\n화면 구조 저장: ${file}` : ''}`, true);
  }
  log('인증서 비밀번호를 입력합니다.');
  await pw.click();
  await pw.pressSequentially(password, { delay: 40 });
  if ((await pw.evaluate((el) => (el as HTMLInputElement).value.length)) !== password.length) {
    await pw.fill('');
    await pw.fill(password);
  }
  if ((await pw.evaluate((el) => (el as HTMLInputElement).value.length)) !== password.length) {
    await pw.fill('').catch(() => {});
    throw new HometaxError('password-input', '비밀번호가 입력창에 정확히 입력되지 않았습니다. 확인 버튼은 누르지 않았습니다.', true);
  }
  log('비밀번호 입력 후 확인 버튼을 클릭합니다.');
  if ((await evalStable(page, CONFIRM_PASSWORD_SCRIPT)) !== true) {
    const file = await saveDebugSnapshot(page, 'password-confirm');
    throw new HometaxError('password-input', `확인 버튼을 찾지 못했습니다.${file ? `\n화면 구조 저장: ${file}` : ''}`, true);
  }
}

/** 로그인 결과 알림을 닫은 뒤 주소가 바뀔 때까지 기다린다(다음 페이지). */
async function waitForNextPage(page: Page, log: LogFn): Promise<void> {
  const before = page.url();
  const moved = await page
    .waitForURL((u) => u.toString() !== before, { timeout: 30_000 })
    .then(() => true)
    .catch(() => false);
  if (moved) {
    log(`다음 페이지로 이동했습니다. (${page.url()})`, 'success');
    return;
  }
  const file = await saveDebugSnapshot(page, 'after-login');
  log(`다음 페이지로 이동하지 않았습니다. 열린 창에서 알림을 확인해 주세요.${file ? ` 화면 구조 저장: ${file}` : ''}`, 'warn');
}

/** 인증서 로그인 페이지(목록이 화면 안에 있는 형태)에서 선택 → 로그인 → 비밀번호 → 결과 확인까지 진행한다. */
async function loginInPage(
  page: Page,
  material: CertificateMaterial,
  expected: ExpectedCert,
  options: LoginOptions,
  log: LogFn
): Promise<void> {
  // 로그인 버튼을 누르면 사이트가 인증서 목록을 새로 열면서 선택을 첫 번째 인증서로 되돌린다.
  // 그래서 목록을 연 뒤에 사업자 인증서를 고른다.
  log('5. "공동인증서 로그인"을 눌러 인증서 목록을 엽니다.');
  await clickCertLogin(page);
  log('6. 인증서 목록에서 사업자 인증서를 고릅니다.');
  await selectCertificateInPage(page, expected, log);
  if (options.stopBeforePassword) {
    const selected = await saveDebugSnapshot(page, 'dry-run-selected');
    log(`테스트 모드: 인증서 선택까지 확인했습니다. 비밀번호는 입력하지 않고 멈춥니다.${selected ? ` ${selected}` : ''}`, 'warn');
    return;
  }
  log('7. 인증서 비밀번호를 입력합니다.');
  await enterPasswordInPage(page, material.password, log);

  const deadline = Date.now() + 90_000;
  let closedSince: number | undefined;
  while (Date.now() < deadline) {
    if (page.isClosed()) throw new HometaxError('page-error', '브라우저 창이 닫혀 로그인 결과를 확인하지 못했습니다.');
    const lines = ((await evalStable(page, BODY_TEXT_SCRIPT)) as string).split('\n').map((s) => s.trim());
    const problem = lines.find((l) => l.length > 0 && l.length <= 150 && (WRONG_PASSWORD_RE.test(l) || LOCKED_RE.test(l)));
    if (problem) {
      throw new HometaxError(
        'wrong-password',
        `인증서 비밀번호 확인에 실패했습니다: ${problem.slice(0, 120)}\n오류가 반복되면 인증서가 잠길 수 있어 자동으로 다시 시도하지 않습니다. 비밀번호를 확인해 다시 등록해 주세요.`
      );
    }
    // 로그인이 되면 사이트가 알림(확인 버튼이 있는 창)을 띄운다. 그 확인을 눌러야 다음 페이지로 넘어간다.
    const notice = await evalStable(page, popupScript(false)).catch(() => null);
    if (typeof notice === 'string') {
      log(`8. 로그인 결과 알림이 떴습니다: ${notice}`);
      await evalStable(page, popupScript(true)).catch(() => null);
      log('알림의 확인을 눌렀습니다.', 'success');
      await waitForNextPage(page, log);
      return;
    }

    // 알림 없이 인증서 창만 닫힌 경우에도 다음 페이지 이동을 기다린다.
    const stillOpen =
      (await page.locator('#nx-cert-select:visible').count()) > 0 || (await page.locator('input[type="password"]:visible').count()) > 0;
    if (stillOpen) {
      closedSince = undefined;
    } else {
      closedSince ??= Date.now();
      if (Date.now() - closedSince > 5_000) {
        await waitForNextPage(page, log);
        return;
      }
    }
    await sleep(500);
  }
  throw new HometaxError(
    'unknown-result',
    '90초 안에 로그인 결과를 확인하지 못했습니다. 열려 있는 브라우저에서 로그인 상태를 확인해 주세요.',
    true
  );
}

export interface LoginOptions {
  /** true 면 인증서 선택까지만 확인하고 비밀번호를 입력하지 않는다(선택이 맞는지 시험할 때 사용). */
  stopBeforePassword: boolean;
  /** 로그인 후 목록에서 찾을 발전월(REC 사이트 표기: YYYY-MM). */
  targetPeriod?: string;
  /** 발급 대상 발전량(kWh). 신청 2단계 화면의 발전량과 같을 때만 저장한다. */
  targetAmount?: number;
}

/** 저장된 발전 기간("2026.09.01 ~ 2026.09.30")을 REC 목록 표기("2026-09")로 바꾼다. */
export function toRecPeriod(generationPeriod?: string): string | undefined {
  const m = generationPeriod?.match(/(\d{4})[.-](\d{2})/);
  return m ? `${m[1]}-${m[2]}` : undefined;
}

export async function loginRec(
  session: HometaxSession,
  material: CertificateMaterial,
  businessNumber: string,
  log: LogFn,
  options: LoginOptions = { stopBeforePassword: false }
): Promise<void> {
  const { page, context } = session;
  const digits = businessNumber.replace(/\D/g, '');
  if (digits.length !== 10) {
    throw new HometaxError('unsupported-cert', '사업자번호가 10자리 숫자가 아니어서 REC 사이트에 입력할 수 없습니다.', true);
  }
  const expected = describeCertificate(material);
  // 하드디스크 인증서를 읽을 수 있도록 인증서 로그인 페이지(kcert)의 로컬 네트워크 접근을 미리 허용한다.
  // (이 허용이 없으면 브라우저가 "이 기기의 다른 앱 및 서비스에 액세스" 권한을 물어본다.)
  await context.grantPermissions(['local-network-access' as any], { origin: KCERT_ORIGIN }).catch(() => {});

  const dialogMessages: string[] = [];
  const onDialog = (d: import('playwright').Dialog) => {
    dialogMessages.push(d.message());
    (d.type() === 'alert' ? d.accept() : d.dismiss()).catch(() => {});
  };
  page.on('dialog', onDialog);
  // 페이지 이동 시각을 로그로 남긴다(사이트 응답이 느린 구간을 찾기 위한 기록).
  const started = Date.now();
  const onFrameNavigated = (frame: import('playwright').Frame) => {
    if (frame === page.mainFrame()) {
      log(`페이지 이동: ${frame.url()} (시작 후 ${((Date.now() - started) / 1000).toFixed(1)}초)`);
    }
  };
  page.on('framenavigated', onFrameNavigated);
  let loginPage: Page | null = null;

  try {
    // 1. REC 로그인 페이지 접속
    log('1. REC 발행 사이트에 접속합니다.');
    await page.goto(REC_LOGIN_URL, { waitUntil: 'domcontentloaded', timeout: 60_000 });

    // 2. 접속하면 뜨는 팝업(창·레이어)을 모두 닫고, 남은 팝업이 없는지 확인한다.
    log('2. 팝업을 닫습니다.');
    await closeRecPopups(session, log);

    // 2-1. 발전사업자 공동인증서로그인 클릭 → 사업자번호 입력칸 확인
    log('2-1. 발전사업자 "공동인증서로그인"을 클릭합니다.');
    const clickedAt = Date.now();
    await clickCertLogin(page);

    // 3. 사업자번호 3칸이 나타나면 입력 후 다시 공동인증서로그인 클릭
    let parts: [Locator, Locator, Locator];
    try {
      parts = await waitForBusinessNumberParts(page, 15_000);
    } catch {
      throw new HometaxError('page-error', 'REC 사이트에서 사업자번호 입력칸을 찾지 못했습니다. 화면 구조가 바뀌었는지 확인해 주세요.', true);
    }
    log(`3. 사업자번호 입력칸이 나타났습니다(클릭 후 ${((Date.now() - clickedAt) / 1000).toFixed(1)}초). 사업자번호를 입력하고 공동인증서로그인을 다시 클릭합니다.`);
    await parts[0].fill(digits.slice(0, 3));
    await parts[1].fill(digits.slice(3, 5));
    await parts[2].fill(digits.slice(5));
    await clickCertLogin(page);

    // 4. 인증서 로그인 페이지(kcert)로 넘어가 사업자번호가 채워진 것을 확인하고 공동인증서 로그인을 누른다.
    log('4. 인증서 로그인 페이지로 이동하기를 기다립니다.');
    loginPage = await waitForKcertPage(session);
    loginPage.on('dialog', onDialog);
    await loginPage.waitForSelector('#nx-cert-select, iframe[name="dscert"]', { timeout: 30_000 }).catch(() => {});
    if ((await loginPage.locator('#nx-cert-select').count()) > 0) {
      await loginInPage(loginPage, material, expected, options, log);
      await afterLogin(loginPage, options, log);
      return;
    }
    log(`5. 인증서 로그인 페이지에서 "공동인증서 로그인"을 클릭합니다. (${loginPage.url()})`);
    await clickCertLogin(loginPage);

    // 6. 인증서 선택창에서 사업자에 등록된 인증서와 같은 인증서 선택
    await waitForCertList(loginPage);
    log('6. 인증서 선택창에서 사업자 인증서와 일치하는 항목을 찾습니다.');
    await selectMatchingCertificate(loginPage, expected, log);
    if (options.stopBeforePassword) {
      log('테스트 모드: 인증서 선택까지만 확인했습니다. 비밀번호는 입력하지 않고 멈춥니다.', 'warn');
      return;
    }

    // 7. 비밀번호 입력 후 확인
    log('7. 인증서 비밀번호를 입력합니다.');
    const dialogsBefore = dialogMessages.length;
    await submitCertificatePassword(loginPage, material.password, log);

    // 8. 로그인 결과 확인: 인증서 선택창이 사라지면 로그인 완료로 본다.
    const target = loginPage;
    const deadline = Date.now() + 90_000;
    while (Date.now() < deadline) {
      if (target.isClosed()) throw new HometaxError('page-error', '브라우저 창이 닫혀 로그인 결과를 확인하지 못했습니다.');

      const certFrame = target.frame({ name: 'dscert' });
      const messages = dialogMessages.slice(dialogsBefore);
      if (certFrame) {
        const text = ((await certFrame.evaluate('(() => (document.body && document.body.innerText) || "")()').catch(() => '')) as string)
          .split('\n')
          .map((s) => s.trim());
        messages.push(...text.filter((l) => l.length > 0 && l.length <= 150 && (WRONG_PASSWORD_RE.test(l) || LOCKED_RE.test(l))));
      }
      const problem = messages.find((m) => WRONG_PASSWORD_RE.test(m) || LOCKED_RE.test(m));
      if (problem) {
        throw new HometaxError(
          'wrong-password',
          `인증서 비밀번호 확인에 실패했습니다: ${problem.replace(/\s+/g, ' ').slice(0, 120)}\n오류가 반복되면 인증서가 잠길 수 있어 자동으로 다시 시도하지 않습니다. 비밀번호를 확인해 다시 등록해 주세요.`
        );
      }

      if (!certFrame) {
        log('8. 인증서 선택창이 닫혔습니다. REC 사이트에서 로그인 상태를 확인해 주세요.', 'success');
        return;
      }
      await sleep(500);
    }
    throw new HometaxError(
      'unknown-result',
      '90초 안에 로그인 결과를 확인하지 못했습니다. 열려 있는 브라우저에서 로그인 상태를 확인해 주세요.',
      true
    );
  } catch (err: any) {
    if (err instanceof HometaxError) throw err;
    let msg = String(err?.message || err).split('\n')[0].slice(0, 200);
    if (material.password) msg = msg.split(material.password).join('***');
    throw new HometaxError('page-error', `REC 사이트 처리 중 오류가 발생했습니다: ${msg}`, true);
  } finally {
    page.off('dialog', onDialog);
    page.off('framenavigated', onFrameNavigated);
    loginPage?.off('dialog', onDialog);
  }
}
