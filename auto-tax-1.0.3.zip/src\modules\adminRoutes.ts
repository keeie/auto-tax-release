import express, { Express, Request, Response } from 'express';
import { loadConfig } from '../config';
import { CollectorService } from './collector';
import { removeOperatorCertificate, saveOperatorCertificate } from './certStore';
import { InvoiceService } from './invoiceService';
import { RecService } from './recService';
import { extractLicenseText, LicenseError } from './licenseOcr';
import { parseBusinessLicenseText } from './licenseParser';
import { resetAllData } from './resetData';
import { applyUpdate, checkForUpdate, restartServerSoon, RUNNING_VERSION } from './updater';
import { HttpError, PlantService, RegistryStorage } from './registry';
import { DataStorage } from './storage';

const outputDir = () => loadConfig().options.outputDir;
const bodyOf = (req: Request): Record<string, any> =>
  req.body && typeof req.body === 'object' && !Buffer.isBuffer(req.body) ? req.body : {};

const wrap =
  (fn: (req: Request) => Promise<Record<string, unknown>> | Record<string, unknown>) =>
  async (req: Request, res: Response) => {
    try {
      const result = await fn(req);
      res.json({ success: true, ...result });
    } catch (err: any) {
      const status = err instanceof HttpError || err instanceof LicenseError ? err.status : 500;
      if (status >= 500) console.error('[AdminAPI] 오류:', err);
      res.status(status).json({ success: false, message: err?.message || '요청 처리 중 오류가 발생했습니다.' });
    }
  };

export function registerAdminRoutes(app: Express) {
  // ----- 자동 업데이트 -----
  // 제어 패널이 실행 중인 버전과 작업 중 여부(업데이트 보류 판단)를 읽는다.
  app.get(
    '/api/app/info',
    wrap(() => {
      const invoice = InvoiceService.getInstance().getStatus();
      const busy =
        CollectorService.getInstance().getStatus().status === 'running' ||
        invoice.status === 'running' ||
        invoice.browserOpen;
      return { version: RUNNING_VERSION, busy };
    })
  );

  app.get(
    '/api/update/check',
    wrap(async () => ({ ...(await checkForUpdate(loadConfig().options.updateManifestUrl || '')) }))
  );

  app.post(
    '/api/update/apply',
    wrap(async (req) => {
      if (bodyOf(req).confirm !== '업데이트') throw new HttpError(400, '확인 문구가 일치하지 않습니다.');
      if (CollectorService.getInstance().getStatus().status === 'running') {
        throw new HttpError(409, '메일 수집이 진행 중입니다. 끝난 뒤에 업데이트해 주세요.');
      }
      const invoice = InvoiceService.getInstance().getStatus();
      if (invoice.status === 'running' || invoice.browserOpen) {
        throw new HttpError(409, '세금계산서 발행 작업이 진행 중입니다. 끝난 뒤에 업데이트해 주세요.');
      }
      const manifestUrl = loadConfig().options.updateManifestUrl || '';
      if (!manifestUrl) throw new HttpError(400, 'config.json 의 options.updateManifestUrl 이 설정되지 않았습니다.');
      const result = await applyUpdate(manifestUrl);
      // 응답을 보낸 뒤 서버를 다시 띄우고, 이 프로세스는 종료한다(launcher 가 아니어도 동작하도록 직접 띄운다).
      setTimeout(() => {
        restartServerSoon();
        process.exit(0);
      }, 1500);
      return { ...result, restarting: true };
    })
  );

  // ----- 전체 데이터 초기화 (되돌릴 수 없음) -----
  app.post(
    '/api/reset',
    wrap((req) => {
      if (bodyOf(req).confirm !== '초기화') throw new HttpError(400, '확인 문구가 일치하지 않습니다.');
      return resetAllData();
    })
  );

  // ----- 발전소 -----
  app.get('/api/plants', wrap(() => ({ plants: new PlantService(outputDir()).listPlants() })));

  app.post('/api/plants', wrap(async (req) => ({ plant: await new PlantService(outputDir()).createPlant(bodyOf(req)) })));

  app.put(
    '/api/plants/:folderId',
    wrap(async (req) => ({ plant: await new PlantService(outputDir()).updatePlant(String(req.params.folderId), bodyOf(req)) }))
  );

  // ----- 사업자 -----
  app.get('/api/operators', wrap(() => ({ operators: new RegistryStorage(outputDir()).listOperators() })));

  app.post('/api/operators', wrap((req) => ({ operator: new RegistryStorage(outputDir()).createOperator(bodyOf(req)) })));

  // 사업자등록증 확인 후 저장: 등록번호가 같은 사업자가 있으면 수정, 없으면 신규 등록
  app.post(
    '/api/operators/upsert',
    wrap((req) => new RegistryStorage(outputDir()).upsertByRegistrationNumber(bodyOf(req)))
  );

  // 사업자등록증(이미지/PDF) 업로드 -> 텍스트 인식 -> 항목 추출 (저장은 하지 않고 미리보기만 반환)
  app.post(
    '/api/operators/license/parse',
    express.raw({ type: () => true, limit: '15mb' }),
    wrap(async (req) => {
      const buf = req.body;
      if (!Buffer.isBuffer(buf) || buf.length === 0) throw new LicenseError('업로드된 파일이 없습니다.', 400);

      const { kind, text } = await extractLicenseText(buf);
      const parsed = parseBusinessLicenseText(text);
      const registrationNumber = parsed.fields.registrationNumber;
      const existing = registrationNumber
        ? new RegistryStorage(outputDir()).findByRegistrationNumber(registrationNumber)
        : undefined;

      return {
        kind,
        fields: parsed.fields,
        warnings: parsed.warnings,
        rawText: text,
        mode: existing ? 'update' : 'create',
        existing: existing ?? null,
      };
    })
  );

  app.put(
    '/api/operators/:id',
    wrap((req) => ({ operator: new RegistryStorage(outputDir()).updateOperator(String(req.params.id), bodyOf(req)) }))
  );

  // ----- 공동인증서(공인인증서) -----
  // 응답에는 비밀번호나 인증서 내용이 포함되지 않고, 표시용 요약(certificate)만 돌려준다.
  app.put(
    '/api/operators/:id/certificate',
    wrap(async (req) => ({
      operator: await saveOperatorCertificate(new RegistryStorage(outputDir()), String(req.params.id), bodyOf(req)),
    }))
  );

  app.delete(
    '/api/operators/:id/certificate',
    wrap((req) => ({ operator: removeOperatorCertificate(new RegistryStorage(outputDir()), String(req.params.id)) }))
  );

  // ----- 발전월별 세금계산서 발행 완료 여부 (직접 수정) -----
  app.put(
    '/api/invoice/issued',
    wrap((req) => {
      const { folderId, generationPeriod, issued } = bodyOf(req);
      if (typeof folderId !== 'string' || !folderId || typeof generationPeriod !== 'string' || !generationPeriod) {
        throw new HttpError(400, 'folderId 및 generationPeriod 가 필요합니다.');
      }
      if (typeof issued !== 'boolean') throw new HttpError(400, 'issued 는 true 또는 false 여야 합니다.');
      const exists = new DataStorage(outputDir())
        .getAllBusinessesData()
        .businesses.some((b) => b.folderId === folderId && b.periods.some((p) => p.generationPeriod === generationPeriod));
      if (!exists) throw new HttpError(404, '해당 발전월 데이터를 찾을 수 없습니다.');
      return { invoice: new RegistryStorage(outputDir()).setInvoiceIssued(folderId, generationPeriod, issued) };
    })
  );

  // ----- 세금계산서 발행 프로세스 (홈택스 로그인 → 발행정보 입력까지) -----
  app.post(
    '/api/invoice/issue',
    wrap((req) => {
      const { message } = InvoiceService.getInstance().start(bodyOf(req), { outputDir: outputDir() });
      return { started: true, message };
    })
  );

  app.get(
    '/api/invoice/status',
    wrap((req) => ({ ...InvoiceService.getInstance().getStatus(typeof req.query.since === 'string' ? req.query.since : undefined) }))
  );

  // ----- REC 발행 (REC 사이트 공동인증서 로그인까지) -----
  app.post(
    '/api/rec/start',
    wrap((req) => {
      const { message } = RecService.getInstance().start(bodyOf(req), { outputDir: outputDir() });
      return { started: true, message };
    })
  );

  app.get(
    '/api/rec/status',
    wrap((req) => ({ ...RecService.getInstance().getStatus(typeof req.query.since === 'string' ? req.query.since : undefined) }))
  );
}
