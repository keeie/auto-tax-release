import { loadConfig } from '../config';
import { CollectionLog } from '../types';
import { CertificateMaterial, loadCertificateMaterial } from './certStore';
import { HometaxError, HometaxSession, LogFn, launchHometaxBrowser } from './hometax';
import { HttpError, RegistryStorage } from './registry';
import { DataStorage } from './storage';
import { loginRec, LoginOptions, REC_ORIGIN, toRecPeriod } from './recLogin';

/**
 * REC 발행 프로세스(현재 범위: REC 사이트 공동인증서 로그인까지).
 * 발전소 → 소속 사업자 → 등록된 공동인증서 확인 → 새 브라우저로 REC 사이트 로그인.
 * 로그인에 성공하면 브라우저를 열어 둔다.
 */

export interface RecStatus {
  status: 'idle' | 'running' | 'completed' | 'error';
  startedAt?: string;
  finishedAt?: string;
  error?: string;
  errorCode?: string;
  browserOpen: boolean;
  request?: { folderId: string; plantName: string; operatorName: string; generationPeriod?: string };
  logs: CollectionLog[];
}

export interface RecRequest {
  folderId?: unknown;
  generationPeriod?: unknown;
  /** true 면 인증서 선택까지만 확인하고 비밀번호를 입력하지 않는다(테스트용). */
  dryRun?: unknown;
}

export interface RecStartOptions {
  outputDir: string;
  configPath?: string;
  // 테스트에서 실제 브라우저 없이 흐름을 검증하기 위한 주입 지점
  launch?: () => Promise<HometaxSession>;
  login?: (session: HometaxSession, material: CertificateMaterial, businessNumber: string, log: LogFn, options: LoginOptions) => Promise<void>;
}

const text = (v: unknown, max = 60) => (typeof v === 'string' ? v.replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max) : '');

export class RecService {
  private static instance: RecService;

  public static getInstance(): RecService {
    if (!RecService.instance) RecService.instance = new RecService();
    return RecService.instance;
  }

  private state: Omit<RecStatus, 'logs' | 'browserOpen'> = { status: 'idle' };
  private logs: CollectionLog[] = [];
  private running = false;
  // 실행마다 번호를 붙인다. 사용자가 브라우저를 닫아 중단된 예전 실행이 뒤늦게 상태를 바꾸지 못하게 한다.
  private runId = 0;
  private session: HometaxSession | null = null;
  private currentRun: Promise<void> = Promise.resolve();
  // 비밀번호 오류로 실패한 인증서(사업자ID → 등록 시각). 같은 인증서로 반복하면 잠길 수 있어 막는다.
  private passwordBlocked = new Map<string, string>();

  public getStatus(since?: string): RecStatus {
    return {
      ...this.state,
      browserOpen: !!this.session && this.session.browser.isConnected(),
      logs: since ? this.logs.filter((l) => l.timestamp > since) : [...this.logs],
    };
  }

  public waitForCompletion(): Promise<void> {
    return this.currentRun;
  }

  private log: LogFn = (message, level = 'info') => {
    this.logs.push({ timestamp: new Date().toISOString(), message, level });
    if (this.logs.length > 300) this.logs.shift();
    const prefix = level === 'error' ? '❌' : level === 'warn' ? '⚠️' : level === 'success' ? '✅' : 'ℹ️';
    console.log(`[REC] ${prefix} ${message}`);
  };

  public async closeSession() {
    const s = this.session;
    this.session = null;
    if (s) await s.browser.close().catch(() => {});
  }

  /** 요청을 검증하고 백그라운드로 로그인을 시작한다. 검증에 실패하면 HttpError 를 던진다. */
  public start(input: RecRequest, opts: RecStartOptions): { message: string } {
    if (this.running) throw new HttpError(409, '이미 REC 발행 작업이 진행 중입니다.');

    const folderId = text(input.folderId, 20);
    if (!folderId) throw new HttpError(400, '발전소 정보(folderId)가 없어 REC 발행을 시작할 수 없습니다.');

    const folder = loadConfig(opts.configPath).folders.find((f) => f.folderId === folderId);
    if (!folder) throw new HttpError(404, '등록되지 않은 발전소입니다.');

    const registry = new RegistryStorage(opts.outputDir);
    const record = registry.getPlantRecord(folderId);
    const operator = record?.operatorId ? registry.getOperator(record.operatorId) : undefined;
    if (!operator) {
      throw new HttpError(400, `[${folder.businessName}] 발전소에 소속 사업자가 지정되어 있지 않습니다. '사업자/발전소 관리'에서 소속 사업자를 지정해 주세요.`);
    }
    const cert = operator.certificate;
    if (!cert) {
      throw new HttpError(400, `[${operator.businessName}] 사업자에 공동인증서가 등록되어 있지 않습니다. '사업자/발전소 관리 → 사업자 목록 → 수정'에서 인증서를 등록해 주세요.`);
    }
    if (cert.validTo && new Date(cert.validTo).getTime() < Date.now()) {
      throw new HttpError(400, `등록된 인증서가 만료되었습니다. (만료일: ${cert.validTo.slice(0, 10)}) 갱신한 인증서를 다시 등록해 주세요.`);
    }
    if (this.passwordBlocked.get(operator.id) === cert.updatedAt) {
      throw new HttpError(
        409,
        '이전 로그인에서 인증서 비밀번호 오류가 발생했습니다. 같은 비밀번호로 반복 시도하면 인증서가 잠길 수 있어 막아 두었습니다. 사업자 수정 화면에서 비밀번호를 다시 등록한 뒤 시도해 주세요.'
      );
    }
    const digits = (operator.registrationNumber || '').replace(/\D/g, '');
    if (digits.length !== 10) {
      throw new HttpError(400, `[${operator.businessName}] 사업자등록번호가 올바르지 않아 REC 사이트에 입력할 수 없습니다.`);
    }

    const generationPeriod = text(input.generationPeriod) || undefined;

    // 발급 대상 발전량은 수집된 명세서에서 읽는다(신청 2단계 화면과 비교하는 기준).
    let targetAmount: number | undefined;
    if (generationPeriod) {
      const periodData = new DataStorage(opts.outputDir)
        .getAllBusinessesData()
        .businesses.find((b) => b.folderId === folderId)
        ?.periods.find((p) => p.generationPeriod === generationPeriod);
      if (!periodData) throw new HttpError(404, `[${folder.businessName}] 발전소의 ${generationPeriod} 수집 데이터를 찾을 수 없습니다.`);
      if (periodData.items.length !== 1) {
        throw new HttpError(400, `[${generationPeriod}] 명세서가 ${periodData.items.length}건이라 발급 대상 발전량을 정할 수 없습니다.`);
      }
      targetAmount = periodData.items[0].generationData.generationAmount ?? undefined;
    }

    this.running = true;
    const runId = ++this.runId;
    this.logs = [];
    this.state = {
      status: 'running',
      startedAt: new Date().toISOString(),
      request: { folderId, plantName: folder.businessName, operatorName: operator.businessName, generationPeriod },
    };

    const dryRun = input.dryRun === true;
    this.currentRun = this.run(operator.id, operator.businessName, digits, cert.updatedAt, opts, dryRun, runId, toRecPeriod(generationPeriod), targetAmount);
    return {
      message: dryRun
        ? 'REC 테스트를 시작했습니다. 인증서 선택까지만 확인하고 비밀번호는 입력하지 않습니다.'
        : 'REC 발행 사이트 로그인을 시작했습니다. 새 브라우저 창에서 진행합니다.',
    };
  }

  private async run(
    operatorId: string,
    operatorName: string,
    businessNumber: string,
    certUpdatedAt: string,
    opts: RecStartOptions,
    dryRun: boolean,
    runId: number,
    targetPeriod: string | undefined,
    targetAmount: number | undefined
  ) {
    let material: CertificateMaterial | null = null;
    try {
      this.log(`사업자 [${operatorName}] REC 발행 로그인을 시작합니다.`);
      this.log('등록된 공동인증서 정보를 불러옵니다.');
      material = await loadCertificateMaterial(operatorId);

      await this.closeSession(); // 이전 실행에서 열어 둔 브라우저 정리
      this.log('REC 사이트용 새 브라우저를 실행합니다.');
      const session = await (opts.launch ?? launchHometaxBrowser)();
      this.session = session;
      // 사용자가 브라우저 창을 닫으면 이 실행을 바로 중단으로 처리해 다음 실행을 막지 않는다.
      session.browser.on('disconnected', () => this.abortRun(runId, '브라우저 창이 닫혀 REC 발행 작업이 중단되었습니다.'));
      // 하드디스크 인증서를 읽을 수 있도록 REC 사이트의 로컬 네트워크 접근을 미리 허용한다.
      await session.context.grantPermissions(['local-network-access' as any], { origin: REC_ORIGIN }).catch(() => {});

      await (opts.login ?? loginRec)(session, material, businessNumber, this.log, { stopBeforePassword: dryRun, targetPeriod, targetAmount });
      material = null; // 로그인 이후에는 비밀번호가 필요 없다

      this.state = { ...this.state, status: 'completed', finishedAt: new Date().toISOString() };
      this.log('REC 사이트 로그인 단계를 마쳤습니다. 발급 작업은 열려 있는 브라우저에서 직접 진행해 주세요.', 'warn');
    } catch (err: any) {
      // 이미 중단 처리된 실행(브라우저를 닫은 경우)이면 상태를 덮어쓰지 않는다.
      if (runId !== this.runId) return;
      const code = err instanceof HometaxError ? err.code : 'error';
      const message = String(err?.message || err);
      this.log(`REC 발행 중단: ${message}`, 'error');
      this.state = { ...this.state, status: 'error', error: message, errorCode: code, finishedAt: new Date().toISOString() };
      if (code === 'wrong-password') this.passwordBlocked.set(operatorId, certUpdatedAt);
      if (!(err instanceof HometaxError && err.keepBrowserOpen)) await this.closeSession();
    } finally {
      material = null; // 비밀번호 참조를 즉시 버린다
      if (runId === this.runId) this.running = false;
    }
  }

  /** 브라우저가 닫혀 실행이 끝났을 때 호출한다. 현재 실행일 때만 중단 처리하고 다음 실행을 허용한다. */
  private abortRun(runId: number, message: string) {
    // 앱이 직접 닫은 경우(closeSession 은 먼저 session 을 비운다)에는 중단으로 보지 않는다.
    if (runId !== this.runId || !this.running || !this.session) return;
    this.running = false;
    this.session = null;
    this.log(`REC 발행 중단: ${message}`, 'error');
    this.state = { ...this.state, status: 'error', error: message, errorCode: 'browser-closed', finishedAt: new Date().toISOString() };
  }
}
