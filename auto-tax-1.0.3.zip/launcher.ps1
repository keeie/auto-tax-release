﻿param([switch]$Headless)

# auto-tax 제어 패널: 서버 시작/중지, 업데이트 확인, 브라우저/로그 열기
# 실행: auto-tax.vbs (콘솔 창 없이 이 파일을 띄움)
# 업데이트:
#   - 패널을 처음 열 때 새 버전을 확인하고, 있으면 설치한 뒤 새 버전으로 서버를 띄운다.
#   - 서버가 실행 중이면 30초마다 확인한다. 새 버전이 있으면 "새 버전이 있습니다." 를 띄우고 업데이트 버튼을 보여 준다.
#   - 업데이트 버튼을 누르면 실행 중인 서버를 멈추고 → 설치하고 → 멈췄던 서버를 새 버전으로 다시 띄운다.
#   이 파일(패널 자신)도 새 버전으로 바뀌었으면 패널을 다시 띄운다.
#   수집·발행 작업이 진행 중이면 보류한다.

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$port = if ($env:PORT) { [int]$env:PORT } else { 3000 }
$url = "http://127.0.0.1:$port"
$pidFile = Join-Path $root '.run\server.pid'
$logFile = Join-Path $root 'logs\server.log'
$updateCheckSeconds = 30

$script:opBusy = $false
$script:relaunching = $false
$script:availableVersion = $null
$script:nextUpdateCheck = Get-Date

function Get-DiskVersion {
  $pkg = Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $root 'package.json') | ConvertFrom-Json
  return [string]$pkg.version
}

function Get-LauncherHash {
  return (Get-FileHash -Algorithm SHA256 -LiteralPath $PSCommandPath).Hash
}

$script:version = Get-DiskVersion
$script:launcherHash = Get-LauncherHash

function Get-ListenerPid {
  $conn = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($conn) { return [int]$conn.OwningProcess }
  return 0
}

function Test-AutoTaxProcess([int]$targetPid, [string]$pattern) {
  $p = Get-CimInstance Win32_Process -Filter "ProcessId=$targetPid" -ErrorAction SilentlyContinue
  return [bool]($p -and $p.CommandLine -match $pattern)
}

# running: 우리 서버가 포트를 사용 중 / foreign: 다른 프로그램이 사용 중 / stopped: 비어 있음
function Get-ServerState {
  $listenerPid = Get-ListenerPid
  if ($listenerPid -eq 0) { return 'stopped' }
  if (Test-AutoTaxProcess $listenerPid 'src.index\.ts') { return 'running' }
  return 'foreign'
}

# 실행 중인 서버에게 버전과 작업 여부를 묻는다. 응답이 없으면 $null.
function Get-AppInfo {
  try { return Invoke-RestMethod -Uri "$url/api/app/info" -TimeoutSec 1 } catch { return $null }
}

function Wait-Until([scriptblock]$condition, [int]$seconds) {
  for ($i = 0; $i -lt ($seconds * 2); $i++) {
    if (& $condition) { return $true }
    Start-Sleep -Milliseconds 500
    if (-not $Headless) { [System.Windows.Forms.Application]::DoEvents() }
  }
  return [bool](& $condition)
}

function Start-Server {
  if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    return 'Node.js가 설치되어 있지 않습니다. https://nodejs.org 에서 LTS 버전을 설치하세요.'
  }
  if ((Get-ServerState) -ne 'stopped') { return '포트가 이미 사용 중입니다.' }

  if (-not (Test-Path (Join-Path $root 'node_modules'))) {
    $install = Start-Process -FilePath 'cmd.exe' -ArgumentList '/c npm install' -WorkingDirectory $root -WindowStyle Hidden -PassThru
    if (-not $Headless) {
      while (-not $install.HasExited) { Start-Sleep -Milliseconds 200; [System.Windows.Forms.Application]::DoEvents() }
    } else {
      $install.WaitForExit()
    }
    if ($install.ExitCode -ne 0) { return 'npm install 실패. 콘솔에서 npm install을 직접 실행해 확인하세요.' }
  }

  New-Item -ItemType Directory -Force -Path (Split-Path $logFile), (Split-Path $pidFile) | Out-Null
  $proc = Start-Process -FilePath 'cmd.exe' -ArgumentList "/c npm run start >> `"$logFile`" 2>&1" -WorkingDirectory $root -WindowStyle Hidden -PassThru
  Set-Content -Path $pidFile -Value $proc.Id -Encoding ascii

  if (Wait-Until { (Get-ServerState) -eq 'running' } 60) { return $null }
  return '60초 안에 서버가 시작되지 않았습니다. 로그를 확인하세요.'
}

function Stop-Server {
  # 시작할 때 저장한 PID(cmd → npm → node 트리)를 먼저 종료
  if (Test-Path $pidFile) {
    $savedPid = (Get-Content $pidFile -ErrorAction SilentlyContinue | Select-Object -First 1)
    if ($savedPid -match '^\d+$' -and (Test-AutoTaxProcess ([int]$savedPid) 'npm run start')) {
      & taskkill /T /F /PID $savedPid | Out-Null
    }
    Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
  }
  # PID 파일이 없을 때 대비: 포트 사용 프로세스가 우리 서버이면 종료
  $listenerPid = Get-ListenerPid
  if ($listenerPid -ne 0 -and (Test-AutoTaxProcess $listenerPid 'src.index\.ts')) {
    & taskkill /T /F /PID $listenerPid | Out-Null
  }
  if (Wait-Until { (Get-ServerState) -eq 'stopped' } 10) { return $null }
  return '서버를 완전히 종료하지 못했습니다.'
}

# npm 명령을 숨긴 창에서 실행하고 끝날 때까지 기다린다. 출력은 logs\<logName> 에 남는다.
function Invoke-Cli([string]$npmScript, [string]$logName) {
  New-Item -ItemType Directory -Force -Path (Join-Path $root 'logs') | Out-Null
  $log = Join-Path $root "logs\$logName"
  $proc = Start-Process -FilePath 'cmd.exe' -ArgumentList "/c npm run $npmScript > `"$log`" 2>&1" -WorkingDirectory $root -WindowStyle Hidden -PassThru
  if ($Headless) {
    $proc.WaitForExit()
  } else {
    while (-not $proc.HasExited) { Start-Sleep -Milliseconds 200; [System.Windows.Forms.Application]::DoEvents() }
  }
  $output = ''
  if (Test-Path $log) { $output = Get-Content -Raw -Encoding UTF8 -LiteralPath $log }
  return [pscustomobject]@{ Code = $proc.ExitCode; Output = [string]$output }
}

function Get-MarkerValue([string]$output, [string]$marker) {
  foreach ($line in ($output -split "`r?`n")) {
    if ($line.StartsWith($marker)) { return $line.Substring($marker.Length).Trim() }
  }
  return $null
}

function Get-FailureText([string]$output) {
  $text = Get-MarkerValue $output 'UPDATE_ERROR '
  if ($text) { return $text }
  $last = $output -split "`r?`n" | Where-Object { $_.Trim() } | Select-Object -Last 1
  if ($last) { return $last } else { return '알 수 없는 오류' }
}

# 새 버전이 있는지만 확인한다(설치하지 않음). Ok=false 면 확인에 실패한 것이다.
function Get-UpdateInfo {
  $check = Invoke-Cli 'update:check' 'update.log'
  $checkJson = Get-MarkerValue $check.Output 'UPDATE_CHECK '
  if ($check.Code -ne 0 -or -not $checkJson) {
    return [pscustomobject]@{ Ok = $false; Configured = $false; Available = $false; Latest = $null; Current = $script:version; Message = "업데이트 확인 실패: $(Get-FailureText $check.Output)" }
  }
  $info = $checkJson | ConvertFrom-Json
  return [pscustomobject]@{
    Ok = $true
    Configured = [bool]$info.configured
    Available = [bool]$info.available
    Latest = [string]$info.latest
    Current = [string]$info.current
    Message = ''
  }
}

# 업데이트 본체. 서버를 멈춰야 하면 멈추고 Stopped=true 로 돌려준다(다시 띄우는 일은 호출한 쪽).
function Invoke-UpdateCore {
  $info = Get-UpdateInfo
  if (-not $info.Ok) {
    return [pscustomobject]@{ Message = $info.Message; Updated = $false; Stopped = $false }
  }
  if (-not $info.Configured) {
    return [pscustomobject]@{ Message = '업데이트 주소가 설정되지 않아 확인하지 않았습니다(config.json options.updateManifestUrl).'; Updated = $false; Stopped = $false }
  }
  if (-not $info.Available) {
    $script:availableVersion = $null
    return [pscustomobject]@{ Message = "최신 버전입니다 (v$($info.Current))."; Updated = $false; Stopped = $false }
  }

  $latest = $info.Latest
  $stopped = $false
  if ((Get-ServerState) -eq 'running') {
    $appInfo = Get-AppInfo
    if (-not $appInfo) {
      return [pscustomobject]@{ Message = "v$latest 이 있지만 실행 중인 서버 상태를 확인하지 못해 보류했습니다."; Updated = $false; Stopped = $false }
    }
    if ($appInfo.busy) {
      return [pscustomobject]@{ Message = "v$latest 이 있지만 메일 수집 또는 세금계산서 작업이 진행 중이라 보류했습니다."; Updated = $false; Stopped = $false }
    }
    $stopError = Stop-Server
    if ($stopError) {
      return [pscustomobject]@{ Message = "업데이트를 위해 서버를 멈추지 못했습니다: $stopError"; Updated = $false; Stopped = $false }
    }
    $stopped = $true
  }

  $apply = Invoke-Cli 'update:apply' 'update.log'
  $applied = Get-MarkerValue $apply.Output 'UPDATE_APPLIED '
  if ($apply.Code -ne 0 -or -not $applied) {
    return [pscustomobject]@{ Message = "업데이트(v$latest) 실패: $(Get-FailureText $apply.Output)"; Updated = $false; Stopped = $stopped }
  }
  $script:version = Get-DiskVersion
  $script:availableVersion = $null
  return [pscustomobject]@{ Message = "v$applied 으로 업데이트했습니다."; Updated = $true; Stopped = $stopped }
}

# 업데이트 → 서버 띄우기 → (패널 자신이 바뀌었으면 패널 다시 띄우기). 화면에 보일 문장을 돌려준다.
# 서버를 멈춰 둔 경우는 새 버전으로 다시 띄운다. startAfter 이면 멈춰 있던 서버도 업데이트 뒤에 띄운다(첫 실행용).
function Update-Flow([bool]$startAfter = $false) {
  $result = Invoke-UpdateCore
  $message = $result.Message
  if ($result.Stopped -or ($startAfter -and $result.Updated)) {
    $startError = Start-Server
    if ($startError) {
      return "$message 서버를 시작하지 못했습니다: $startError"
    }
    if ($result.Updated) { $message = "$message 새 버전으로 서버를 시작했습니다." }
    else { $message = "$message 서버를 이전 버전으로 다시 시작했습니다." }
  }
  if (-not $Headless -and $result.Updated -and (Get-LauncherHash) -ne $script:launcherHash) {
    $script:relaunching = $true
    Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', "`"$PSCommandPath`"")
    $form.Close()
  }
  return $message
}

if ($Headless) {
  Write-Output "version: $script:version, state before: $(Get-ServerState)"
  $err = Start-Server
  Write-Output "start result: $err, state: $(Get-ServerState)"
  $err = Stop-Server
  Write-Output "stop result: $err, state: $(Get-ServerState)"
  exit 0
}

# ---------- 패널 UI ----------
[System.Windows.Forms.Application]::EnableVisualStyles()

$form = New-Object System.Windows.Forms.Form
$form.Text = "auto-tax v$($script:version)"
$form.Size = New-Object System.Drawing.Size(500, 255)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.Font = New-Object System.Drawing.Font('Segoe UI', 10)
$iconFile = Join-Path $root 'assets\icon.ico'
if (Test-Path $iconFile) { $form.Icon = New-Object System.Drawing.Icon($iconFile) }

$title = New-Object System.Windows.Forms.Label
$title.Text = "auto-tax 서버  v$($script:version)"
$title.Font = New-Object System.Drawing.Font('Segoe UI', 14, [System.Drawing.FontStyle]::Bold)
$title.Location = New-Object System.Drawing.Point(20, 15)
$title.AutoSize = $true
$form.Controls.Add($title)

$stateLabel = New-Object System.Windows.Forms.Label
$stateLabel.Location = New-Object System.Drawing.Point(22, 56)
$stateLabel.Size = New-Object System.Drawing.Size(450, 24)
$form.Controls.Add($stateLabel)

$msgLabel = New-Object System.Windows.Forms.Label
$msgLabel.Location = New-Object System.Drawing.Point(22, 84)
$msgLabel.Size = New-Object System.Drawing.Size(450, 44)
$msgLabel.ForeColor = [System.Drawing.Color]::DimGray
$form.Controls.Add($msgLabel)

$noticeLabel = New-Object System.Windows.Forms.Label
$noticeLabel.Text = "실행 중에는 ${updateCheckSeconds}초마다 새 버전을 확인합니다."
$noticeLabel.Font = New-Object System.Drawing.Font('Segoe UI', 8.5)
$noticeLabel.ForeColor = [System.Drawing.Color]::Gray
$noticeLabel.Location = New-Object System.Drawing.Point(22, 184)
$noticeLabel.Size = New-Object System.Drawing.Size(450, 22)
$form.Controls.Add($noticeLabel)

function New-Button([string]$text, [int]$x, [int]$y) {
  $b = New-Object System.Windows.Forms.Button
  $b.Text = $text
  $b.Location = New-Object System.Drawing.Point($x, $y)
  $b.Size = New-Object System.Drawing.Size(84, 36)
  $form.Controls.Add($b)
  return $b
}

$startButton = New-Button '시작' 22 135
$stopButton = New-Button '중지' 110 135
$browserButton = New-Button '브라우저' 198 135
$logButton = New-Button '로그' 286 135
$updateButton = New-Button '업데이트' 374 135
$updateButton.Visible = $false

function Update-Ui {
  if ($script:opBusy -or $script:relaunching) { return }
  $title.Text = "auto-tax 서버  v$($script:version)"
  $form.Text = "auto-tax v$($script:version)"
  $state = Get-ServerState
  switch ($state) {
    'running' {
      $info = Get-AppInfo
      $shownVersion = if ($info) { $info.version } else { $script:version }
      $stateLabel.Text = "● 실행 중 · v$shownVersion  ($url)"
      $stateLabel.ForeColor = [System.Drawing.Color]::ForestGreen
    }
    'foreign' {
      $stateLabel.Text = "● 포트 $port 를 다른 프로그램이 사용 중"
      $stateLabel.ForeColor = [System.Drawing.Color]::Firebrick
    }
    default {
      $stateLabel.Text = "● 중지됨 · 설치된 버전 v$($script:version)"
      $stateLabel.ForeColor = [System.Drawing.Color]::Gray
    }
  }
  $startButton.Enabled = ($state -eq 'stopped')
  $stopButton.Enabled = ($state -eq 'running')
  $browserButton.Enabled = ($state -eq 'running')
  # 새 버전이 확인된 경우에만 안내 문구와 업데이트 버튼을 보여 준다.
  if ($script:availableVersion) {
    $noticeLabel.Text = "새 버전이 있습니다. (v$($script:availableVersion))"
    $noticeLabel.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
    $noticeLabel.ForeColor = [System.Drawing.Color]::DarkOrange
    $updateButton.Visible = ($state -ne 'foreign')
    $updateButton.Enabled = ($state -ne 'foreign')
  } else {
    $noticeLabel.Text = "실행 중에는 ${updateCheckSeconds}초마다 새 버전을 확인합니다."
    $noticeLabel.Font = New-Object System.Drawing.Font('Segoe UI', 8.5)
    $noticeLabel.ForeColor = [System.Drawing.Color]::Gray
    $updateButton.Visible = $false
  }
}

# 서버가 실행 중일 때 새 버전이 있는지만 확인한다. 설치는 하지 않는다.
function Check-ForUpdate {
  $script:opBusy = $true
  try {
    $info = Get-UpdateInfo
    if ($info.Ok) {
      $script:availableVersion = if ($info.Configured -and $info.Available) { $info.Latest } else { $null }
    }
  } finally {
    $script:opBusy = $false
    Update-Ui
  }
}

# 작업 하나를 돌리는 동안 버튼을 막고, 끝난 뒤 결과를 보여 준다. 타이머 갱신은 작업 중에 건너뛴다.
function Run-Operation([string]$message, [scriptblock]$action) {
  $script:opBusy = $true
  $startButton.Enabled = $false
  $stopButton.Enabled = $false
  $updateButton.Enabled = $false
  $msgLabel.Text = $message
  $form.Refresh()
  try {
    $result = & $action
    $msgLabel.Text = [string]($result | Select-Object -Last 1)
  } catch {
    $msgLabel.Text = "오류: $($_.Exception.Message)"
  } finally {
    $script:opBusy = $false
    Update-Ui
  }
}

$startButton.Add_Click({
  Run-Operation '서버를 시작하는 중... (처음이면 몇 분 걸릴 수 있습니다)' {
    $err = Start-Server
    if ($err) { return $err }
    Start-Process $url
    return '서버를 시작했습니다.'
  }
})

$stopButton.Add_Click({
  Run-Operation '서버를 중지하는 중...' { Stop-Server }
})

$updateButton.Add_Click({
  Run-Operation '업데이트를 설치하는 중... (서버가 실행 중이면 잠시 멈춥니다)' { Update-Flow }
})

$browserButton.Add_Click({ Start-Process $url })

$logButton.Add_Click({
  if (-not (Test-Path $logFile)) { $msgLabel.Text = '아직 로그 파일이 없습니다.'; return }
  Start-Process notepad.exe $logFile
})

# 패널을 닫을 때 서버가 돌고 있으면 계속 둘지, 같이 끌지 묻는다
$form.Add_FormClosing({
  param($sender, $e)
  if ($script:relaunching) { return }
  if ($script:opBusy) {
    [System.Windows.Forms.MessageBox]::Show('작업이 끝난 뒤에 닫아 주세요.', 'auto-tax') | Out-Null
    $e.Cancel = $true
    return
  }
  if ((Get-ServerState) -ne 'running') { return }
  $answer = [System.Windows.Forms.MessageBox]::Show(
    "서버가 실행 중입니다.`n`n예: 서버는 계속 실행하고 패널만 닫기`n아니오: 서버도 중지하고 닫기`n취소: 닫지 않기",
    'auto-tax', [System.Windows.Forms.MessageBoxButtons]::YesNoCancel, [System.Windows.Forms.MessageBoxIcon]::Question)
  if ($answer -eq [System.Windows.Forms.DialogResult]::Cancel) { $e.Cancel = $true }
  elseif ($answer -eq [System.Windows.Forms.DialogResult]::No) { Stop-Server | Out-Null }
})

# 첫 실행: 화면이 뜬 뒤 새 버전을 확인하고, 있으면 설치해서 새 버전으로 서버를 띄운다.
$form.Add_Shown({
  Run-Operation '시작할 때 업데이트를 확인하는 중...' { Update-Flow $true }
})

# 2초마다 화면을 갱신한다. 서버가 실행 중이면 30초마다 새 버전이 있는지 확인한다.
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 2000
$timer.Add_Tick({
  if ($script:opBusy -or $script:relaunching) { return }
  if ((Get-ServerState) -eq 'running' -and (Get-Date) -ge $script:nextUpdateCheck) {
    $script:nextUpdateCheck = (Get-Date).AddSeconds($updateCheckSeconds)
    Check-ForUpdate
    return
  }
  Update-Ui
})
$timer.Start()

Update-Ui
[System.Windows.Forms.Application]::Run($form)
