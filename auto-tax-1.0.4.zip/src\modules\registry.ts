import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { loadConfig, updateConfigFolders } from '../config';
import { BusinessData } from '../types';
import {
  CertificateMeta,
  InvoiceIssueRecord,
  Operator,
  OperatorInput,
  PlantInput,
  PlantMailSettings,
  PlantPatch,
  PlantRecord,
  PlantView,
  RegistryFile,
} from '../types/registry';
import { CollectorService } from './collector';
import { formatBizNumber, isValidBizNumber } from './licenseParser';
import {
  accountKey,
  hasMailPassword,
  MailSettingsError,
  normalizeMailPassword,
  normalizeMailSettings,
  saveMailPassword,
} from './mailAccounts';
import { DataStorage } from './storage';

/** 마법사로 만든 발전소의 임시 이름. 첫 메일 수집 때 메일의 발전소명으로 바뀐다. */
export const AUTO_FILL_NAME = '메일 수집 후 자동 입력';

export class HttpError extends Error {
  constructor(public status: number, message: string) {
    super(message);
    this.name = 'HttpError';
  }
}

// ---------- 입력 정리 ----------

const clean = (v: unknown, max = 200): string =>
  typeof v === 'string' ? v.replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max) : '';

function normalizeDate(v: unknown): string {
  const s = clean(v, 30);
  if (!s) return '';
  const m = s.match(/^(\d{4})\D+(\d{1,2})\D+(\d{1,2})\D*$/);
  if (!m) throw new HttpError(400, '개업일은 YYYY-MM-DD 형식이어야 합니다.');
  const y = m[1];
  const mo = m[2].padStart(2, '0');
  const d = m[3].padStart(2, '0');
  const dt = new Date(`${y}-${mo}-${d}T00:00:00Z`);
  if (Number.isNaN(dt.getTime()) || dt.getUTCMonth() + 1 !== Number(mo) || dt.getUTCDate() !== Number(d)) {
    throw new HttpError(400, '개업일이 올바른 날짜가 아닙니다.');
  }
  return `${y}-${mo}-${d}`;
}

function normalizeOperatorInput(input: OperatorInput): OperatorInput {
  const out: OperatorInput = {};
  if (input.businessName !== undefined) out.businessName = clean(input.businessName, 100);
  if (input.representative !== undefined) out.representative = clean(input.representative, 50);
  if (input.address !== undefined) out.address = clean(input.address, 200);
  if (input.businessType !== undefined) out.businessType = clean(input.businessType, 100);
  if (input.businessItem !== undefined) out.businessItem = clean(input.businessItem, 100);
  if (input.openedDate !== undefined) out.openedDate = normalizeDate(input.openedDate);
  if (input.registrationNumber !== undefined) {
    const formatted = formatBizNumber(String(input.registrationNumber));
    if (!formatted) throw new HttpError(400, '사업자등록번호는 숫자 10자리(000-00-00000)여야 합니다.');
    if (!isValidBizNumber(formatted.replace(/-/g, ''))) {
      throw new HttpError(400, '사업자등록번호 검증에 실패했습니다. 숫자를 다시 확인해 주세요.');
    }
    out.registrationNumber = formatted;
  }
  return out;
}

const nonEmpty = (input: OperatorInput): OperatorInput =>
  Object.fromEntries(Object.entries(input).filter(([, v]) => v !== undefined && v !== '')) as OperatorInput;

// ---------- 사업자 / 발전소 부가정보 저장소 ----------

export class RegistryStorage {
  private file: string;

  constructor(outputDir: string = './data') {
    const baseDir = path.resolve(process.cwd(), outputDir);
    if (!fs.existsSync(baseDir)) fs.mkdirSync(baseDir, { recursive: true });
    // data/ 바로 아래의 "폴더"는 발전소 데이터로 취급되므로 파일(registry.json)로만 저장한다.
    this.file = path.join(baseDir, 'registry.json');
  }

  private read(): RegistryFile {
    if (!fs.existsSync(this.file)) return { operators: [], plants: [], invoices: [] };
    try {
      const parsed = JSON.parse(fs.readFileSync(this.file, 'utf-8'));
      return {
        operators: Array.isArray(parsed.operators) ? parsed.operators : [],
        plants: Array.isArray(parsed.plants) ? parsed.plants : [],
        invoices: Array.isArray(parsed.invoices) ? parsed.invoices : [],
      };
    } catch (err) {
      // 읽기 실패 시 빈 값으로 덮어쓰지 않도록 중단한다.
      throw new HttpError(500, `registry.json 을 읽을 수 없습니다. 파일을 확인해 주세요: ${err}`);
    }
  }

  private write(reg: RegistryFile) {
    const tmp = `${this.file}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(reg, null, 2), 'utf-8');
    fs.renameSync(tmp, this.file);
  }

  // ----- 사업자 -----

  public listOperators(): Operator[] {
    return this.read().operators.sort((a, b) => a.businessName.localeCompare(b.businessName, 'ko'));
  }

  public getOperator(id: string): Operator | undefined {
    return this.read().operators.find((o) => o.id === id);
  }

  public findByRegistrationNumber(registrationNumber: string): Operator | undefined {
    const formatted = formatBizNumber(registrationNumber);
    if (!formatted) return undefined;
    return this.read().operators.find((o) => o.registrationNumber === formatted);
  }

  public createOperator(input: OperatorInput): Operator {
    const n = normalizeOperatorInput(input);
    if (!n.registrationNumber) throw new HttpError(400, '사업자등록번호가 필요합니다.');
    if (!n.businessName) throw new HttpError(400, '상호(법인명)가 필요합니다.');

    const reg = this.read();
    const dup = reg.operators.find((o) => o.registrationNumber === n.registrationNumber);
    if (dup) {
      throw new HttpError(409, `이미 등록된 사업자입니다: ${dup.businessName} (${dup.registrationNumber})`);
    }

    const now = new Date().toISOString();
    const op: Operator = {
      id: crypto.randomUUID(),
      businessName: n.businessName,
      representative: n.representative ?? '',
      registrationNumber: n.registrationNumber,
      openedDate: n.openedDate ?? '',
      address: n.address ?? '',
      businessType: n.businessType ?? '',
      businessItem: n.businessItem ?? '',
      createdAt: now,
      updatedAt: now,
    };
    reg.operators.push(op);
    this.write(reg);
    return op;
  }

  public updateOperator(id: string, input: OperatorInput): Operator {
    const n = normalizeOperatorInput(input);
    const reg = this.read();
    const op = reg.operators.find((o) => o.id === id);
    if (!op) throw new HttpError(404, '사업자를 찾을 수 없습니다.');

    if (n.businessName === '') throw new HttpError(400, '상호(법인명)는 비울 수 없습니다.');
    if (n.registrationNumber) {
      const dup = reg.operators.find((o) => o.id !== id && o.registrationNumber === n.registrationNumber);
      if (dup) throw new HttpError(409, `다른 사업자가 이미 사용 중인 등록번호입니다: ${dup.businessName}`);
    }

    Object.assign(op, n, { updatedAt: new Date().toISOString() });
    this.write(reg);
    return op;
  }

  /** 사업자등록번호가 같은 사업자가 있으면 수정(빈 값은 기존 값 유지), 없으면 신규 등록 */
  public upsertByRegistrationNumber(input: OperatorInput): { mode: 'created' | 'updated'; operator: Operator } {
    const n = normalizeOperatorInput(input);
    if (!n.registrationNumber) throw new HttpError(400, '사업자등록번호가 필요합니다.');
    const existing = this.findByRegistrationNumber(n.registrationNumber);
    if (existing) {
      return { mode: 'updated', operator: this.updateOperator(existing.id, nonEmpty(n)) };
    }
    return { mode: 'created', operator: this.createOperator(n) };
  }

  // ----- 발전소 부가정보 -----

  /** 인증서 요약 정보만 저장한다(null 이면 삭제). 파일/비밀번호는 certStore 가 secrets/ 에 보관한다. */
  public setCertificate(operatorId: string, meta: CertificateMeta | null): Operator {
    const reg = this.read();
    const op = reg.operators.find((o) => o.id === operatorId);
    if (!op) throw new HttpError(404, '사업자를 찾을 수 없습니다.');
    if (meta) op.certificate = meta;
    else delete op.certificate;
    op.updatedAt = new Date().toISOString();
    this.write(reg);
    return op;
  }

  public listPlantRecords(): PlantRecord[] {
    return this.read().plants;
  }

  public getPlantRecord(folderId: string): PlantRecord | undefined {
    return this.read().plants.find((p) => p.folderId === folderId);
  }

  public upsertPlantRecord(folderId: string, patch: PlantPatch): PlantRecord {
    const reg = this.read();
    if (patch.operatorId && !reg.operators.some((o) => o.id === patch.operatorId)) {
      throw new HttpError(400, '선택한 사업자를 찾을 수 없습니다.');
    }
    let rec = reg.plants.find((p) => p.folderId === folderId);
    if (!rec) {
      rec = { folderId, operatorId: '', address: '', capacity: '', contractNumber: '', updatedAt: '' };
      reg.plants.push(rec);
    }
    Object.assign(rec, patch, { updatedAt: new Date().toISOString() });
    this.write(reg);
    return rec;
  }

  // ----- 세금계산서 발행 완료 여부 -----

  public getInvoiceIssue(folderId: string, generationPeriod: string): InvoiceIssueRecord | undefined {
    return this.read().invoices.find((r) => r.folderId === folderId && r.generationPeriod === generationPeriod);
  }

  /** 발전월의 발행 완료 여부를 직접 표시한다. 발전월 데이터가 있는지는 호출하는 쪽에서 확인한다. */
  public setInvoiceIssued(folderId: string, generationPeriod: string, issued: boolean): InvoiceIssueRecord {
    const reg = this.read();
    let rec = reg.invoices.find((r) => r.folderId === folderId && r.generationPeriod === generationPeriod);
    if (!rec) {
      rec = { folderId, generationPeriod, issued, updatedAt: '' };
      reg.invoices.push(rec);
    }
    rec.issued = issued;
    rec.updatedAt = new Date().toISOString();
    this.write(reg);
    return rec;
  }

  /** 대시보드 데이터에 직접 입력한 주소/용량/계약번호와 사업자명, 발전월별 발행 완료 여부를 덮어쓴다. */
  public applyToBusinesses(businesses: BusinessData[]): void {
    let reg: RegistryFile;
    try {
      reg = this.read();
    } catch (err) {
      console.warn('[Registry] 대시보드에 사업자 정보를 반영하지 못했습니다:', err);
      return;
    }
    const operators = new Map(reg.operators.map((o) => [o.id, o]));
    for (const b of businesses) {
      for (const p of b.periods) {
        const inv = reg.invoices.find((r) => r.folderId === b.folderId && r.generationPeriod === p.generationPeriod);
        p.invoiceIssued = !!inv?.issued;
        if (inv) p.invoiceIssuedUpdatedAt = inv.updatedAt;
      }
      const rec = reg.plants.find((p) => p.folderId === b.folderId);
      if (!rec) continue;
      if (rec.address) b.address = rec.address;
      if (rec.capacity) b.capacity = rec.capacity;
      if (rec.contractNumber) b.contractNumber = rec.contractNumber;
      const op = rec.operatorId ? operators.get(rec.operatorId) : undefined;
      if (op) {
        b.operatorId = op.id;
        b.operatorName = op.businessName;
      }
    }
  }
}

// ---------- 발전소 등록/수정 ----------

export class PlantService {
  private registry: RegistryStorage;
  private storage: DataStorage;

  constructor(private outputDir: string, private configPath?: string) {
    this.registry = new RegistryStorage(outputDir);
    this.storage = new DataStorage(outputDir);
  }

  private cfg() {
    return loadConfig(this.configPath);
  }

  private patchFrom(input: PlantInput): PlantPatch {
    const patch: PlantPatch = {};
    if (input.operatorId !== undefined) patch.operatorId = clean(input.operatorId, 64);
    if (input.address !== undefined) patch.address = clean(input.address, 200);
    if (input.capacity !== undefined) patch.capacity = clean(input.capacity, 50);
    if (input.contractNumber !== undefined) patch.contractNumber = clean(input.contractNumber, 50);
    return patch;
  }

  /** 메일 항목이 하나라도 들어왔으면 전체를 검증해 돌려준다. 없으면 undefined(변경 없음). */
  private mailFrom(input: PlantInput): PlantMailSettings | undefined {
    if (input.mailPlatform === undefined && input.mailAccount === undefined && input.mailbox === undefined) return undefined;
    try {
      return normalizeMailSettings(input.mailPlatform, input.mailAccount, input.mailbox);
    } catch (err) {
      if (err instanceof MailSettingsError) throw new HttpError(400, err.message);
      throw err;
    }
  }

  /** 사업자와 발전소는 1:1 이다. 이미 다른 발전소에 연결된 사업자는 또 연결할 수 없다. */
  private assertOperatorFree(operatorId: string, exceptFolderId?: string) {
    const folders = this.cfg().folders;
    const folderIds = new Set(folders.map((f) => f.folderId));
    const used = this.registry
      .listPlantRecords()
      .find((r) => r.operatorId === operatorId && r.folderId !== exceptFolderId && folderIds.has(r.folderId));
    if (used) {
      const name = folders.find((f) => f.folderId === used.folderId)?.businessName ?? used.folderId;
      throw new HttpError(409, `이 사업자는 이미 발전소(${name})에 연결되어 있습니다. 사업자와 발전소는 1:1로만 연결할 수 있습니다.`);
    }
  }

  /** 다른 발전소가 같은 메일함을 쓰면 같은 메일이 두 발전소에 저장되므로 막는다. */
  private assertMailboxFree(mail: PlantMailSettings, exceptFolderId?: string) {
    const key = `${accountKey(mail.platform, mail.account)}#${mail.mailbox}`;
    const names = new Map(this.cfg().folders.map((f) => [f.folderId, f.businessName]));
    const dup = this.registry
      .listPlantRecords()
      .find((r) => r.folderId !== exceptFolderId && r.mail && names.has(r.folderId) && `${accountKey(r.mail.platform, r.mail.account)}#${r.mail.mailbox}` === key);
    if (dup) throw new HttpError(409, `다른 발전소(${names.get(dup.folderId)})가 이미 같은 메일함을 사용하고 있습니다.`);
  }

  /** 새 비밀번호가 있으면 저장하고, 없으면 그 계정에 저장된 비밀번호가 있는지 확인한다. */
  private async applyMailPassword(mail: PlantMailSettings, rawPassword: unknown) {
    let password: string;
    try {
      password = normalizeMailPassword(mail.platform, rawPassword);
    } catch (err) {
      if (err instanceof MailSettingsError) throw new HttpError(400, err.message);
      throw err;
    }
    if (password) {
      await saveMailPassword(mail.platform, mail.account, password);
    } else if (!hasMailPassword(mail.platform, mail.account)) {
      throw new HttpError(400, '이 메일 계정은 저장된 비밀번호가 없습니다. 메일 비밀번호를 입력해 주세요.');
    }
  }

  private newPlantId(): string {
    const used = new Set(this.cfg().folders.map((f) => f.folderId));
    for (const b of this.storage.getAllBusinessesData().businesses) used.add(b.folderId);
    for (;;) {
      // 데이터 폴더 이름이 "<ID>_<발전소명>" 이므로 ID 에 '_' 가 들어가면 안 된다.
      const id = `p${crypto.randomBytes(4).toString('hex')}`;
      if (!used.has(id)) return id;
    }
  }

  public listPlants(): PlantView[] {
    const config = this.cfg();
    const data = this.storage.getAllBusinessesData(config.folders);
    const derived = new Map(data.businesses.map((b) => [b.folderId, b]));
    const operators = new Map(this.registry.listOperators().map((o) => [o.id, o]));
    const dash = (v?: string) => (v && v !== '-' ? v : '');

    return config.folders.map((f) => {
      const rec = this.registry.getPlantRecord(f.folderId);
      const d = derived.get(f.folderId);
      const op = rec?.operatorId ? operators.get(rec.operatorId) : undefined;
      return {
        folderId: f.folderId,
        plantName: f.businessName,
        description: f.description ?? '',
        operatorId: op ? op.id : '',
        operatorName: op ? op.businessName : '',
        address: rec?.address || dash(d?.address),
        capacity: rec?.capacity || dash(d?.capacity),
        contractNumber: rec?.contractNumber || dash(d?.contractNumber),
        mail: rec?.mail ?? null,
        mailPasswordSaved: rec?.mail ? hasMailPassword(rec.mail.platform, rec.mail.account) : false,
        hasData: (d?.totalPeriods ?? 0) > 0,
      };
    });
  }

  /**
   * 발전소 표시 순서를 바꾼다(config.json folders 순서 = 관리 목록과 메인 화면 순서).
   * order 는 현재 발전소 ID 를 빠짐없이 한 번씩 담아야 한다. 그 사이 발전소가 추가/삭제됐으면 409.
   */
  public reorderPlants(order: unknown): PlantView[] {
    if (!Array.isArray(order) || !order.every((id) => typeof id === 'string')) {
      throw new HttpError(400, 'order 는 발전소 ID 목록이어야 합니다.');
    }
    const ids = order as string[];
    updateConfigFolders((folders) => {
      const byId = new Map(folders.map((f) => [f.folderId, f]));
      if (ids.length !== folders.length || new Set(ids).size !== ids.length || !ids.every((id) => byId.has(id))) {
        throw new HttpError(409, '발전소 목록이 바뀌어 순서를 저장하지 못했습니다. 목록을 새로 불러온 뒤 다시 시도해 주세요.');
      }
      return ids.map((id) => byId.get(id)!);
    }, this.configPath);
    return this.listPlants();
  }

  public async createPlant(input: PlantInput): Promise<PlantView> {
    // 마법사(autoFill)에서는 발전소명·주소·용량·고객번호를 받지 않고, 첫 메일 수집 때 채운다.
    const autoFill = input.autoFill === true;
    const plantName = clean(input.plantName, 100) || (autoFill ? AUTO_FILL_NAME : '');
    if (!plantName) throw new HttpError(400, '발전소명이 필요합니다.');
    const patch = this.patchFrom(input);
    if (patch.operatorId && !this.registry.getOperator(patch.operatorId)) {
      throw new HttpError(400, '선택한 사업자를 찾을 수 없습니다.');
    }
    if (patch.operatorId) this.assertOperatorFree(patch.operatorId);
    // 메일 정보는 단계별 등록을 위해 나중에 넣을 수 있다(없으면 수집 대상에서 제외됨).
    const mail = this.mailFrom(input);
    if (autoFill && !mail) throw new HttpError(400, '메일 수집 정보(플랫폼, ID, 메일함)를 입력해 주세요.');
    if (mail) {
      this.assertMailboxFree(mail);
      await this.applyMailPassword(mail, input.mailPassword);
      patch.mail = mail;
    }
    if (autoFill) patch.autoFill = true;
    const folderId = this.newPlantId();

    const description = clean(input.description, 200) || plantName;
    updateConfigFolders((folders) => [...folders, { folderId, businessName: plantName, description }], this.configPath);
    this.registry.upsertPlantRecord(folderId, patch);
    return this.listPlants().find((p) => p.folderId === folderId)!;
  }

  public async updatePlant(folderId: string, input: PlantInput): Promise<PlantView> {
    const current = this.cfg().folders.find((f) => f.folderId === folderId);
    if (!current) throw new HttpError(404, '발전소를 찾을 수 없습니다.');

    const patch = this.patchFrom(input);
    if (patch.operatorId && !this.registry.getOperator(patch.operatorId)) {
      throw new HttpError(400, '선택한 사업자를 찾을 수 없습니다.');
    }
    if (patch.operatorId) this.assertOperatorFree(patch.operatorId, folderId);
    const mail = this.mailFrom(input);
    if (mail) {
      this.assertMailboxFree(mail, folderId);
      await this.applyMailPassword(mail, input.mailPassword);
      patch.mail = mail;
    }

    const newName = input.plantName !== undefined ? clean(input.plantName, 100) : current.businessName;
    if (!newName) throw new HttpError(400, '발전소명은 비울 수 없습니다.');
    // 설명이 발전소명과 같게(기본값) 쓰여 있던 경우에는 이름 변경에 맞춰 같이 바꾼다.
    const newDescription =
      input.description !== undefined
        ? clean(input.description, 200)
        : current.description === current.businessName
          ? newName
          : current.description;

    const renamed = newName !== current.businessName;
    let dirRenamed = false;
    if (renamed) {
      if (CollectorService.getInstance().getStatus().status === 'running') {
        throw new HttpError(409, '메일 수집이 진행 중일 때는 발전소명을 바꿀 수 없습니다. 수집이 끝난 뒤 다시 시도해 주세요.');
      }
      try {
        dirRenamed = this.storage.renameFolderDir(folderId, newName);
      } catch (err: any) {
        throw new HttpError(409, err?.message?.includes('이미 있습니다') ? err.message : `데이터 폴더 이름을 바꾸지 못했습니다(다른 프로그램에서 열려 있을 수 있습니다): ${err?.message || err}`);
      }
    }

    try {
      if (renamed || input.description !== undefined) {
        updateConfigFolders(
          (folders) =>
            folders.map((f) =>
              f.folderId === folderId ? { ...f, businessName: newName, description: newDescription } : f
            ),
          this.configPath
        );
      }
    } catch (err) {
      if (dirRenamed) {
        try {
          this.storage.renameFolderDir(folderId, current.businessName);
        } catch {}
      }
      throw err;
    }

    if (Object.keys(patch).length > 0) this.registry.upsertPlantRecord(folderId, patch);
    return this.listPlants().find((p) => p.folderId === folderId)!;
  }
}
