import { startServer } from './server';
import { CollectorService } from './modules/collector';
import { loadConfig } from './config';
import { applyUpdate, checkForUpdate, restartServerSoon } from './modules/updater';

const CHECK_TIMEOUT_MS = 15_000;

function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  let timer: NodeJS.Timeout | undefined;
  const timeout = new Promise<never>((_, reject) => {
    timer = setTimeout(() => reject(new Error('시간 초과')), ms);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

/**
 * 시작할 때 새 버전이 있으면 자동으로 설치하고 서버를 다시 띄운다.
 * 업데이트 서버에 닿지 않거나 설치에 실패하면 기록만 남기고 현재 버전으로 계속 실행한다.
 * AUTOTAX_NO_AUTO_UPDATE=1 이면 건너뛴다(개발 중 테스트용).
 */
async function autoUpdateOnStart(): Promise<void> {
  if (process.env.AUTOTAX_NO_AUTO_UPDATE === '1') return;
  const manifestUrl = loadConfig().options.updateManifestUrl || '';
  if (!manifestUrl) return;
  try {
    const check = await withTimeout(checkForUpdate(manifestUrl), CHECK_TIMEOUT_MS);
    if (!check.available) return;
    console.log(`[Update] 새 버전 v${check.latest} 을(를) 설치합니다 (현재 v${check.current}).`);
    const result = await applyUpdate(manifestUrl);
    console.log(`[Update] v${result.to} 설치 완료. 서버를 다시 시작합니다.`);
    restartServerSoon();
    process.exit(0);
  } catch (err: any) {
    console.warn(`[Update] 자동 업데이트를 건너뜁니다: ${err?.message || err}`);
  }
}

async function main() {
  const isCliMode = process.argv.includes('--cli') || process.argv.includes('--collect');

  if (isCliMode) {
    console.log('====================================================');
    console.log('   메일 수집 및 세금계산서 발행 데이터 CLI 수집 실행');
    console.log('====================================================');
    const collector = CollectorService.getInstance();
    await collector.startCollection();
  } else {
    await autoUpdateOnStart();
    const port = parseInt(process.env.PORT || '3000', 10);
    startServer(port);
  }
}

main().catch((err) => {
  console.error('[Error] 실행 중 오류 발생:', err);
  process.exit(1);
});
